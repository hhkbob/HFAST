#ifndef FILETOOLBAR_H
#define FILETOOLBAR_H

#include <QWidget>
#include <QMenu>
#include <QFileDialog>
#include <QAction>
#include "printTool.h"

class fileToolBar : public QWidget
{
    Q_OBJECT
public:
    explicit fileToolBar(printTool *pEvent, QMenu *File);
    ~fileToolBar();

    QString filePath;

    //  保存工程文件
    QAction *savePr;

    //  读取工程文件设置
    QAction *readProj;

    printTool *pEvent;

    QAction *readMesh;

    QAction *readBash;

    void setWorkDirBash(QString path);
    bool readProjectBash(QString json);


private:
    //  设置工作目录
    QAction *setWorkDir;


signals:
    void triggered();
    void changeDir(QString);

public slots:
    void setWDTrigger();
    bool readProject();

};

#endif // FILETOOLBAR_H
