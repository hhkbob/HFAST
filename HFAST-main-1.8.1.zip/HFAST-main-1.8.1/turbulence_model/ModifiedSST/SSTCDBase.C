/*---------------------------------------------------------------------------*\
  =========                 |
  \\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
   \\    /   O peration     |
    \\  /    A nd           | Copyright (C) 2011-2017 OpenFOAM Foundation
     \\/     M anipulation  |
-------------------------------------------------------------------------------
License
    This file is part of OpenFOAM.

    OpenFOAM is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    OpenFOAM is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.

    You should have received a copy of the GNU General Public License
    along with OpenFOAM.  If not, see <http://www.gnu.org/licenses/>.

\*---------------------------------------------------------------------------*/

#include "SSTCDBase.H"
#include "fvOptions.H"
#include "bound.H"
#include "wallDist.H"

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

namespace Foam
{

// * * * * * * * * * * * Protected Member Functions  * * * * * * * * * * * * //

template<class TurbulenceModel, class BasicTurbulenceModel>
tmp<volScalarField>
SSTCD<TurbulenceModel, BasicTurbulenceModel>::SSTCD::F1
(
    const volScalarField& CDkOmega
) const
{
    tmp<volScalarField> CDkOmegaPlus = max
    (
        CDkOmega,
        dimensionedScalar("1.0e-10", dimless/sqr(dimTime), 1.0e-10)
    );

    tmp<volScalarField> arg1 = min
    (
        min
        (
            max   
            (
                (scalar(1)/betaStar_)*sqrt(k_)/(omega_*y_),
                scalar(500)*(this->mu()/this->rho_)/(sqr(y_)*omega_)
                //scalar(500)*(this->mu()/this->rho_)/(pow(y_,2)*omega_)
            ),
            (4*alphaOmega2_)*k_/(CDkOmegaPlus*sqr(y_))
            //(4*alphaOmega2_)*k_/(CDkOmegaPlus*pow(y_,2))
        ),
        scalar(10)
    );

    return tanh(pow4(arg1));
}

template<class TurbulenceModel, class BasicTurbulenceModel>
tmp<volScalarField>
SSTCD<TurbulenceModel, BasicTurbulenceModel>::SSTCD::F2
(

) const
{
    tmp<volScalarField> arg2 = min
    (
        max
        (
            (scalar(2)/betaStar_)*sqrt(k_)/(omega_*y_),
            scalar(500)*(this->mu()/this->rho_)/(sqr(y_)*omega_)
            //scalar(500)*(this->mu()/this->rho_)/(pow(y_,2)*omega_)
        ),
        scalar(100)
    );

    return tanh(sqr(arg2));
   //return tanh(pow(arg2,2));
}

template<class TurbulenceModel, class BasicTurbulenceModel>
tmp<volScalarField>
SSTCD<TurbulenceModel, BasicTurbulenceModel>::SSTCD::F3
(

) const
{
    tmp<volScalarField> arg3 = min
    (
        150*(this->mu()/this->rho_)/(omega_*sqr(y_)),
        //150*(this->mu()/this->rho_)/(omega_*pow(y_,2)),
        scalar(10)
    );

    return 1 - tanh(pow4(arg3));
}

template<class TurbulenceModel, class BasicTurbulenceModel>
tmp<volScalarField>
SSTCD<TurbulenceModel, BasicTurbulenceModel>::SSTCD::F23
(

) const
{
    tmp<volScalarField> f23(F2());

    if (F3_)
    {
        f23.ref() *= F3();
    }

    return f23;
}


template<class TurbulenceModel, class BasicTurbulenceModel>
void SSTCD<TurbulenceModel, BasicTurbulenceModel>::correctNut
(
    const volScalarField& S2,
    const volScalarField& F2
)
{   
    /*volScalarField Ref(this->rho_*k_/( 6*this->mu()*omega_));
    volScalarField alphaInf
    (
         alphaStar_*( (0.072/3+Ref) /(1+Ref) )
    );*/
  
    this->nut_ = a1_*k_/max(a1_*omega_, b1_*F2*sqrt(S2));
    this->nut_.correctBoundaryConditions();
    fv::options::New(this->mesh_).correct(this->nut_);

    BasicTurbulenceModel::correctNut();
}


// * * * * * * * * * * * * Protected Member Functions  * * * * * * * * * * * //

template<class TurbulenceModel, class BasicTurbulenceModel>
void SSTCD<TurbulenceModel, BasicTurbulenceModel>::correctNut()
{
    correctNut(2*magSqr(symm(fvc::grad(this->U_))), F23());
}

template<class TurbulenceModel, class BasicTurbulenceModel>
tmp<volScalarField::Internal>
SSTCD<TurbulenceModel, BasicTurbulenceModel>::fr
(

)const
{
    tmp<volTensorField> tgradU = fvc::grad(this->U_);
    volSymmTensorField S(symm(tgradU()));
    volTensorField Omega(skew(tgradU()));
    const volScalarField::Internal S2(sqrt(2*S&&S));
    const volScalarField::Internal Omega2
    (
          sqrt(2*Omega&&Omega)
    );
    const volScalarField::Internal rStar(S2/Omega2);

    // do not consider the rotation
    const volScalarField::Internal D
    (
          sqrt(max(S2*S2, 0.09*this->omega_()*this->omega_()))
    );
    const volScalarField::Internal DBar(Omega2*pow(D,3.0));
    //volVectorField velocity(this->U);

    const surfaceScalarField& alphaRhoPhi = this->alphaRhoPhi_;
    
    volScalarField::Internal rBar1
    (
         scalar(2.0)*Omega & S 
       && (fvc::ddt(S) + fvc::div( alphaRhoPhi, S))
    );
    volScalarField::Internal rBar(rBar1/DBar);

    const volScalarField::Internal fRotation
    (
         (scalar(1.0)+cr1_)*2*rStar/(scalar(1.0)+rStar)
       * (1-cr3_*atan(cr2_*rBar))
       - cr1_
    );
    volScalarField::Internal frBar
    (
        max
        (
            min(fRotation, 1.25),
            0.
        )
    );
    S.clear();
    Omega.clear();
    return max(0., 1.0+Cscale_*(frBar-1.0));
}


template<class TurbulenceModel, class BasicTurbulenceModel>
tmp<volScalarField::Internal>
SSTCD<TurbulenceModel, BasicTurbulenceModel>::Pk
(
    const volScalarField::Internal& G1
) const
{
    return min(G1, (c1_*betaStar_)*this->k_()*this->omega_());
}

template<class TurbulenceModel, class BasicTurbulenceModel>
tmp<volScalarField::Internal>
SSTCD<TurbulenceModel, BasicTurbulenceModel>::PkIm
(
    const volScalarField::Internal& G1,
    const volScalarField::Internal& betaStar
) const
{
    return min(G1, (c1_*betaStar)*this->k_()*this->omega_());
}


template<class TurbulenceModel, class BasicTurbulenceModel>
tmp<volScalarField::Internal>
SSTCD<TurbulenceModel, BasicTurbulenceModel>::epsilonByk
(
    const volScalarField::Internal& F1,
    const volScalarField::Internal& F2
) const
{
    return betaStar_*omega_();
}
template<class TurbulenceModel, class BasicTurbulenceModel>
tmp<volScalarField::Internal>
SSTCD<TurbulenceModel, BasicTurbulenceModel>::epsilonBykIm
(
    const volScalarField::Internal& F1,
    const volScalarField::Internal& betaStar
) const
{
    return betaStar*omega_();
}


template<class TurbulenceModel, class BasicTurbulenceModel>
tmp<fvScalarMatrix>
SSTCD<TurbulenceModel, BasicTurbulenceModel>::kSource() const
{
    return tmp<fvScalarMatrix>
    (
        new fvScalarMatrix
        (
            k_,
            dimVolume*this->rho_.dimensions()*k_.dimensions()/dimTime
        )
    );
}


template<class TurbulenceModel, class BasicTurbulenceModel>
tmp<fvScalarMatrix>
SSTCD<TurbulenceModel, BasicTurbulenceModel>::omegaSource() const
{
    return tmp<fvScalarMatrix>
    (
        new fvScalarMatrix
        (
            omega_,
            dimVolume*this->rho_.dimensions()*omega_.dimensions()/dimTime
        )
    );
}


template<class TurbulenceModel, class BasicTurbulenceModel>
tmp<fvScalarMatrix> SSTCD<TurbulenceModel, BasicTurbulenceModel>::Qsas
(
    const volScalarField::Internal& S2,
    const volScalarField::Internal& gamma,
    const volScalarField::Internal& beta
) const
{
    return tmp<fvScalarMatrix>
    (
        new fvScalarMatrix
        (
            omega_,
            dimVolume*this->rho_.dimensions()*omega_.dimensions()/dimTime
        )
    );
}


// * * * * * * * * * * * * * * * * Constructors  * * * * * * * * * * * * * * //

template<class TurbulenceModel, class BasicTurbulenceModel>
SSTCD<TurbulenceModel, BasicTurbulenceModel>::SSTCD
(
    const word& type,
    const alphaField& alpha,
    const rhoField& rho,
    const volVectorField& U,
    const surfaceScalarField& alphaRhoPhi,
    const surfaceScalarField& phi,
    const transportModel& transport,
    const word& propertiesName
)
:
    TurbulenceModel
    (
        type,
        alpha,
        rho,
        U,
        alphaRhoPhi,
        phi,
        transport,
        propertiesName
    ),

    alphaK1_
    (
        dimensioned<scalar>::lookupOrAddToDict
        (
            "alphaK1",
            this->coeffDict_,
            0.85
        )
    ),
    alphaK2_
    (
        dimensioned<scalar>::lookupOrAddToDict
        (
            "alphaK2",
            this->coeffDict_,
            1.0
        )
    ),
    alphaOmega1_
    (
        dimensioned<scalar>::lookupOrAddToDict
        (
            "alphaOmega1",
            this->coeffDict_,
            0.5
        )
    ),
    alphaOmega2_
    (
        dimensioned<scalar>::lookupOrAddToDict
        (
            "alphaOmega2",
            this->coeffDict_,
            0.856
        )
    ),
    gamma1_
    (
        dimensioned<scalar>::lookupOrAddToDict
        (
            "gamma1",
            this->coeffDict_,
            5.0/9.0
        )
    ),
    gamma2_
    (
        dimensioned<scalar>::lookupOrAddToDict
        (
            "gamma2",
            this->coeffDict_,
            0.44
        )
    ),
    beta1_
    (
        dimensioned<scalar>::lookupOrAddToDict
        (
            "beta1",
            this->coeffDict_,
            0.075
        )
    ),
    beta2_
    (
        dimensioned<scalar>::lookupOrAddToDict
        (
            "beta2",
            this->coeffDict_,
            0.0828
        )
    ),
    betaStar_
    (
        dimensioned<scalar>::lookupOrAddToDict
        (
            "betaStar",
            this->coeffDict_,
            0.09
        )
    ),
    beta0Star_
    (
        dimensioned<scalar>::lookupOrAddToDict
        (
            "beta0Star",
            this->coeffDict_,
            0.09
        )
    ),
    f1_
    (
        dimensioned<scalar>::lookupOrAddToDict
        (
            "f1",
            this->coeffDict_,
            680
        )
    ),
    f2_
    (
        dimensioned<scalar>::lookupOrAddToDict
        (
            "f2",
            this->coeffDict_,
            80
        )
    ),

    a1_
    (
        dimensioned<scalar>::lookupOrAddToDict
        (
            "a1",
            this->coeffDict_,
            0.31
        )
    ),
    b1_
    (
        dimensioned<scalar>::lookupOrAddToDict
        (
            "b1",
            this->coeffDict_,
            1.0
        )
    ),

    c1_
    (
        dimensioned<scalar>::lookupOrAddToDict
        (
            "c1",
            this->coeffDict_,
            10.0
        )
    ),
    cr1_
    (
        dimensioned<scalar>::lookupOrAddToDict
        (
            "cr1",
            this->coeffDict_,
            1.0
        )
    ),
    cr2_
    (
        dimensioned<scalar>::lookupOrAddToDict
        (
            "cr2",
            this->coeffDict_,
            2.0
        )
    ),
    cr3_
    (
        dimensioned<scalar>::lookupOrAddToDict
        (
            "cr3",
            this->coeffDict_,
            1.0
        )
    ),
    Cscale_
    (
        dimensioned<scalar>::lookupOrAddToDict
        (
            "Cscale",
            this->coeffDict_,
            1.0
        )
    ),
    F3_
    (
        Switch::lookupOrAddToDict
        (
            "F3",
            this->coeffDict_,
            false
        )
    ),
    KatoLaunder_
    (
        Switch::lookupOrAddToDict
        (
            "KatoLaunder",
            this->coeffDict_,
            false
        )
    ), 

    VortexCorrect_
    (
        Switch::lookupOrAddToDict
        (
            "VortexCorrect",
            this->coeffDict_,
            false
        )
    ), 

    CrossDiffusion_
    (
        Switch::lookupOrAddToDict
        (
            "CrossDiffusion",
            this->coeffDict_,
            false
        )
    ), 
    CurvatureCorrect_
    (
        Switch::lookupOrAddToDict
        (
            "CurvatureCorrect",
            this->coeffDict_,
            false
        )
    ),   

    y_(wallDist::New(this->mesh_).y()),

    k_
    (
        IOobject
        (
            IOobject::groupName("k", U.group()),
            this->runTime_.timeName(),
            this->mesh_,
            IOobject::MUST_READ,
            IOobject::AUTO_WRITE
        ),
        this->mesh_
    ),
    omega_
    (
        IOobject
        (
            IOobject::groupName("omega", U.group()),
            this->runTime_.timeName(),
            this->mesh_,
            IOobject::MUST_READ,
            IOobject::AUTO_WRITE
        ),
        this->mesh_
    )
{
    bound(k_, this->kMin_);
    bound(omega_, this->omegaMin_);
}


// * * * * * * * * * * * * * * * Member Functions  * * * * * * * * * * * * * //

template<class TurbulenceModel, class BasicTurbulenceModel>
bool SSTCD<TurbulenceModel, BasicTurbulenceModel>::read()
{
    if (TurbulenceModel::read())
    {
        alphaK1_.readIfPresent(this->coeffDict());
        alphaK2_.readIfPresent(this->coeffDict());
        alphaOmega1_.readIfPresent(this->coeffDict());
        alphaOmega2_.readIfPresent(this->coeffDict());
        gamma1_.readIfPresent(this->coeffDict());
        gamma2_.readIfPresent(this->coeffDict());
        beta1_.readIfPresent(this->coeffDict());
        beta2_.readIfPresent(this->coeffDict());
        betaStar_.readIfPresent(this->coeffDict());
        beta0Star_.readIfPresent(this->coeffDict());
        f1_.readIfPresent(this->coeffDict());
        f2_.readIfPresent(this->coeffDict());
       
        a1_.readIfPresent(this->coeffDict());
        b1_.readIfPresent(this->coeffDict());
       
        c1_.readIfPresent(this->coeffDict());
        cr1_.readIfPresent(this->coeffDict());
        cr2_.readIfPresent(this->coeffDict());
        cr3_.readIfPresent(this->coeffDict());
        Cscale_.readIfPresent(this->coeffDict());

        F3_.readIfPresent("F3", this->coeffDict());
        KatoLaunder_.readIfPresent("KatoLaunder", this->coeffDict());
        VortexCorrect_.readIfPresent("VortexCorrect", this->coeffDict());
        CrossDiffusion_.readIfPresent("CrossDiffusion", this->coeffDict());
        CurvatureCorrect_.readIfPresent("CurvatureCorrect", this->coeffDict());
        return true;
    }
    else
    {
        return false;
    }
}


template<class TurbulenceModel, class BasicTurbulenceModel>
void SSTCD<TurbulenceModel, BasicTurbulenceModel>::correct()
{
    if (!this->turbulence_)
    {
        return;
    }

    // Local references
    const alphaField& alpha = this->alpha_;
    const rhoField& rho = this->rho_;
    const surfaceScalarField& alphaRhoPhi = this->alphaRhoPhi_;
    const volVectorField& U = this->U_;
    volScalarField& nut = this->nut_;
    fv::options& fvOptions(fv::options::New(this->mesh_));

    BasicTurbulenceModel::correct();

    volScalarField::Internal divU
    (
        fvc::div(fvc::absolute(this->phi(), U))()()
    );

    tmp<volTensorField> tgradU = fvc::grad(U);
    volScalarField S2(2*magSqr(symm(tgradU())));
    volScalarField::Internal GbyNu(dev(twoSymm(tgradU()())) && tgradU()());
    volScalarField::Internal G(this->GName(), nut()*GbyNu);

    volScalarField OMEGA(sqrt(2*(skew(tgradU()) && skew(tgradU()) )));
    volScalarField STRAIN(sqrt(2*(symm(tgradU()) && symm(tgradU()) )));
    volScalarField::Internal KL=nut()*OMEGA * STRAIN;  //  need more understand
    volScalarField::Internal fr(this->fr());
    if( KatoLaunder_ )
        G = KL ;
    if(!CurvatureCorrect_)
        fr=fr/fr;
    
	volScalarField::Internal XOmega
    (
        sqrt(
                magSqr
                (
                    (skew(tgradU()()) & skew(tgradU()()))
                    && symm(tgradU()())
                     / (pow(beta0Star_*omega_(),3.0))
                )
             )
     );
	volScalarField::Internal fbeta
    (
        (1.0+90*XOmega*1.0)/(1.0+100*XOmega)
    );
    tgradU.clear();

    // Update omega and G at the wall
    omega_.boundaryFieldRef().updateCoeffs();

    volScalarField CDkOmega
    (
        (2*alphaOmega2_)*(fvc::grad(k_) & fvc::grad(omega_))/omega_
    );

    //  implemeted beta
    const volScalarField::Internal XK
    ( 
        (fvc::grad(k_) & fvc::grad(omega_))/(pow(omega_,3.0))
    );

    volScalarField::Internal fbetaStar(1.0*(1+f1_*XK*XK)/(1+f2_*XK*XK)) ;
   

    volScalarField F1(this->F1(CDkOmega));
    volScalarField F23(this->F23());

    // I want to add the implementation to the beta0Star
    //volScalarField ReT(k_ / (this->nu()*omega_));
    //volScalarField beta0Im = beta0Star_*(9.0/8.0+pow4(ReT/8.0))/(1.0 + pow4(ReT/8.0));
    //volScalarField::Internal betaStarIm( betaStartImplement(F1, beta0Im*fbetaStar) );

    // cross-diffusion correction
    volScalarField::Internal betaStarIm( betaStartImplement(F1, beta0Star_*fbetaStar) );
    if(!CrossDiffusion_)
          betaStarIm = this->betaStartImplement(F1, betaStar_);


    //  implemented the beta and betaStart
    {

        // the consideration of vortexCorrection
        volScalarField::Internal beta(this->betaIm(F1, beta2_*fbeta));
        if(!VortexCorrect_)
            beta = this->beta(F1); 
        volScalarField::Internal gamma(this->gamma(F1));  



        // Turbulent frequency equation
        tmp<fvScalarMatrix> omegaEqn
        (
            fvm::ddt(alpha, rho, omega_)
          + fvm::div(alphaRhoPhi, omega_)
          - fvm::laplacian(alpha*rho*DomegaEff(F1), omega_)
         ==
            alpha()*rho()*gamma*fr
           *min
            (
                GbyNu,
                (c1_/a1_)*betaStar_*omega_()//betaStarIm*omega_()
               *max(a1_*omega_(), b1_*F23()*sqrt(S2()))
            )
          - fvm::SuSp((2.0/3.0)*alpha()*rho()*gamma*divU, omega_)
          - fvm::Sp(alpha()*rho()*beta*omega_(), omega_)
          - fvm::SuSp
            (
                alpha()*rho()*(F1() - scalar(1))*CDkOmega()/omega_(),
                omega_
            )
          + Qsas(S2(), gamma, beta)
          + omegaSource()
          + fvOptions(alpha, rho, omega_)
        );

        omegaEqn.ref().relax();
        fvOptions.constrain(omegaEqn.ref());
        omegaEqn.ref().boundaryManipulate(omega_.boundaryFieldRef());
        solve(omegaEqn);
        fvOptions.correct(omega_);
        bound(omega_, this->omegaMin_);
    }

    
    // Turbulent kinetic energy equation
    tmp<fvScalarMatrix> kEqn
    (
        fvm::ddt(alpha, rho, k_)
      + fvm::div(alphaRhoPhi, k_)
      - fvm::laplacian(alpha*rho*DkEff(F1), k_)
     ==
        alpha()*rho()*Pk(G)*fr
      - fvm::SuSp((2.0/3.0)*alpha()*rho()*divU, k_)
      - fvm::Sp(alpha()*rho()*epsilonBykIm(F1,betaStarIm), k_)  //change
      + kSource()
      + fvOptions(alpha, rho, k_)
    );


    kEqn.ref().relax();
    fvOptions.constrain(kEqn.ref());
    solve(kEqn);
    fvOptions.correct(k_);
    bound(k_, this->kMin_);
    //Lt_=nut*STRAIN/(a1_*k_);

    correctNut(S2, F23);
}


// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

} // End namespace Foam

// ************************************************************************* //
