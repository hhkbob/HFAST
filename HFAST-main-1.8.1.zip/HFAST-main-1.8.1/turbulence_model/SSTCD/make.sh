ln -s kOmegaSSTCD.C /home/hhk/OpenFOAM/OpenFOAM-10/src/MomentumTransportModels/momentumTransportModels/lnInclude/kOmegaSSTCD.C
ln -s kOmegaSSTCD.H /home/hhk/OpenFOAM/OpenFOAM-10/src/MomentumTransportModels/momentumTransportModels/lnInclude/kOmegaSSTCD.H
ln -s kOmegaSSTCDBase.C /home/hhk/OpenFOAM/OpenFOAM-10/src/MomentumTransportModels/momentumTransportModels/lnInclude/kOmegaSSTCDBase.C
ln -s kOmegaSSTCDBase.H /home/hhk/OpenFOAM/OpenFOAM-10/src/MomentumTransportModels/momentumTransportModels/lnInclude/kOmegaSSTCDBase.H
