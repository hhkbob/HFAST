#include "runCommandLine.h"

runCommandLine::runCommandLine()
{

}

void runCommandLine::runMsgCommand()
{
    QString qbt;
    qbt = QString::number(this->document()->lineCount());
    qbt = this->document()->findBlockByLineNumber(qbt.toInt()-1).text();
    qbt = qbt.replace(BROWSER, "");
    runBashIn(qbt);

}

void runCommandLine::runBashIn(QString qbt)
{
    QStringList input = qbt.split(" ");
    if(input.size()>1)
    {
        QString name = input[0];
        QString value = input[1];
        if(name.compare("set_work_path")==0)
            fBar->setWorkDirBash(value);
        else if(name.compare("read_bash")==0)
            emit getBashFile(value);
        else if(name.compare("run_case")==0)
            emit runCase(true);
        else if(name.compare("read_project")==0)
            emit readProject();
        else if(name.compare("save_project")==0)
            emit saveProject();
        else
        {
            qDebug()<<"The input command is error: The avalible command:";
            qDebug()<<"read_bash";
            qDebug()<<"read_project";
            qDebug()<<"run_case";
            qDebug()<<"set_work_path";
        }
        qDebug()<<"HFAST<<";
   }
   else
   {
        run->runCommand(qbt);
   }
}

void runCommandLine::readBashFile(QString file)
{
    QString workPath = QDir::currentPath();
    QString path = workPath + "/" + file;
    FILE *data = fopen(path.toLocal8Bit().data(), "r");
    bool formatTrue = false;
    if(data!=NULL)
    {
        char buffer[500];
        char value[500];

        while(!feof(data))
        {
            fscanf(data, "%s", buffer);
            if(QString(buffer).compare("EOF")==0)
            {
                formatTrue = true;
                break;
            }
            fgets(value, 500, data);
            qDebug()<<buffer<<" "<<value;
        }
        if(!formatTrue)
            qDebug()<<"The file should add \"EOF\" in the end";
    }
    else
    {
        qDebug()<<path<<" does not exist";
    }
}
