#include "runPanel.h"
#include "ui_runPanel.h"

runPanel::runPanel(printTool *p, QWidget *w) :
    ui(new Ui::runPanel)
{
    ui->setupUi(this);
    pEvent = p;
    panel = ui->widget;
    count = 1;
    timer = new QTimer;
    connect(timer,SIGNAL(timeout()), this, SLOT(onTimeOut()));
    runBt = ui->runBt;
    read = ui->read;
    run = ui->run;
    save = ui->save;
    opt = new optimize;
}

runPanel::~runPanel()
{
    delete ui;
}

void runPanel::saveFile(int currentStep)
{
    int step = ui->timeEdit->text().toInt();
    if(step*count<=currentStep && ui->var->isChecked())
    {
        QString path = QDir::currentPath();
        QString file = path + "/system/controlVar.H";
        FILE *data = fopen(file.toLocal8Bit().data(), "w");
        if(data!=NULL)
        {
            double varMax = ui->maxEdit->text().toDouble();
            double varMin = ui->minEdit->text().toDouble();
            int MaxStep = ui->maxTimeEdit->text().toInt();
            {
                double var = max(varMin, min(varMax, varMax/(1.0*MaxStep)*currentStep));
                fprintf(data, "var  %g;", var);
                fclose(data);
                count++;
            }
        }
    }
}

void runPanel::onTimeOut()
{
    QString command = ui->runEdit->text();
    pEvent->saveTool->runCommandNoWindow(command);
}

void runPanel::timeBegin()
{
    if(run->isChecked())
    {
        timer->setInterval(30*1000);
        timer->start();
    }
}

bool runPanel::useOpt()
{
    return ui->useOpt->isChecked();
}

bool runPanel::distributedTask()
{
    int coreNum = ui->coreNum->value();
    int task = ui->task->value();
    QString folderName;
    QString path = QDir::currentPath();
    QString cmd = path +"/TASK";
    createFolder(cmd);
    qDebug()<<"make folder done";
    FILE *data;
    for(int i=0; i<task; i++)
    {
        bool su;
        folderName = "task"+QString::number(i);
        cmd = path + "/TASK/"+folderName;
        createFolder(cmd);
        qDebug()<<"make folder done";
        // copy the 0, system, and constant
        su = copyFolder("0", folderName, true);
        if(!su) return su;
        su = copyFolder("system", folderName, true);
        if(!su) return su;
        su = copyFolder("constant", folderName, true);
        if(!su) return su;
        //copy run.sh
        copyFile("runTask.sh", folderName, true);
        if(!su) return su;
        copyFile("refData.txt", folderName, true);
        if(!su) return su;
        //write parallel file
        QString file = path + "/TASK/"+folderName+"/system/coreControl.H";
        data = fopen(file.toLocal8Bit().data(), "w");
        if(data!=NULL)
        {
            fprintf(data, "core  %d;", coreNum);
            fclose(data);
        }
        else
        {
            qDebug()<<"cannot create the coreControl.H in the single task file";
            return false;
        }
    }
    return true;
}

void runPanel::runClicked()
{
    optInf.line = ui->sampleData->text();
    optInf.process = ui->coreNum->value();
    optInf.task = ui->task->value();
    optInf.ref = ui->RefData->text();
    optInf.varIdx = ui->varBox->currentIndex();
}

bool runPanel::copyFolder(QString name, QString folderName, bool coverFileIfExist)
{
    QString path = QDir::currentPath();
    QString need = path +"/"+ name + "  ";
    QString desNeed = path + "/TASK/"+folderName+ "/" + name;
    QDir dir(desNeed);
    if(dir.exists())
    {
        qDebug()<<"The folder: "<<desNeed<<" is exists, please delete";
        return false;
    }
    QString cmd = "cp -rf " + need + desNeed;
    system(cmd.toLocal8Bit().data());

   /* QDir srcDir(need);
    QDir dstDir(desNeed);
    if (!dstDir.exists()) { //目的文件目录不存在则创建文件目录
        if (!dstDir.mkdir(dstDir.absolutePath()))
            return false;
    }
    QFileInfoList fileInfoList = srcDir.entryInfoList();
    foreach(QFileInfo fileInfo, fileInfoList) {
        if (fileInfo.fileName() == "." || fileInfo.fileName() == "..")
            continue;

        if (fileInfo.isDir()) {    // 当为目录时，递归的进行copy
            if (!copyFolder(fileInfo.filePath(),dstDir.filePath(fileInfo.fileName()),coverFileIfExist))
                return false;
        }
        else {            //当允许覆盖操作时，将旧文件进行删除操作
            if (coverFileIfExist && dstDir.exists(fileInfo.fileName())) {
                dstDir.remove(fileInfo.fileName());
            }
            /// 进行文件copy
            if (!QFile::copy(fileInfo.filePath(), dstDir.filePath(fileInfo.fileName()))) {
                return false;
            }
        }
    }*/
    return true;
}

bool runPanel::copyFile(QString name, QString folderName, bool coverFileIfExist)
{
    QString path = QDir::currentPath();
    QString srcPath = path +"/"+ name + "  ";
    QString dstPath = path + "/TASK/"+folderName+ "/" + name;
    QDir dir(dstPath);
    if(dir.exists())
    {
        qDebug()<<"The file "<<dstPath<<" exists, please delete";
        return false;
    }
    QString cmd = "cp -rf " + srcPath +" " + dstPath;
    system(cmd.toLocal8Bit().data());
    /*srcPath.replace("\\", "/");
    dstPath.replace("\\", "/");
     if (srcPath == dstPath) {
         return true;
     }

     if (!QFile::exists(srcPath)) {  //源文件不存在
         return false;
     }

     if (QFile::exists(dstPath)) {
         if (coverFileIfExist) {
             QFile::remove(dstPath);
         }
     }

     if (!QFile::copy(srcPath, dstPath)){
         return false;
     }*/
     return true;
}

bool runPanel::createFolder(QString name)
{
    QDir *dir = new QDir(name);
    bool exist = dir->exists();
    if(!exist)
    {
        bool OK = dir->mkdir(name);
        if(OK)
            return true;
        else
        {
            qDebug()<<"cannot create the folder: "<<name;
        }
    }
    return false;
}

QList<QStringList> runPanel::getOptimizeResult()
{
    QString Max = ui->OpMaxEdit->text();
    QString Min = ui->OpMinEdit->text();
    QString interval = ui->interval->text();
    QStringList paraMax = Max.split(" ");
    QStringList paraMin = Min.split(" ");
    if(paraMax.size()!=paraMin.size() || paraMax.isEmpty() || paraMin.isEmpty())
    {
        Mess mes;
        mes.Fun = "void runPanel::getOptimizeResult()";
        mes.Head = "runPanel.h";
        mes.Loc = "use Optimize";
        mes.title = "Warnning";
        mes.Mess = "the min and max number is not equal. nothing will do";
        HError HFASTError;
        HFASTError.HFASTWarning(mes);
        QList<QStringList> kk;
        return kk;
    }
    else if(interval.toInt()<1 || interval.isEmpty())
    {
        Mess mes;
        mes.Fun = "void runPanel::getOptimizeResult()";
        mes.Head = "runPanel.h";
        mes.Loc = "use Optimize";
        mes.title = "Warnning";
        mes.Mess = "the interval must be larger than 1. nothing will do";
        HError HFASTError;
        HFASTError.HFASTWarning(mes);
        QList<QStringList> kk;
        return kk;
    }
    QList<QStringList> range;
    for(int i=0; i<paraMax.size(); i++)
    {
        QStringList lst;
        lst.append(paraMin[i]);
        lst.append(paraMax[i]);
        range.append(lst);
    }
    QList<QStringList> scheme = opt->createSchemes(range, interval.toInt());
    if(scheme.isEmpty())
        return scheme;
    QList<int> num = opt->randomNum(scheme.size());
    QList<QStringList> schemes;

    QString path = QDir::currentPath();
    QString file = path + "/optimize.txt";
    FILE *data = fopen(file.toLocal8Bit().data(), "w");
    if(data!=NULL)
    {
         for(int j=0; j<scheme.size(); j++)
         {
             schemes.append(scheme[num[j]]);
             for(int k=0; k<range.size(); k++)
             {
                 fprintf(data, "%s ", scheme[num[j]][k].toLocal8Bit().data());
             }
             fprintf(data, "\n");
         }
         fclose(data);
    }
    return schemes;
}
