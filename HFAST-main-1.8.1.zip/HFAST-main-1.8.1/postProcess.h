#ifndef POSTPROCESS_H
#define POSTPROCESS_H

#include <QObject>
#include <QMenu>
#include "HFASTAction.h"
#include "printTool.h"
#include "controlPanel.h"

class postProcess : public QObject
{
    Q_OBJECT
public:
    explicit postProcess(printTool *p, QMenu *menu, controlPanel *ctrol);
    QStringList app;
    QStringList appField;
    HFASTAction **action;
    HFASTAction **actionField;
    printTool *pEvent;
    QMenu   **pMenu;
    controlPanel *ctr;
    QString appName;

private:
    QStringList read(QString file);

signals:

public slots:
    void runCommand(int idx, QString cmd);
    void runFieldCommand(int idx, QString cmd);
    void recieveApp(QString appName);
};

#endif // POSTPROCESS_H
