#ifndef MSGHANDLE_H
#define MSGHANDLE_H

#include <QObject>

class msgHandle : public QObject
{
    Q_OBJECT
public:
    //explicit msgHandle(QObject *parent = nullptr);
    static msgHandle *instance();

signals:
    void message(QtMsgType type, const QString &msg);
private:
    static msgHandle *sInstance;
    msgHandle();

public slots:
};

#endif // MSGHANDLE_H
