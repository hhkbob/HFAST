#ifndef BASICDEFINE_H
#define BASICDEFINE_H

#define VERSION 10

#define BROWSER "HFAST<<"
#define JSONFILE "userPro.json"
#define MATERIAL_NUM 6

#define SIMPLE 1
#define HIERA 2
#define SCOTCH 4
#define METIC 3
#define MAXIMUMVIEWPANELWIDTH 400

#define WCONSTANT 30

struct mStr
{
    char name[50];
    int cKey;
    int index;
    char cName[WCONSTANT][50];
    double vName[WCONSTANT];
};

enum
{
    NU=0,
    RHO=1,
    BETA=2,
    T0=3,
    PR=4,
    PRt=5,
    MOWEIGHT=6,
    CP=7,
    HF=8,
    CV=9
};

struct GRAVITY
{
    QString gxyz[3];
};

struct PARADICT
{
    int num;
    int mark;
    QString simple[4];
    QString hiera[5];
    QString metic[3];
};

struct MATERIAL
{
    char name[50];
    int index;
    double materials[10];
};

struct THERMAL
{
    QStringList type;
    QStringList value;
    bool change;
    bool heat;
};

struct SCHEME
{
    QString name;
    QString first;
    QString scheme;
    QString other;
    int firstIndex;
    int schemeIndex;
};

struct pSCHEME
{
    QList<SCHEME> ddt;
    QList<SCHEME> div;
    QList<SCHEME> grad;
    QList<SCHEME> lap;
    QList<SCHEME> inter;
    QList<SCHEME> snG;
};

struct unit
{
    QString name;
    QString value;
};

struct CTRL
{
    int appSelect;
    int appIndex;
    int startFromIndex;
    int stopAtIndex;
    int writeControlIndex;
    bool runModi;
    bool Co;
    QString keyBox[3];
    QString appName;
    QString list[5];
    int solverDict;
};

#define C_SIMPLE 0
#define C_PIMPLE 1
#define C_PISO 2
#define C_PONTENTIAL 3

struct RESIDUAL
{
    bool monitor;
    QString para;
    bool line;
    QList<unit> residual;
    int ReNum;
    QString sampleTime;
    QString sampleCommand;

};

struct LINEGRAPH
{
    QString points[6];
    QString field;
    QString type;
    QString axis;
    int typeIndex;
    int axisIndex;
};

struct SURFACEGRAPH
{
    QString points[3];
    QString field;
    QString normal;
    QString name;
};

struct pltPROPERTY
{
    QStringList x;
    QStringList y;
    QString xLabel;
    QString yLabel;
    QString name;
};

struct SOLUTION
{
    QString value[6];
    bool use;
    QString name;
    QString solver;
    QString smoother;
    QString pre;
};

struct SOLVERSETTING
{
    QStringList value;
    int solverDict;
    int len;
};

#define simpleNum 5
#define pimpleNum 8

struct RELAXATION
{
    QString len;
    QStringList value;
    QStringList name;
    QString additional;
};

struct BOUNDARY
{
    QString totalBdr;
    QList<QStringList> value;
    QList<QStringList> paraName;
    QList<QStringList> paraValue;
    QList<QStringList> paraIndex;
    QStringList internal;
};

struct DEFINEPARA
{
    QString name;
    QString field;
};

#endif // BASICDEFINE_H


