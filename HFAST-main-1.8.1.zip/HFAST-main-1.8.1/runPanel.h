#ifndef RUNPANEL_H
#define RUNPANEL_H

#include <QWidget>
#include "printTool.h"
#include "QTimer"
#include "optimize.h"

namespace Ui {
class runPanel;
}

class runPanel : public QWidget
{
    Q_OBJECT

public:
    explicit runPanel(printTool *p, QWidget *w);
    ~runPanel();
    printTool *pEvent;
    int count;
    QTimer *timer;
    optimize *opt;

public:
    void saveFile(int currentStep);

    void timeBegin();
    QList<QStringList> getOptimizeResult();
    bool useOpt();
    bool distributedTask();
    QPushButton *runBt;
    QCheckBox *read;
    QCheckBox *run;
    QCheckBox *save;
    QWidget *panel;
    struct optInfs
    {
        int task;
        int process;
        QString line;
        QString ref;
        int varIdx;
    };

    optInfs optInf;
    void runClicked();

public:
    Ui::runPanel *ui;

    bool copyFolder(QString name, QString folderName, bool coverFileIfExist);
    bool copyFile(QString name, QString folderName, bool coverFileIfExist);
    bool createFolder(QString name);

public slots:
    void onTimeOut();
};

#endif // RUNPANEL_H
