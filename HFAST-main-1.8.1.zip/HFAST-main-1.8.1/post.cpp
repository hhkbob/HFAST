#include "post.h"
#include "ui_post.h"
#include <QCoreApplication>
//#include "functions.h"

//#include "interpolation.H"
//#include "incompressibleMomentumTransportModels.H"
//#include "viscosityModel.H"
//#include "simpleControl.H"
//#include "fvModels.H"
//#include "fvConstraints.H"

post::post(printTool *p, QTabWidget *tabEdit):
    ui(new Ui::post)
{
    ui->setupUi(this);
    pEvent = p;
    tab = tabEdit;
    contour = new HFASTPlot;
    connect(ui->lineName, SIGNAL(activated(int)),
            this, SLOT(lineEditClick(int)));
    connect(this, SIGNAL(lineEditTrigger(QString,int)),
            this, SLOT(showLineDetail(QString,int)));
    connect(ui->LinePlotBt, SIGNAL(clicked(bool)),
            this, SLOT(plotXYTrigger()));
    hPlot = NULL;
}

post::~post()
{
    delete ui;
}

bool post::readRawData(QString name, QString timeStep)
{
    QString workPath = QDir::currentPath();
    QString file = workPath +"/postProcessing/"+name+"/"
            +timeStep+"/"+name+".xy";
    generalFunc ge;
    data1 = ge.readXYData(file);
    if(data1.isEmpty())
        return false;
    return true;
}

QStringList post::getTimeName(QString path, QString name)
{
    generalFunc ge;
    QStringList time = ge.getTimeName(path, name);
    return time;
}

post::DATA post::readExterNalFile(QString file)
{
    DATA temp;
    temp.sucess = false;
    QFile re(file);
    if(!re.open(QIODevice::ReadOnly | QIODevice::Text))
    {
        //qCritical() <<"Error cannot open file: "<< file;
        return temp;
    }
    QTextStream in(&re);
    in.setCodec("UTF-8");

    QStringList var;
    bool nameExist = false;
    while(!in.atEnd())
    {
        QString line = in.readLine().toUtf8();
        QStringList lineLst = line.split(QRegExp(" "));
        if(lineLst[0]=="#")
        {
            for(int i=1; i<lineLst.size(); i++)
                if(!lineLst[i].isEmpty())
                      var.append(lineLst[i]);
            nameExist = true;
            break;
        }
    }
    if(nameExist)
    {
       temp.variables = var;
       temp.sucess = true;
    }
    else
    {
        qDebug()<<"the external file cannot find the name items";
        return temp;
    }

    //-- read data
    QStringList dataTmp[var.size()];
    QList<QStringList> Tmp2;
    QStringList space;
    space<<" "<<"\t";
    int spaceIndex = 0;
    bool dataFormatRight = false;
    while(!in.atEnd())
    {
        QString line = in.readLine().toUtf8();
        QStringList lineLst = line.split(space[spaceIndex]);
        //qDebug()<< lineLst;
        //lineLst.removeAll(QString(""));
        if(lineLst.size()!=temp.variables.size())
        {
            for(int i=1; i<space.size(); i++)
            {
                lineLst = line.split(space[i]);
                if(lineLst.size()==temp.variables.size())
                {
                    spaceIndex = i;
                    dataFormatRight = true;
                    break;
                }
            }
        }
        if(dataFormatRight)
        {
            for(int i=0; i<temp.variables.size(); i++)
            {
                bool OK;
                double tr = lineLst[i].toDouble(&OK);
                if(OK)
                {
                   dataTmp[i].append(lineLst[i]);
                }
                else
                {
                    break;
                }
            }
        }
    }
    re.close();
    if(dataFormatRight)
    {
        for(int i=0; i<temp.variables.size(); i++)
        {
            Tmp2.append(dataTmp[i]);
        }
        temp.data1 = Tmp2;
        temp.sucess = true;
        return temp;
    }
    else
    {
        temp.sucess = false;
        return temp;
    }
}

void post::refreshComboBoxItem(QComboBox *box, QStringList lst)
{
    int count = box->count();
    for(int i=0; i<count; i++)
        box->removeItem(0);
    box->addItems(lst);
}

/*double post::getSpecificPointValue(int argc, char *argv[], point p)
{
     timeSelector::addOptions();
     #include "addRegionOption.H"
     #include "setRootCase.H"
     #include "createTime.H"
     instantList timeDirs = timeSelector::select0(runTime, args);
     #include "createNamedMesh.H"

    // for(int timeI=0; timeI<timeDirs.size(); timeI++)
     //{
         volVectorField U
         (
            IOobject
            (
                "U",
                runTime.timeName(),
                mesh,
                IOobject::MUST_READ,
                IOobject::AUTO_WRITE
            ),
            mesh
        );
    //}

    dictionary interpolationDict = mesh.schemes().subDict("interpolationSchemes");
    autoPtr<interpolation<Foam::vector>> Cl_int = interpolation<Foam::vector>::New(interpolationDict, U);


    contour->setInteractions(QCP::iRangeDrag|QCP::iRangeZoom);
    contour->axisRect()->setupFullAxesBox(true);

    QCPColorMap *colorMap = new QCPColorMap(contour->xAxis, contour->yAxis);
    int nx = 200;
    int ny = 200;
    colorMap->data()->setSize(nx, ny);
    colorMap->data()->setRange(QCPRange(0, 0.8), QCPRange(0, 0.08));
    double x1, y1, z;
    //char *argv[1]={"HFAST"};
    for (int xIndex=0; xIndex<nx; ++xIndex)
    {
            for(int yIndex=0; yIndex<ny; ++yIndex)
            {
                colorMap->data()->cellToCoord(xIndex, yIndex, &x1, &y1);
                point p(x1, y1, 0);
                label cellJ = mesh.findCell(p);
                Foam::vector value = Cl_int->interpolate(p, cellJ);
                colorMap->data()->setCell(xIndex, yIndex, mag(value));
            }
    }
    colorMap->setGradient(QCPColorGradient::gpPolar);
    colorMap->rescaleDataRange(true);
    contour->rescaleAxes();
    contour->replot();
    bool exist=false;
    for(int i=0; i<tab->count(); i++)
    {
        QString nameTab = tab->tabText(i);
        if(nameTab.compare("contour")==0)
        {
            exist=true;
            break;
        }
    }
    if(!exist)
        tab->addTab(contour, "contour");

    return 0;
}*/

void post::lineEditClick(int index)
{
    {
        char buffer[50];
        sprintf(buffer, "line%d", index);
        emit lineEditTrigger(buffer, index);
    }
}

void post::showLineDetail(QString name, int idx)
{
    //- read at the latestTime results
    QString workPath = QDir::currentPath();
    QString path = workPath + "/postProcessing/";
    QStringList time = getTimeName(path, name);
    timeName = time;
    readRawData(name, time[time.size()-1]);
    if(timeName.size()>0)
    {
        refreshComboBoxItem(ui->xAxis, variables);
        refreshComboBoxItem(ui->yAxis, variables);
        refreshComboBoxItem(ui->timeName, time);
        ui->timeName->setCurrentIndex(time.size()-1);
    }
}

void post::plotXYTrigger()
{
    if(ui->timeName->count()>0 && ui->xAxis->count()>0 && ui->yAxis->count()>0)
    {
        QString time = ui->timeName->currentText();
        QString xLabel = ui->xAxis->currentText();
        QString yLabel = ui->yAxis->currentText();
        QString name = ui->lineName->currentText();

        // read data
        int idx = ui->lineName->currentIndex();
        if(idx>0)
        {
            bool OKX, OKY;
            double scaleX = ui->scaleX->text().toDouble(&OKX);
            double scaleY = ui->scaleY->text().toDouble(&OKY);
            if(ui->scaleX->text().isEmpty() || !OKX) scaleX = 1;
            if(ui->scaleY->text().isEmpty() || !OKY) scaleY = 1;
            readRawData(name, time);
            QStringList x = data1[ui->xAxis->currentIndex()];
            QStringList y = data1[ui->yAxis->currentIndex()];

            hPlot[idx]->clearPlottables();
            hPlot[idx]->xAxis->setLabel(xLabel);
            hPlot[idx]->yAxis->setLabel(yLabel);
            hPlot[idx]->plotXY(x, y, 0, "present", scaleX, scaleY);

            // read reference
            DATA dat = readExterNalFile(externalFile);
            if(dat.sucess)
            {
                for(int i=0; i<dat.data1.size(); i=i+2)
                {
                    hPlot[idx]->plotXY(dat.data1[i], dat.data1[i+1], i+1, dat.variables[i+1], 1.0, 1.0);
                }
            }

            int tabIndex = tab->count();
            bool exist=false;
            for(int i=0; i<tabIndex; i++)
            {
                if(tab->tabText(i).compare(name)==0)
                {
                    exist = true;
                    break;
                }
            }
            if(!exist)
                 tab->addTab(hPlot[idx], name);
        }
    }
    else
    {
        qDebug()<<"cannot find the data";
    }
}

void post::definePanel(printTool *p)
{
    QList<LINEGRAPH> lineGraph  = p->saveTool->lg;
    QStringList nameLst;
    char buffer[50];
    for(int i=0; i<lineGraph.size(); i++)
    {
        sprintf(buffer, "line%d", i);
        nameLst.append(buffer);
    }
    refreshComboBoxItem(ui->lineName, nameLst);
    if(nameLst.size()>0 && hPlot!=NULL)
    {
        delete hPlot;
    }
    if(nameLst.size()>0 && hPlot==NULL)
    {
        hPlot = new HFASTPlot*[nameLst.size()];
        for(int i=0; i<nameLst.size(); i++)
            hPlot[i] = new HFASTPlot;
    }

    // surface
    QList<SURFACEGRAPH> sampleSur = p->saveTool->sampleSur;
    int count = ui->surfaceName->count();
    for(int i=0; i<count; i++)
    {
        ui->surfaceName->removeItem(0);
    }
    for(int i=0; i<sampleSur.size(); i++)
    {
        ui->surfaceName->addItem(sampleSur[i].name);
    }
}

void post::plotContour()
{
    QString name = ui->surfaceName->currentText();
    QString time = ui->surfaceTime->currentText();
    QString workPath = QDir::currentPath();
    QString file = workPath +"/postProcessing/"+name+"/"
            +time+"/"+name+".xy";
    int xy[2];
    int index = ui->surfaceName->currentIndex();
    int axis = pEvent->saveTool->sampleSur[index].normal.toInt();
    for(int i=0; i<3;i++)
    {
        if(axis==i)
            continue;
        xy[i] = i;
    }
    int valueZ = ui->surfacePara->currentIndex();
    QString para = ui->surfacePara->currentText();
    QString str = workPath + "/contour.py";
    FILE *data = fopen(str.toLocal8Bit().data(), "w");
    QString templatePath = QCoreApplication::applicationDirPath() + "/template";
    if(data!=NULL)
    {
        fprintf(data, "import sys\n");
        fprintf(data, "sys.path.insert(0, '%s')\n", templatePath.toLocal8Bit().data()); 
        fprintf(data, "import contourTemp as ct\n\n");
        fprintf(data, "ct.plotFoam('%s', %d, %d, %d, '%s', '%s', '%s')",
                file.toLocal8Bit().data(),
                xy[0], xy[1], valueZ,
                para.toLocal8Bit().data(),
                "x", "y");
        fclose(data); 
        //basic run;
        //run.runCommand("conda activate && python contour.py");
    }

   // readRawData(name, time);
   /* int size = data1[0].size();
    if(size>1e5)
    {
        qDebug()<<"too many data";
        return;
    }
    QList<QStringList> xyPlane;
    for(int i=0; i<3; i++)
    {
        if(axis==i)
            continue;
        xyPlane.append(data1[i]);
    }
    contour->plotPlane(xyPlane[0], xyPlane[1], data1[valueZ]);
    bool exist=false;
    for(int i=0; i<tab->count(); i++)
    {
        QString nameTab = tab->tabText(i);
        if(nameTab.compare("contour")==0)
        {
            exist=true;
            break;
        }
    }
    if(!exist)
        tab->addTab(contour, "contour");*/

}

void post::on_surfaceName_activated(const QString &arg1)
{
    QString workPath = QDir::currentPath();
    QString path = workPath + "/postProcessing/";
    QStringList time = getTimeName(path, arg1);
    refreshComboBoxItem(ui->surfaceTime, time);
    ui->surfaceTime->setCurrentIndex(time.size()-1);
}

void post::on_surfaceTime_activated(const QString &arg1)
{
    // get variables
    readRawData(ui->surfaceName->currentText(), arg1);
    refreshComboBoxItem(ui->surfacePara, variables);
}

void post::on_surfacePlotBt_clicked()
{
    if(ui->surfaceName->count()>0 && ui->surfaceTime->count()>0 && ui->surfacePara->count()>0)
    {
        plotContour();
    }
    else
    {
        qDebug()<<"no data to plot";
    }
}

void post::on_dataReadBt_clicked()
{
    QString workPath = QDir::currentPath();
    //  打开文件对话框，选择路径
    externalFile = QFileDialog::getOpenFileName(
                this,
                tr("Please choose a reference raw file"),
                workPath,
                tr("All files (*.*)")
                );
    if(externalFile.isEmpty())
    {
        return;
    }
}

void post::on_dataDelBt_clicked()
{
    QString tmp;
    externalFile = tmp;
}
