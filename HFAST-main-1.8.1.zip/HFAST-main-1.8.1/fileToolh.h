#ifndef FILETOOLH_H
#define FILETOOLH_H

#include "printTool.h"
#include <QAction>
#include <QMenu>
#include "defineFields.h"
#include "HFASTAction.h"

class fileToolh  : public QWidget
{
    Q_OBJECT
public:
    explicit fileToolh(printTool *p, QMenu *menu);
    printTool *pEvent;
    defineFields *dPanel;


    QAction *Allclean;
    HFASTAction **action;
    QAction *define;
    QAction *plotResiudal;
    QAction *repeat;

private:
    QStringList read(QString file);

private slots:
    void cleanTrigger();
    void defineTrigger();
    bool runCommand(int idx, QString cmd);
    void repeatTrigger();
};

#endif // FILETOOLH_H
