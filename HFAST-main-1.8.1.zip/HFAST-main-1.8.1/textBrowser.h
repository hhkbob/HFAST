#ifndef TEXTBROWSER_H
#define TEXTBROWSER_H

#include "msgHandle.h"
#include <QPlainTextEdit>
#include <QTextBlock>
#include <QDebug>
#include <QKeyEvent>
#include "basic.h"
#include <stdlib.h>
#include <string.h>

class textBrowser : public QPlainTextEdit
{
    Q_OBJECT
public:
    enum MessageLevel
    {
        NORMAL_LEVAL = 0,
        WARNING_LEVEL = 1,
        ERROR_LEVAL = 2
    };
    basic *run;
    QString input;

    explicit textBrowser(QWidget *parent = nullptr);
    void outputMessage(const MessageLevel &level, const QString &msg);


signals:
    void enterPress();
    void runCase(bool);
    void getBashFile(QString);
    void readProject();
    void saveProject();

protected:
    virtual void keyPressEvent(QKeyEvent *e);
    virtual void runMsgCommand();

public slots:
    void outputMessage(QtMsgType type, const QString &msg);

    //bool eventFilter(QObject *, QEvent *);
};

#endif // TEXTBROWSER_H
