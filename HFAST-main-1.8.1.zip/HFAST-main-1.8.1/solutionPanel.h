#ifndef SOLUTIONPANEL_H
#define SOLUTIONPANEL_H

#include <QObject>
#include "printTool.h"
#include <QSplitter>

class linePara;
class paraGroup;

class solutionPanel : public QObject
{
    Q_OBJECT
public:
    explicit solutionPanel(printTool *p, QWidget *w);
    paraGroup **sGroup;
    QVBoxLayout *vLayout;
    QVBoxLayout *wLayout;
    QWidget *sPanel;
    QWidget *rePanel;
    QPlainTextEdit *add;
    printTool *pEvent;
private:
    QTabWidget *tab;
    QLabel **reName;
    QLineEdit **reValue;
    QVBoxLayout *reVLayout;
    QHBoxLayout **reHLayout;
    int mSelect;
    int count;
    RELAXATION relaxation;
    int sGroupNum;

    void deleteLayout(printTool *pEvent);
    void createLayout(printTool *pEvent);
    QStringList getVariables(printTool *p);

signals:

public slots:
    void save();
    void read(printTool *p);
    void defineRe(printTool *pEvent);
};

class linePara : public QWidget
{
    Q_OBJECT
public:
    explicit linePara(QObject *parent = nullptr);
    QLabel *name[6];
    QLineEdit *value[3];
    QComboBox *keyBox[3];
    SOLUTION soluteSave;
private:
    QHBoxLayout *hLayout[6];
    QVBoxLayout *vLayout;
public:
    void saveEvery();
    void readEvery();
};

class paraGroup : public QWidget
{
    Q_OBJECT
public:
    paraGroup();
    QLineEdit *para;
    linePara *line;
    QPushButton *Button;
    SOLUTION soluteSave;
    QPushButton *saveBt;
    QPushButton *delBt;
    bool use;
private:
    QHBoxLayout *hLayout;
public slots:
    void save();
    void triggered();
    void clearPanel();
};

#endif // SOLUTIONPANEL_H
