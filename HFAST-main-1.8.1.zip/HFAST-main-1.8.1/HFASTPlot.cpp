#include "HFASTPlot.h"
#include "ui_HFASTPlot.h"

HFASTPlot::HFASTPlot() :
    ui(new Ui::HFASTPlot)
{
    ui->setupUi(this);
    color.append(Qt::black);
    color.append(Qt::red);
    color.append(Qt::darkBlue);
    color.append(Qt::darkCyan);
    color.append(Qt::darkMagenta);
    color.append(Qt::darkGreen);
    color.append(Qt::gray);

    line.append(Qt::SolidLine);
    line.append(Qt::DashLine);
    line.append(Qt::DotLine);
    line.append(Qt::DashDotLine);
    line.append(Qt::DashDotDotLine);
}

HFASTPlot::~HFASTPlot()
{
    delete ui;
}

void HFASTPlot::plotXY(QStringList x, QStringList y, int idx, QString name, double scaleX, double scaleY)
{
     QVector<double> DataX(x.size());
     QVector<double> DataY(y.size());
     this->addGraph();

     for(int i=0; i<x.size(); i++)
     {
         DataX[i] = x[i].toDouble()*scaleX;
         DataY[i] = y[i].toDouble()*scaleY;
     }
     this->graph(idx)->setData(DataX, DataY);
     //this->xAxis->setLabel("x");
     //this->yAxis->setLabel("y");
     this->graph(idx)->setName(name);

     if(idx<color.size())
     {
         QPen pen;
         if(idx<line.size())
         {
             pen.setColor(color[idx]);
             pen.setStyle(line[idx]);
         }
         else
         {
             pen.setColor(color[idx]);
             pen.setStyle(line[0]);
         }
         this->graph(idx)->setPen(pen);
     }
     else
     {
         QPen pen(color[0], line[2]);
         this->graph(idx)->setPen(pen);
     }

     this->legend->setVisible(true);

     this->rescaleAxes(true);

     this->replot();
}

void HFASTPlot::plotPlane(QStringList x, QStringList y, QStringList value)
{
    this->setInteractions(QCP::iRangeDrag|QCP::iRangeZoom); // this will also allow rescaling the color scale by dragging/zooming
    this->axisRect()->setupFullAxesBox(true);

    // set up the QCPColorMap:
    QCPColorMap *colorMap = new QCPColorMap(this->xAxis, this->yAxis);
    //int nx = 200;
    //int ny = 200;
    colorMap->data()->setSize(x.size()/2, y.size()/2);
    colorMap->data()->setRange(QCPRange(0, 2), QCPRange(0, 0.08));
    for (int xIndex=0; xIndex<x.size(); ++xIndex)
    {
        colorMap->data()->setCell(x[xIndex].toDouble(), y[xIndex].toDouble(), value[xIndex].toDouble());
    }
    colorMap->setGradient(QCPColorGradient::gpPolar);
    colorMap->rescaleDataRange(true);
    this->rescaleAxes();
    this->replot();

}
