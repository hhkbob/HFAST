#include "HFAST.h"
#include "ui_HFAST.h"
#include "foamInit.h"
//#include "omp.h"


HFAST::HFAST(bool window) :
    ui(new Ui::HFAST)
{
    ui->setupUi(this);
    this->setAttribute(Qt::WA_QuitOnClose, true);
    QString qss;
    FILE *data = fopen("./resources/skin.dat", "r");
    char skin[50];
    if(data!=NULL)
        fscanf(data, "%s", skin);
    else
    {
        qDebug()<<"do not find the skin.dat in resources folder;";
    }
    QString name = QString("./resources/")+skin;

    QFile file(name);
    if(file.open(QFile::ReadOnly))
    {
        qss = QLatin1String(file.readAll());
        qApp->setStyleSheet(qss);
    }

    TimeStep = 1;

    win = window;

    //  初始化界面
    initApp();

    //  添加布局
    addLayout();

    //  检查算例是否存在

    //init.newCase("E:\\case", "HFAST::HFAST(QWidget *parent) :QMainWindow(parent),ui(new Ui::HFAST)");
}

HFAST::~HFAST()
{
    delete init;
    delete tabEdit;
    delete mesView;
    delete runButton;
    delete checkButton;
    delete generalButton;
    delete modelButton;
    delete timeCtr;
    delete schemeCtr;
    delete solutionCtr;
    delete materialButton;
    delete bGroup;
    delete viewGroup;
    delete gPanelPage;
    delete mPanelPage;
    delete mtPanelPage;
    //delete ctrPanelPage;
    delete wholeWidget;
    //delete view;
    delete File;
    delete Tool;
    delete fileBar;
    delete pEvent;
    delete status;
    delete time;
    delete estimateTime;
    delete sLayout;
    delete sGroup;
    //delete fTool;
    delete ui;
}

void HFAST::initApp()
{
    init = new foamInit;

    init->setup->exec();

    init->checkFoamEvn();

    isReady = false;

    //  保存项目
    pEvent = new printTool;
    
    pEvent->saveTool->Version = init->setup->currentVersion;
    pEvent->saveTool->bashrc = init->setup->bashrcPath;

    //  创建菜单栏
    File = this->menuBar()->addMenu(tr("File(F)"));
    Tool = this->menuBar()->addMenu(tr("Tools(T)"));
    postTool = this->menuBar()->addMenu(tr("Post(P)"));

    //  放置菜单--File
    fileBar = new fileToolBar(pEvent, File);
    fTool = new fileToolh(pEvent, Tool);

    timer = new QTimer;
    timer->setInterval(1000);
    connect(timer,SIGNAL(timeout()), this, SLOT(onTimeOut()));

    //
    time = new QLabel(tr("Time: "));
    estimateTime = new QLabel(tr("Total Time: "));
    status = new QLabel(tr("Not Ready"));
    status->setMinimumSize(200, 20);
    status->setMaximumSize(200, 20);
    status->setStyleSheet("background-color:rgb(250, 192, 61)");
    ui->statusBar->setStyleSheet("background-color:rgb(44,47,59)");
    QPalette pe;
    pe.setColor(QPalette::WindowText, Qt::white);
    //status->setPalette(pe);
    time->setPalette(pe);
    estimateTime->setPalette(pe);

    sLayout = new QHBoxLayout;
    sGroup = new QGroupBox;
    sLayout->addWidget(status);
    sLayout->addWidget(time);
    sLayout->addWidget(estimateTime);
    sLayout->setMargin(0);
    sGroup->setLayout(sLayout);
    sGroup->setMinimumHeight(20);
    sGroup->setMaximumHeight(20);
    status->setMinimumWidth(200);
    time->setMinimumWidth(100);
    estimateTime->setMinimumWidth(100);
    sGroup->setStyleSheet("QGroupBox{ margin-top:0px;} QGroupBox:title {margin-top: 0px;}");
    sGroup->setStyleSheet("border:none");

    ui->statusBar->addWidget(sGroup);
    connect(fileBar, SIGNAL(changeDir(QString)),this, SLOT(statusChange(QString)));
}

void HFAST::addLayout()
{
    //  创建网格布局
    //gridLayout = new QGridLayout;
    vLayout = new QVBoxLayout;
    hLayout = new QHBoxLayout;
    viewLayout = new QHBoxLayout;
    stackLayout = new QStackedLayout;

    tabEdit = new QTabWidget;
    view = new QDockWidget(tr(""));
    Splitter1 = new QSplitter(Qt::Horizontal);
    Splitter2 = new QSplitter(Qt::Vertical);
    viewGroup = new QGroupBox(tr(""));
    mesView = new textBrowser;
    viewGroupLayout = new QVBoxLayout;

    bGroup = new QButtonGroup;

    runButton = new QPushButton(tr("Run"));  //  运行按钮-运行命令行
    checkButton = new QPushButton(tr("ParaView")); //  检查网格质量
    generalButton = new QPushButton(tr("General"));
    modelButton = new QPushButton(tr("Model"));
    timeCtr = new QPushButton(tr("controlDict"));
    schemeCtr = new QPushButton(tr("fvScheme"));
    solutionCtr = new QPushButton(tr("fvSolution"));
    materialButton = new QPushButton(tr("Materials"));
    residualButton = new QPushButton(tr("Rseidual"));
    boundaryButton = new QPushButton(tr("boundary"));
    postButton = new QPushButton(tr("post"));

    //runButton->setEnabled(false);
    schemeCtr->setEnabled(false);
    solutionCtr->setEnabled(false);
    materialButton->setEnabled(false);
    residualButton->setEnabled(false);
    boundaryButton->setEnabled(false);
    postButton->setEnabled(false);

    bGroup->addButton(generalButton, 0);
    bGroup->addButton(modelButton, 1);
    bGroup->addButton(materialButton, 2);
    bGroup->addButton(schemeCtr, 3);
    bGroup->addButton(timeCtr, 4);
    bGroup->addButton(residualButton, 5);
    bGroup->addButton(solutionCtr, 6);
    bGroup->addButton(boundaryButton, 7);
    bGroup->addButton(postButton, 8);
    bGroup->addButton(runButton, 9);

    //  设置页面属性
    //view->set

    //  创建panel页面，放置组件
    wholeWidget = new QWidget;
    gPanelPage = new QWidget;
    mPanelPage = new QWidget;
    mtPanelPage = new QWidget;
    schemePanelPage = new QWidget;
    ctrPanelPage = new QWidget;
    rePanelPage = new QWidget;
    solutePage = new QWidget;
    bPanelPage = new QWidget;
    calPanelPage = new QWidget;
    //postPanelPage = new QWidget;
    gPanel = new generalPanel(pEvent, gPanelPage);
    mPanel = new modelPage(pEvent, mPanelPage);
    mtPanel = new materialPanel(pEvent, mtPanelPage);
    sPanel = new schemePanel(pEvent, schemePanelPage);
    cPanel = new controlPanel(pEvent, ctrPanelPage);
    rPanel = new residualPanel(pEvent, rePanelPage);
    solutePanel = new solutionPanel(pEvent, solutePage);
    bPanel = new boundaryPanel(pEvent, bPanelPage);
    //pPanel = new postProcess(pEvent, postPanelPage, tabEdit);
    pPanel = new post(pEvent, tabEdit);
    calPanel = new runPanel(pEvent, calPanelPage);

    plt = new plot(rPanel, tabEdit);
    mt = new myThread();
    postM = new postProcess(pEvent, postTool, cPanel);


    //  在布局上添加控件 （组件名，行，列，行宽，列宽）
    Splitter2->addWidget(tabEdit);
    Splitter2->addWidget(mesView);
    viewGroupLayout->addWidget(Splitter2);
    viewGroupLayout->setContentsMargins(0 ,0, 0, 0);
    viewGroup->setLayout(viewGroupLayout);

    Splitter1->addWidget(wholeWidget);
    Splitter1->addWidget(viewGroup);
    viewLayout->addWidget(Splitter1);
    viewLayout->setContentsMargins(0, 0, 0, 0);
    viewGroup->resize(650, 700);
    this->resize(1200, 700);
    //viewLayout->addWidget(viewGroup);

    vLayout->addWidget(generalButton);
    vLayout->addWidget(modelButton);
    vLayout->addWidget(timeCtr);
    vLayout->addWidget(boundaryButton);
    vLayout->addWidget(materialButton);
    vLayout->addWidget(schemeCtr);
    vLayout->addWidget(solutionCtr);
    vLayout->addWidget(residualButton);
    vLayout->addWidget(runButton);
    vLayout->addWidget(checkButton);
    vLayout->addWidget(postButton);
    vLayout->addStretch();

    //  设置布局距离页面左右距离
    //gridLayout->setContentsMargins(10,10,10,10);

    //  放置布局
    //viewLayout->addLayout(gridLayout);
    hLayout->addLayout(vLayout);
    hLayout->addLayout(viewLayout);
    //hLayout->setContentsMargins(5, 0, 0, 0);

    //  链接页面槽函数
    connect(bGroup, SIGNAL(buttonClicked(int)), this, SLOT(setPanel(int)));
    connect(fileBar->savePr, SIGNAL(triggered()), this, SLOT(saveProject()));
    connect(fileBar->readProj, SIGNAL(triggered()), this, SLOT(readProject()));
    connect(fileBar->readMesh, SIGNAL(triggered()), this, SLOT(readMesh()));
    connect(fileBar->readBash, SIGNAL(triggered(bool)), this, SLOT(readBashTrigger()));
    connect(fTool->plotResiudal, SIGNAL(triggered(bool)), this, SLOT(plotResidual()));
    connect(calPanel->runBt, SIGNAL(clicked(bool)), this, SLOT(timerStart()));
    connect(calPanel->runBt, SIGNAL(clicked(bool)), this, SLOT(runProject()));
    connect(checkButton, SIGNAL(clicked(bool)), this, SLOT(paraview()));
    connect(solutionCtr, SIGNAL(clicked(bool)), this, SLOT(defineRelaxation()));
    connect(cPanel, SIGNAL(appSelectTrigger(int)), mtPanel, SLOT(hideWidget(int)));

    connect(boundaryButton, SIGNAL(clicked(bool)), this, SLOT(defineBoundary()));
    connect(schemeCtr, SIGNAL(clicked(bool)), this, SLOT(schemeTriggered()));
    connect(postButton, SIGNAL(clicked(bool)), this, SLOT(postTriggered()));

    connect(pEvent->saveTool, SIGNAL(finished()), this, SLOT(timeFinished()));
    connect(mt, SIGNAL(transData(PLOTDATA)), plt, SLOT(readResidual(PLOTDATA)));


    mesView->installEventFilter(this);

    //  在界面添加布局
    ui->centralWidget->setLayout(hLayout);
    wholeWidget->setLayout(stackLayout);
    //view->setWidget(wholeWidget);
    //view->setMaximumWidth(MAXIMUMVIEWPANELWIDTH);
    //view->setFeatures(QDockWidget::DockWidgetMovable |
    //                  QDockWidget::DockWidgetFloatable);
    //view->setAllowedAreas(Qt::RightDockWidgetArea | Qt::BottomDockWidgetArea);


    //  放置页面
    stackLayout->addWidget(gPanelPage);
    stackLayout->addWidget(mPanelPage);
    stackLayout->addWidget(mtPanelPage);
    stackLayout->addWidget(schemePanelPage);
    stackLayout->addWidget(ctrPanelPage);
    stackLayout->addWidget(rePanelPage);
    stackLayout->addWidget(solutePage);
    stackLayout->addWidget(bPanelPage);
    //stackLayout->addWidget(postPanelPage);
    stackLayout->addWidget(pPanel);
    stackLayout->addWidget(calPanel->panel);
    stackLayout->setContentsMargins(0, 0, 0, 0);

    start = false;
    firstRead = true;

    //  read window size
    QString path = QCoreApplication::applicationDirPath();
    path = path +"/windowSize";
    FILE *data = fopen(path.toLocal8Bit().data(), "rb");
    if(data!=NULL)
    {
        fread(&wSize, sizeof(windowSize), 1, data);
        fclose(data);
        this->resize(wSize.width, wSize.height);
        //wholeWidget->resize(wSize.widthWholeWidget, wSize.heightWholeWidget);
        viewGroup->resize(wSize.widthViewGroup, wSize.heightViewGroup);
        tabEdit->resize(wSize.widthTabEdit, wSize.heightTabEdit);
        sPanel->schemeT->resize(wSize.widthSchemeT, wSize.heighSchemeT);
        bPanel->scroArea->resize(wSize.widthBoundaryScroArea, wSize.heighBoundaryScroArea);
    }

    if(!win)
    {
        cmdLine = new runCommandLine;
        cmdLine->fBar = fileBar;
        connect(cmdLine, SIGNAL(runCase(bool)), this, SLOT(runProject()));
        connect(cmdLine, SIGNAL(getBashFile(QString)), SLOT(readBashInCommandLine(QString)));
        connect(cmdLine, SIGNAL(readProject()), this, SLOT(readProject()));
        connect(cmdLine, SIGNAL(saveProject()), this, SLOT(saveProject()));
        cmdLine->show();
    }
}

void HFAST::closeEvent(QCloseEvent *e)
{
    // remember the window size

    wSize.widthWholeWidget = wholeWidget->rect().width();
    wSize.heightWholeWidget = wholeWidget->rect().height();
    wSize.widthViewGroup = viewGroup->rect().width();
    wSize.heightViewGroup = viewGroup->rect().height();
    wSize.widthTabEdit = tabEdit->rect().width();
    wSize.heightTabEdit = tabEdit->rect().height();
    wSize.height = this->rect().height();
    wSize.width = this->rect().width();
    wSize.widthSchemeT = sPanel->schemeT->rect().width();
    wSize.heighSchemeT = sPanel->schemeT->rect().height();
    wSize.widthBoundaryScroArea = bPanel->scroArea->rect().width();
    wSize.heighBoundaryScroArea = bPanel->scroArea->rect().height();
    QString path = QCoreApplication::applicationDirPath();
    path = path +"/windowSize";
    FILE *data = fopen(path.toLocal8Bit().data(), "wb");
    if(data!=NULL)
    {
        fwrite(&wSize, sizeof(windowSize), 1, data);
        fclose(data);
    }
    //--save the current casePath

}

void HFAST::setPanel(int index)
{
    if(index==6);
    {
        mPanel->saveEq(); // get the equation number
    }
    stackLayout->setCurrentIndex(index);
}

void HFAST::timeFinished()
{
        timer->stop();
        calPanel->timer->stop();
        mt->terminate();
        mt->wait();
        {
           /* plotResidual();
            QString timeStep = "Time: "+ plt->curTimeStep;
            QString timeT = cPanel->keyLine[1]->text();
            time->setText(timeStep+"/"+timeT);*/
            estimateTime->setText("Still need:s 0 s");
            time_start = 0;
            time_end = 0;
            firstRead = true;
        }
        start = false;
        pEvent->saveTool->isReady = true;
        QApplication::beep();
}

void HFAST::onTimeOut()
{
    if(!start)
    {
         runTime.start();
         if(mt->isReady)
         {
             if(calPanel->read->isChecked())
             {
                 mt->start();
             }
             else
             {
                 mt->isReady = false;
             }
             time_start = runTime.elapsed();
         }
         start = true;
         lastT = 0;
    }
    else
    {
      {
            if(mt->isReady)
                mt->start(); //mt->wait();
            double intTime= runTime.elapsed();
            if(mt->wait());
            {
                QString timeStep;
                //if(mt->isReady)
                {
                   timeStep  = "Time: "+ plt->curTimeStep;
                   curT = plt->curTimeStep.toDouble();
                   calPanel->saveFile(int(curT));
                }
                //else
                {
                   //timeStep = "Time: "+ QString("0");
                   //curT = 0;
                }
                QString timeT = cPanel->keyLine[1]->text();
                double TotalTime, est;
                char buffer[50];
                if(firstRead)
                {
                    TotalTime = intTime;
                    if(fabs(curT)>0)
                        est = TotalTime / (curT/timeT.toDouble());
                    firstRead=false;
                }
                else
                {
                    //  estimate function run
                    TotalTime = intTime;
                    double intT = curT - lastT;
                    double leftTime = cPanel->keyLine[1]->text().toDouble()-curT;
                    est = TotalTime * (leftTime/intT);
                }
                sprintf(buffer, "Still need:  %lf s", est/1000.0);
                estimateTime->setText(buffer);
                time->setText(timeStep+"/"+timeT);
                lastT = curT;

                runTime.start();
            }
      }
    }
}

void HFAST::timerStart()
{
    timer->start();
    if(calPanel->run->isChecked())
        calPanel->timeBegin();
}

void HFAST::plotResidual()
{
    if(pEvent->saveTool->isReady)
    {
        mt->start();
    }
    else
    {
        Mess mes;
        mes.Fun = "void HFAST::plotResidual()";
        mes.Head = "HFAST.h";
        mes.Loc = "read residual";
        mes.title = "Informed";
        mes.Mess = "The application is busy. Please try again in a few minutes";
        HError HFASTErr;
        HFASTErr.HFASTInform(mes);
    }
}

void HFAST::defineRelaxation()
{
    cPanel->saveForNextStep();
    mPanel->saveEq();
    mtPanel->saveForNextStep();
    solutePanel->defineRe(pEvent);
}

void HFAST::defineBoundary()
{
    cPanel->saveForNextStep();
    mPanel->saveEq();

    QStringList modelEq = pEvent->saveTool->modelEq;
    QStringList GoverEq = pEvent->saveTool->eqs;
    QStringList nameLsts;
    QList<QStringList> paraName;
    paraName.append(modelEq);
    paraName.append(GoverEq);
    for(int i=0; i<modelEq.size(); i=i+2)
    {
        nameLsts.append(modelEq[i]);
    }
    for(int i=0; i<GoverEq.size(); i=i+2)
    {
        nameLsts.append(GoverEq[i]);
    }

    int modelIndex = pEvent->saveTool->modelS.index;
    int solverIndex = pEvent->saveTool->ctrlT.appIndex;
    int solverSelect = pEvent->saveTool->ctrlT.appSelect;
    bPanel->setUpPanel(paraName, nameLsts, modelIndex, solverIndex, solverSelect);
    showButton();
}

void HFAST::runMsgCommand()
{
    QString qbt;
    qbt = QString::number(mesView->document()->lineCount());
    qbt = mesView->document()->findBlockByLineNumber(qbt.toInt()-2).text();
}

void HFAST::runProject()
{
    if(pEvent->saveTool->isReady)
    {
        //  save Project
        Mess mes;
        //mes.Fun = "void HFAST::runProject()";
        //mes.Head = "HFAST.h";
        //mes.Loc = "runButton triggered";
        //mes.title = "Warnning";
        //mes.Mess = "Do you want to save the Project before running?";
        //HError HFASTError;
        //int save = HFASTError.HFASTWarning(mes);
        if(calPanel->save->isChecked())
        {
            cPanel->saveForNextStep();
            gPanel->saveForNextStep();
        }
        else if(boundaryButton->isEnabled())
            saveProject();
        else
        {
            mes.Fun = "void HFAST::runProject()";
            mes.Head = "HFAST.h";
            mes.Loc = "runButton triggered";
            mes.title = "Warnning";
            mes.Mess = "The project cannot be ran since the boundary is not setting";
            HError HFASTError;
            HFASTError.HFASTWarning(mes);
            pEvent->saveTool->isReady = true;
        }
        if(calPanel->useOpt())
        {
             runOptimize();
             return;
        }
        QString cmd;
        QString cmdFoam;
        //  get the app name
        QString app = pEvent->saveTool->ctrlT.appName;
        //  parallel number
        int num = pEvent->saveTool->para.num;

        if(pEvent->saveTool->ctrlT.startFromIndex==2)
        {
            QString workPath = QDir::currentPath();
            QString path = workPath + "/";
            QStringList timeList = pPanel->getTimeName(workPath, "");
            mt->timeFolder = timeList[timeList.size()-1];
        }
        else
        {
            mt->timeFolder = pEvent->saveTool->ctrlT.list[0];
        }

        if(num==0 || num==1)
        {
            cmdFoam = app + " | tee log."+app;
        }
        else
        {
            cmdFoam = "mpirun -np " + QString::number(num) + " "+ app +" -parallel | tee log."+app;
            QString workPath = QDir::currentPath();
            QString path = workPath + "/processor0/";
            QStringList timeList = pPanel->getTimeName(path, "");
            if(timeList.isEmpty())
            {
                //The folder is not existed.
                mes.Fun = "void HFAST::runProject()";
                mes.Head = "HFAST.h";
                mes.Loc = "runButton triggered";
                mes.title = "Warnning";
                mes.Mess = "decomposePar should be ran!\n";
                HFASTError.HFASTWarning(mes);
                return;
            }
            if(pEvent->saveTool->ctrlT.startFromIndex==2)
            {
                mt->timeFolder = timeList[timeList.size()-1];
            }
            else
            {
                bool exist = false;
                for(int i=0; i<timeList.size(); i++)
                {
                    if(timeList[i].compare(mt->timeFolder)==0)
                    {
                        exist = true;
                        break;
                    }
                }
                if(!exist)
                {
                    mes.Fun = "void HFAST::runProject()";
                    mes.Head = "HFAST.h";
                    mes.Loc = "runButton triggered";
                    mes.title = "Warnning";
                    mes.Mess = "time "+mt->timeFolder+" is not found in processor0 folder;\n" ;
                    HFASTError.HFASTWarning(mes);
                    pEvent->saveTool->isReady = true;
                    return;
                }
            }
        }   
        cmd = cmd + ("rm -rf 0 && cp -rf 0.orig 0 && ");
        cmd = cmd + cmdFoam;
        pEvent->saveTool->runCommand(cmd);
    }
    else
    {
        Mess mes;
        mes.Fun = "void HFAST::runProject()";
        mes.Head = "HFAST.h";
        mes.Loc = "Run command";
        mes.title = "Informed";
        mes.Mess = "The application is busy. Please try again in a few minutes";
        HError HFASTErr;
        HFASTErr.HFASTInform(mes);
    }
}

void HFAST::runOptimize()
{
    QList<QStringList> scheme = calPanel->getOptimizeResult();
    if(scheme.isEmpty())
    {
        qDebug()<<"cannot get the optimize scheme";
        return;
    }
    calPanel->runClicked();

    //check the optimize core
    if(pEvent->saveTool->para.num!=calPanel->optInf.process)
    {
        qDebug()<<"the para number is not equal to the general panel setting.";
        return;
    }

    // create the task
    bool su = calPanel->distributedTask();
    if(!su)
        return;
    // run parallel

    gPanel->saveProject();
    int len = scheme.size()/calPanel->optInf.task;
    QList<QList<QStringList>> distScheme;
    for(int i=0; i<calPanel->optInf.task; i++)
    {
         int match = 0 + len*i;
         QList<QStringList> data = paraDistribe(scheme, len, i+1, match);
         distScheme.append(data);
         //qDebug()<<data;
    }
    //omp_set_dynamic(0);
    //omp_set_num_threads(calPanel->optInf.task);
    qDebug()<<"applied for process storage";
    pr = new paraProcess*[calPanel->optInf.task];
    qDebug()<<"parallel for running";
    //#pragma omp parallel for
    for(int i=0; i<calPanel->optInf.task; i++)
    {
       QList<QStringList> data = distScheme[i];
       qDebug()<<"parallel data is ready";

       QString folderName = "task"+QString::number(i);
       QString path = QDir::currentPath();
       QString taskPath = path + "/TASK/"+folderName;
       QString bashrc = pEvent->saveTool->bashrc;
       QString ref = calPanel->optInf.ref;
       QString line = calPanel->optInf.line;
       int varIndex = calPanel->optInf.varIdx;

       //qDebug()<<"create process " <<i;
       pr[i] = new paraProcess(i, data, taskPath, bashrc, ref, line, varIndex);
       pr[i]->bs = pEvent->saveTool;

       qDebug()<<"process "<<i<<" is started";
       pr[i]->isStarted();
    }
}

QList<QStringList> HFAST::paraDistribe(QList<QStringList> scheme, int len, int taskIdx, int begin)
{
    QList<QStringList> data;
    int last;
    if(taskIdx==calPanel->optInf.task)
        last = scheme.size();
    else
        last = len*taskIdx;
    for(int i=begin; i<last; i++)
    {
        data.append(scheme[i]);
    }
    return data;
}

void HFAST::statusChange(QString str)
{
    QString str1 = "Ready";
    bool su = init->newCase(str, "void HFAST::statusChange(QString str)");
    if(su)
    {
       status->setText(str1);
       //status->setStyleSheet("background-color:rgb(64, 66, 68)");
       isReady = true;
    }
}

void HFAST::saveProject()
{
    QString workPath = QDir::currentPath();
    QString file = workPath + "/"+JSONFILE;
    QDir dir(workPath);
    dir.remove(file);
    bool su;
    gPanel->saveProject();

    mPanel->saveProject();

    sPanel->saveProject();
    cPanel->saveProject();
    mtPanel->saveProject();

    solutePanel->save();
    rPanel->saveProject();
    su = bPanel->saveProject();
    if(su)
        pEvent->saveTool->saveProject("void HFAST::saveProject()");
}

void HFAST::readProject()
{
    bool su = fileBar->readProject();
    if(su==true)
    {
        qDebug()<<"user.json is read";
        emit fileBar->readMesh->triggered();
        qDebug()<<"Mesh is read";

        fTool->dPanel->readProject();
        qDebug()<<"defining Fields are read";

        //emit generalButton->click();
        gPanel->readProject();
        qDebug()<<"general Panel is read";

        //emit modelButton->click();
        mPanel->readProject();
        qDebug()<<"model Panel is read";

        //emit materialButton->click();
        mtPanel->readProject();
        qDebug()<<"material Panel is read";

        //emit solutionCtr->click();
        sPanel->readProject();
        qDebug()<<"scheme Panel is read";

        //emit timeCtr->click();
        cPanel->readproject();
        qDebug()<<"control Panel is read";


        rPanel->readProject();
        qDebug()<<"residual Panel is read";

        mPanel->saveEq();
        bPanel->readProject();
        qDebug()<<"boundary Panel is read";
        emit boundaryButton->click();

        solutePanel->read(pEvent);
        qDebug()<<"solution Panel is read";

        qDebug()<<BROWSER;
    }
}

void HFAST::paraview()
{
    QString workPath = QDir::currentPath();
    int mark = init->newCase(workPath, "void HFAST::paraview()");
    if(mark ==1)
    {
        QStringList lst = workPath.split("/");
        QString file = workPath + "/"+lst[lst.size()-1]+".foam";
        FILE *data = fopen(file.toLocal8Bit().data(), "w");
        if(data!=NULL)
        {
            fclose(data);
            if(pEvent->saveTool->isReady)
            {
                pEvent->saveTool->runCommand("paraview *.foam");
            }
            else
            {
                Mess mes;
                mes.Fun = "void HFAST::paraview()";
                mes.Head = "HFAST.h";
                mes.Loc = "Run command: "+ QString("paraview *.foam");
                mes.title = "Informed";
                mes.Mess = "The application is busy. Please try again in a few minutes";
                HError HFASTErr;
                HFASTErr.HFASTInform(mes);
            }
        }
    }
}

void HFAST::readMesh()
{
    bPanel->delecteMeshPanel();
    int sucess = bPanel->defineMeshPanel();
    // -- set true for button
    if(sucess)
    {
        boundaryButton->setEnabled(true);
    }
    else
    {
        Mess mes;
        mes.Fun = "void HFAST::readMesh()";
        mes.Head = "HFAST.h";
        mes.Loc = "read Mesh";
        mes.title = "Warnning";
        mes.Mess = "The Mesh cannnot be found in the current path";
        HError HFASTErr;
        HFASTErr.HFASTWarning(mes);
    }
}

void HFAST::schemeTriggered()
{
    if(sPanel->useRec)
    {
        cPanel->saveForNextStep();
        mPanel->saveEq();
        mtPanel->saveForNextStep();
        sPanel->reScheme(pEvent);
    }
}

void HFAST::showButton()
{
    runButton->setEnabled(true);
    schemeCtr->setEnabled(true);
    solutionCtr->setEnabled(true);
    materialButton->setEnabled(true);
    residualButton->setEnabled(true);
    postButton->setEnabled(true);
}

void HFAST::postTriggered()
{
    rPanel->saveForNextStep();
    pPanel->definePanel(pEvent);
}

void HFAST::readBashTrigger()
{
    QFileDialog *file = new QFileDialog;
    file->setWindowTitle("Choose file");
    QString path = QDir::currentPath();
    file->setDirectory(path);
    file->setFileMode(QFileDialog::ExistingFile);
    file->setViewMode(QFileDialog::Detail);
    QStringList fileName;
    if(file->exec())
    {
        fileName = file->selectedFiles();
    }
    if(!fileName.isEmpty())
    {
        readBash rBash;
        QString desFile = fileName[0];
        rBash.changeWorkPath(desFile, fileBar);
        rBash.readBashFile(desFile);
        // set optimize
        rBash.setRunPanel(calPanel);
        rBash.readRunPanel(desFile, calPanel);
        rBash.setProcess(desFile, gPanel);
    }
}

void HFAST::readBashInCommandLine(QString file)
{
    readBash rBash;
    QString desFile = file;
    rBash.changeWorkPath(desFile, fileBar);
    rBash.readBashFile(desFile);
    // set optimize
    rBash.setRunPanel(calPanel);
    rBash.readRunPanel(desFile, calPanel);
    rBash.setProcess(desFile, gPanel);
}
