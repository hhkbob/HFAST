/**
  * @file     	HFAST.h
  * @author   	Huakun Huang
  * @email   	huanghuakun0902@163.com
  * @version	V1.0
  * @date    	09-SEP-2022
  * @license  	GNU General Public License (GPL)
  * @brief   	主界面
  * @detail		详细
  * @attention
  *  This file is part of HFAST.                                                \n
  *  This program is free software; you can redistribute it and/or modify 		\n
  *  it under the terms of the GNU General Public License version 3 as 		    \n
  *  published by the Free Software Foundation.                               	\n
  *  You should have received a copy of the GNU General Public License   		\n
  *  along with OST. If not, see <http://www.gnu.org/licenses/>.       			\n
  *  Unless required by applicable law or agreed to in writing, software       	\n
  *  distributed under the License is distributed on an "AS IS" BASIS,         	\n
  *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  	\n
  *  See the License for the specific language governing permissions and     	\n
  *  limitations under the License.   											\n
  *   																			\n
  * @htmlonly
  * <span style="font-weight: bold">History</span>
  * @endhtmlonly
  * Version|Auther|Date|Describe
  * ------|----|------|--------
  * V1.0|Huang Huakun|09-SEP-2022|Create File
  * <h2><center>&copy;COPYRIGHT 2017 WELLCASA All Rights Reserved.</center></h2>
  */
#ifndef HFAST_H
#define HFAST_H

#include <QMainWindow>
#include <QTextBrowser>
#include <QGridLayout>
#include "generalPanel.h"
#include "modelPage.h"
#include "materialPanel.h"
#include "schemePanel.h"
#include "controlPanel.h"
#include "residualPanel.h"
#include <QDockWidget>
#include <QStackedLayout>
#include <QSplitter>
#include "fileToolBar.h"
#include "textBrowser.h"
#include "fileToolh.h"
#include "plot.h"
#include "QTime"
#include "solutionPanel.h"
#include "boundaryPanel.h"
#include "postProcess.h"
#include "post.h"
#include "runPanel.h"
#include "readBash.h"
#include "runCommandLine.h"

namespace Ui {
class HFAST;
}

class HFAST : public QMainWindow
{
    Q_OBJECT

public:
    explicit HFAST(bool window);
    ~HFAST();
    HError HFASTError;
    printTool *pEvent;
    fileToolBar *fileBar;
    fileToolh *fTool;
    postProcess *postM;
    foamInit *init;
    plot *plt;
    myThread *mt;
    bool start;
    textBrowser *mesView;  //  命令查看窗口
    runCommandLine *cmdLine;
    bool win;

    /**
    * @brief 初始化界面
    */
    void initApp();

private:
    Ui::HFAST *ui;
    QMenu *File;
    QMenu *Tool;
    QMenu *postTool;
    QLabel *status;
    QLabel *time;
    QLabel *estimateTime;
    QGroupBox *sGroup;
    QHBoxLayout *sLayout;

    QGridLayout *gridLayout; //  网格布局
    QVBoxLayout *vLayout; //  水平布局--整体的
    QHBoxLayout *hLayout;  //  放置按钮
    QHBoxLayout *viewLayout; //  放置文本和视图窗口
    QStackedLayout *stackLayout; //  放置不同页面
    QVBoxLayout *viewGroupLayout;

    QWidget *wholeWidget;
    generalPanel *gPanel;
    modelPage *mPanel;
    materialPanel *mtPanel;
    schemePanel *sPanel;
    controlPanel *cPanel;
    residualPanel *rPanel;
    solutionPanel *solutePanel;
    boundaryPanel *bPanel;
    runPanel *calPanel;
    //postProcess *pPanel;
    post *pPanel;
    QWidget *gPanelPage;
    QWidget *mPanelPage;
    QWidget *mtPanelPage;
    QWidget *schemePanelPage;
    QWidget *ctrPanelPage;
    QWidget *rePanelPage;
    QWidget *solutePage;
    QWidget *bPanelPage;
    QWidget *calPanelPage;
    //QWidget *postPanelPage;

    QTabWidget *tabEdit; //  tab

    QDockWidget  *view;  //  核心展示窗口
    QSplitter *Splitter1;
    QSplitter *Splitter2;

    QPushButton *runButton; //  运行按钮
    QPushButton *checkButton; //  检查网格质量按钮
    QPushButton *generalButton; //  常规按钮
    QPushButton *modelButton;  //  模型按钮
    QPushButton *timeCtr;
    QPushButton *schemeCtr;
    QPushButton *solutionCtr;
    QPushButton *materialButton;  //  材料按钮
    QPushButton *residualButton;
    QPushButton *boundaryButton;
    QGroupBox *viewGroup;
    QPushButton *postButton;

    /**
     * @brief 添加界面按钮
     */
    void addLayout();

private:
    QButtonGroup *bGroup;
    bool isReady;
    QTimer *timer;
    myThread *myPr;
    double time_start;
    double time_end;
    bool firstRead;
    double curT, lastT;
    QTime runTime;
    int TimeStep;
    paraProcess **pr;
    struct windowSize
    {
        int widthWholeWidget;
        int heightWholeWidget;
        int widthViewGroup;
        int heightViewGroup;
        int widthTabEdit;
        int heightTabEdit;
        int widthSchemeT;
        int heighSchemeT;
        int widthBoundaryScroArea;
        int heighBoundaryScroArea;
        int width;
        int height;
    };
    windowSize wSize;

protected:
    virtual void closeEvent(QCloseEvent *e);


private slots:
    void setPanel(int index);
    void timeFinished();
    void onTimeOut();
    void timerStart();
    void plotResidual();
    void defineRelaxation();
    void defineBoundary();

    void runMsgCommand();
    void runProject();
    void runOptimize();
    QList<QStringList> paraDistribe(QList<QStringList> scheme, int len, int taskIdx, int begin);
    void statusChange(QString);
    void saveProject();
    void readProject();
    void paraview();
    void readMesh();
    void schemeTriggered();
    void showButton();
    void postTriggered();
    void readBashTrigger();
    void readBashInCommandLine(QString file);

};

#endif // HFAST_H
