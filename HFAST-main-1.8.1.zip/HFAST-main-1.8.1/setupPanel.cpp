#include "setupPanel.h"
#include "ui_setupPanel.h"

setUpPanel::setUpPanel(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::setUpPanel)
{
    ui->setupUi(this);
    FILE *data = fopen("./core/foamVersion.ini", "r");
    if(data!=NULL)
    {
        char buffer[500];
        while(!feof(data))
        {
            fscanf(data, "%s", buffer);
            version.append(buffer);
            fscanf(data, "%s", buffer);
            bashrc.append(buffer);
        }
        fclose(data);
    }
    else
    {
        Mess mes;
        mes.Fun = "setUpPanel::setUpPanel(QWidget *parent)";
        mes.Head = "setupPanel.h";
        mes.Loc = "Read foamVersion.ini, but fails. ";
        mes.title = "Critical error";
        mes.Mess = "Cannot found foamVersion.ini in the core directory. Abort the application any way";
        HError HFASTError;
        HFASTError.HFASTCritical(mes);
        abort();
    }
    ui->comboBox->addItems(version);
    ui->lineEdit->setText(bashrc[0]);
    skin = ui->comboBox_2->currentText();
    connect(ui->comboBox, SIGNAL(activated(int)), this, SLOT(showBashrc(int)));

    data = fopen("./core/version.ini", "r");
    int v=5;
    if(data!=NULL)
    {
        fscanf(data, "%d", &v);
        fclose(data);
        ui->comboBox->setCurrentText(QString::number(v));
        int idx = ui->comboBox->currentIndex();
        emit ui->comboBox->activated(idx);
    }
    else
    {

        {
            Mess mes;
            mes.Fun = "setUpPanel::setUpPanel(QWidget *parent)";
            mes.Head = "setUpPanel.h";
            mes.Loc = "";
            mes.title = "critical error";
            mes.Mess = "cannot find file core/version.ini. The application will be aborted";
            HError HFASTEror;
            HFASTEror.HFASTWarning(mes);
            abort();
        }
    }
    currentVersion = ui->comboBox->currentText();
    skinList<<"AMOLED"<<"Aqua"<<"ConsoleStyle"<<"ElegantDark"
            <<"MacOS"<<"ManjaroMix"<<"MaterialDark"
            <<"NeonButtons";
    ui->comboBox_2->addItems(skinList);
    showSkin(0);
    connect(ui->comboBox_2, SIGNAL(activated(int)), SLOT(showSkin(int)));
}

setUpPanel::~setUpPanel()
{
    delete ui;
}

void setUpPanel::showBashrc(int idx)
{
    if(!bashrc.isEmpty() && bashrc.size()>idx)
    {
       ui->lineEdit->setText(bashrc[idx]);
       bashrcPath = bashrc[idx];
    }
}

void setUpPanel::on_pushButton_clicked()
{
    FILE *data = fopen("resources/skin.dat", "w");
    skin = ui->comboBox_2->currentText();
    if(data!=NULL)
    {
        fprintf(data, "QSS/%s.qss", skin.toLocal8Bit().data());
        fclose(data);
    }
    bashrcPath = ui->lineEdit->text();
    currentVersion = ui->comboBox->currentText();
    data = fopen("./core/version.ini", "w");
    if(data!=NULL)
    {
        fprintf(data, "%s", currentVersion.toLocal8Bit().data());
        fclose(data);
    }
    else
    {
        Mess mes;
        mes.Fun = "void setUpPanel::on_pushButton_clicked()";
        mes.Head = "setupPanel.h";
        mes.Loc = "create version.ini, but fails. ";
        mes.title = "Critical error";
        mes.Mess = "Cannot create ./core/version.ini. Abort the application any way";
        HError HFASTError;
        HFASTError.HFASTCritical(mes);
        abort();
    }
    this->accept();
}

void setUpPanel::on_pushButton_2_clicked()
{
    exit(0);
}

void setUpPanel::on_buttonBox_rejected()
{}

void setUpPanel::showSkin(int idx)
{
    QString skinName = skinList[idx] +".png";
    skinName = "resources/" + skinName;
    QImage *img = new QImage;
    img->load(skinName);
    double width = 200;
    double height = 300;
    //QPixmap pixmap(skinName);
    ui->skin->setPixmap(QPixmap::fromImage(img->scaled(width,
                                                      height,
                                                      Qt::KeepAspectRatio)));
    ui->skin->show();
}
