#ifndef HFASTACTION_H
#define HFASTACTION_H

#include <QAction>

class HFASTAction : public QAction
{
    Q_OBJECT
public:
    explicit HFASTAction(int index, QString command);
    QString cmd;
    int idx;

signals:
    void triggered(int i, QString cmd);

public slots:
    void sendData();
};

#endif // HFASTACTION_H
