#ifndef MATERIALPANEL_H
#define MATERIALPANEL_H

#include <QObject>
#include <QComboBox>
#include <QHBoxLayout>
#include <QLabel>
#include "basic.h"
#include "printTool.h"
#include "thermal.h"
#include "thermaValue.h"

class materialPanel : public QObject
{
    Q_OBJECT
public:
    explicit materialPanel(printTool *p, QWidget *m);
    ~materialPanel();
    MATERIAL mt;
    THERMAL tThermal;
    QList<MATERIAL> list;
    printTool *pEvent;
    thermal *tGroup;
    thermaValue *thValue;
    void saveProject();
    void readProject();
    void saveForNextStep();

signals:

private:
    void setUpPanel();
    void printMt(QString loc, MATERIAL mtr);
    void saveMt();
    void readMt(QString loc);
    void defineAir();
    void defineWater();
private:
    QComboBox *dataBase;
    QLabel *dataL;
    QLabel *mtName[MATERIAL_NUM];
    QLineEdit *mtValue[MATERIAL_NUM];
    QHBoxLayout *hLayout;
    QHBoxLayout *pLayout[MATERIAL_NUM];
    QVBoxLayout *vLayout;
    int currentInex;
    QTabWidget *tab;
    QPlainTextEdit *add;
    QScrollArea *scroArea;

public slots:
    void showDetail(int index);
    void hideWidget(int index);
};

#endif // MATERIALPANEL_H
