#include "thermaValue.h"

thermaValue::thermaValue(thermal *tGroup)
{
    thm = tGroup;
    vLayout = new QVBoxLayout;
    QStringList lst;
    lst<<"specie"<<"thermodynamics"<<"transport"<<"equationOfState";
    for(int i=0; i<THERMALVALUENUM; i++)
    {
        name[i] = new QLabel(lst[i]);
        textEdit[i] = new QPlainTextEdit;
        vLayout->addWidget(name[i]);
        vLayout->addWidget(textEdit[i]);
    }
    vLayout->addStretch();
    this->setLayout(vLayout);

    change = false;
}

QStringList thermaValue::save()
{
    QStringList lst;
    for(int i=0; i<THERMALVALUENUM; i++)
    {
        lst.append(textEdit[i]->toPlainText());
    }
    return lst;
}

void thermaValue::read(QStringList lst)
{
    for(int i=0; i<THERMALVALUENUM; i++)
    {
        textEdit[i]->clear();
        textEdit[i]->appendPlainText(lst[i]);
    }
}

void thermaValue::defineSpecie()
{
    char buffer[500];
    sprintf(buffer, "molWeight      %lf;", mts.materials[MOWEIGHT]);
    textEdit[0]->appendPlainText(buffer);
}

void thermaValue::defineEq()
{
    char buffer[500];
    sprintf(buffer, "rho0     %lf;\nT0        %lf;\nbeta        %lf;",
            mts.materials[RHO], mts.materials[T0], mts.materials[BETA]);
    textEdit[3]->appendPlainText(buffer);
}

void thermaValue::defineTher()
{
    {
        char buffer[500];
        sprintf(buffer, "Cp     %lf;\nHf        %lf;", mts.materials[CP], mts.materials[HF]);
        textEdit[1]->appendPlainText(buffer);
    }
}

void thermaValue::defineTran()
{
    char buffer[500];
    sprintf(buffer, "mu     %lf;\nPr        %lf;", mts.materials[NU], mts.materials[PR]);
    textEdit[2]->appendPlainText(buffer);
}

void thermaValue::defineValue(MATERIAL mt)
{
    mts = mt;
    for(int i=0; i<THERMALVALUENUM; i++)
        textEdit[i]->clear();

    defineSpecie();
    defineEq();
    defineTher();
    defineTran();
}

void thermaValue::thermoChange(int idx)
{
    textEdit[1]->clear();
    if(idx==1) //sutherland
    {
        QString str = "Tlow         200;\n"+QString("Thigh        6000;\n");
        str = str + "Tcommon      1000;\n" +QString("highCpCoeffs  ();\n");
        str = str + "lowCpCoeffs  ();";
        textEdit[1]->appendPlainText(str);
    }
    else
    {
        defineTher();
    }
}
