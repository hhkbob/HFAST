/**
  * @file     	printTool.cpp
  * @author   	Huakun Huang
  * @email   	huanghuakun0902@163.com
  * @version	V1.0
  * @date    	09-SEP-2022
  * @license  	GNU General Public License (GPL)
  * @brief   	专门处理各种OpenFOAM文档的头文件，版本控制等
  * @detail		头文件定义可以参考printTool.h
  * @attention
  *  This file is part of HFAST.                                                                                              \n
  *  This program is free software; you can redistribute it and/or modify 		          \n
  *  it under the terms of the GNU General Public License version 3 as 		          \n
  *  published by the Free Software Foundation.                               	                              \n
  *  You should have received a copy of the GNU General Public License   		          \n
  *  along with OST. If not, see <http://www.gnu.org/licenses/>.       			          \n
  *  Unless required by applicable law or agreed to in writing, software       	                    \n
  *  distributed under the License is distributed on an "AS IS" BASIS,         	                    \n
  *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  	\n
  *  See the License for the specific language governing permissions and     	          \n
  *  limitations under the License.   									\n
  *   														\n
  * @htmlonly
  * <span style="font-weight: bold">History</span>
  * @endhtmlonly
  * Version|Auther|Date|Describe
  * ------|----|------|--------
  * V1.0|Huang Huakun|09-SEP-2022|Create File
  * <h2><center>&copy;COPYRIGHT 2017 WELLCASA All Rights Reserved.</center></h2>
  */

#include "printTool.h"

printTool::printTool()
{
    saveTool = new basic;
}

void printTool::printHeader(FILE *file, QString rt, QString obj, QString clas)
{
    fprintf(file, "/*--------------------------------*- C++ -*----------------------------------*\\\n");
    fprintf(file, "| =========                 |                                                 |\n");
    fprintf(file, "| \\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox           |\n");
    fprintf(file, "|  \\    /   O peration     | Version:  %s                                  |\n", version.toLocal8Bit().data());
    fprintf(file, "|   \\  /    A nd           | Web:      www.OpenFOAM.org                      |\n");
    fprintf(file, "|    \\/     M anipulation  |                                                 |\n");
    fprintf(file, "\\*---------------------------------------------------------------------------*/\n");
    fprintf(file, "%s\n{\n", "FoamFile");
    fprintf(file, "    version	   2.0;\n");
    fprintf(file, "    format	   ascii;\n");
    fprintf(file, "    class	   %s;\n", clas.toLocal8Bit().data());
    fprintf(file, "    location	  \"%s\";\n", rt.toLocal8Bit().data());
    fprintf(file, "    object	   %s;\n}\n", obj.toLocal8Bit().data());
    fprintf(file, "//    author      Huakun Huang\n");
    fprintf(file, "//    Email:      huanghuakun0902@163.com\n");
    //fprintf(file, "// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //\n");
}

void printTool::printFoot(FILE *file)
{
    fprintf(file, "// ************************************************************************* //");
}

void printTool::printGravity(GRAVITY g, QString loc)
{
    initBasic(QString("printTool::printGravity() ")+
              "found in: void printTool::initBasic()\n"+loc);
    QString workPath = QDir::currentPath();
    QString fileName = workPath + "/constant/g";
    bool OK[3];
    g.gxyz[0].toDouble(&OK[0]);
    g.gxyz[0].toDouble(&OK[1]);
    g.gxyz[2].toDouble(&OK[2]);
    for(int i=0; i<3; i++)
    {
        if(!OK[i])
        {
            HError HFASTError;
            Mess mes;
            mes.Fun = "void printTool::printGravity()";
            mes.Head = "printTool.h";
            mes.title = "Critical Error";
            mes.Loc = loc;
            mes.Mess = "Application found error inputs for gravity";
            int mark = HFASTError.HFASTCritical(mes);
            if(mark==1 || mark==2)
                return;
        }
    }
    saveTool->gravity[0] = g.gxyz[0];
    saveTool->gravity[1] = g.gxyz[1];
    saveTool->gravity[2] = g.gxyz[2];

    FILE *file2;
A:  file2 = fopen(fileName.toLocal8Bit().data(), "w");
    if(file2==NULL)
    {
        HError HFASTError;
        Mess mes;
        mes.Fun = "void printTool::printGravity()";
        mes.Head = "printTool.h";
        mes.title = "Critical Error";
        mes.Loc = loc;
        mes.Mess = "Cannot create g file in the constant directory";
        int mark = HFASTError.HFASTCritical(mes);
        if(mark==1)
            goto A;
        if(mark==2)
            return;
    }
    printHeader(file2,"constant","g","uniformDimensionedVectorField");
    printFoot(file2);
    fprintf(file2, "\n\ndimensions	[0 1 -2 0 0 0 0];\n");
    fprintf(file2, "value  (%s %s %s);\n\n\n\n", saveTool->gravity[0].toLocal8Bit().data(),
         saveTool->gravity[1].toLocal8Bit().data(),
         saveTool->gravity[2].toLocal8Bit().data());
    printFoot(file2);
    fclose(file2);
}

void printTool::printDecomposePar(PARADICT para, int method, QString loc)
{
    if(para.num==0)
    {
        return;
    }

    //  save the json
    saveTool->para = para;

    QString workPath = QDir::currentPath();
    QString file = workPath + "/system/decomposeParDict";
    FILE *data;
    loc = QString
    (
      "void printTool::printDecomposePar(PARADICT para, int method, QString loc)\n"
    ) + loc;
    data = fopen(file.toLocal8Bit().data(), "w");
    fileCheck(loc, data, file);
    printHeader(data,"system","decomposePar","dictionary");
    printFoot(data);
    fprintf(data, "\n#include \"coreControl.H\"\n");
    fprintf(data, "\nnumberOfSubdomains   $core;\n");
    if(method==SIMPLE)
    {
        int Total = para.simple[0].toInt( ) *
                    para.simple[1].toInt() *
                    para.simple[2].toInt();
        if(Total != para.num)
        {
            Mess mes;
            mes.Fun = "void printTool::fileCheck(Mess mes, FILE *data, QString file)";
            mes.Head = "printTool.h";
            mes.title = "Critical Error";
            mes.Loc = loc;
            mes.Mess = "Subdomain is not equal";
            HError HFASTError;
            HFASTError.HFASTCritical(mes);
        }
        fprintf(data, "method       simple;\n");
        fprintf(data, "simpleCoeffs\n{\n");
        fprintf(data, "     n       (%d %d %d);\n",
                para.simple[0].toInt(),
                para.simple[1].toInt(),
                para.simple[2].toInt());
        fprintf(data, "  delta        %lf;\n}\n", para.simple[3].toDouble());
    }
    else if(method==HIERA)
    {
        int Total = para.hiera[0].toInt( ) *
                    para.hiera[1].toInt() *
                    para.hiera[2].toInt();
        if(Total != para.num)
        {
            Mess mes;
            mes.Fun = "void printTool::fileCheck(Mess mes, FILE *data, QString file)";
            mes.Head = "printTool.h";
            mes.title = "Critical Error";
            mes.Loc = loc;
            mes.Mess = "Subdomain is not equal";
            HError HFASTError;
            HFASTError.HFASTCritical(mes);
        }
        fprintf(data, "method       hierarchical;\n");
        fprintf(data, "hierarchicalCoeffs\n{\n");
        fprintf(data, "     n       (%d %d %d);\n",
                para.hiera[0].toInt(),
                para.hiera[1].toInt(),
                para.hiera[2].toInt());
        fprintf(data, "delta        %lf;\n", para.hiera[3].toDouble());
        fprintf(data, "order        %s;\n}\n",para.hiera[4].toLocal8Bit().data());
    }
    else if(method==SCOTCH)
    {
        fprintf(data, "method       scotch;\n");
    }
    /*else if(method==METIC)
    {
        fprintf(data, "metisCoeffs\n{\n");
        fprintf(data, "processorWeights\n   (\n" );
        fprintf(data, "     %d\n", para.metic[0].toInt());
        fprintf(data, "     %d\n", para.metic[1].toInt());
        fprintf(data, "     %d\n    );\n}\n", para.metic[2].toInt());

    }*/
    printFoot(data);
    fclose(data);
    file = workPath + "/system/coreControl.H";
    data = fopen(file.toLocal8Bit().data(), "w");
    fileCheck(loc, data, file);
    if(data!=NULL)
    {
        fprintf(data, "core  %d;", para.num);
        fclose(data);
    }
}

void printTool::printModel(mStr model, QString loc)
{
    QString workPath = QDir::currentPath();
    QString file;
    if(saveTool->getVersion("printTool printModel").toInt()==10)
        file = workPath + "/constant/momentumTransport";
    else if(saveTool->getVersion("printTool printModel").toInt()==5)
        file = workPath + "/constant/turbulenceProperties";
    loc = QString
    (
      "void printTool::printModel(printTool::modelStr model, QString loc)\n"
    ) + loc;
    FILE *data = fopen(file.toLocal8Bit().data(), "w");
    fileCheck(loc, data, file);
    printHeader(data,"constant","momentumTransport","dictionary");
    printFoot(data);
    fprintf(data, "\nsimulationType RAS;\n\n");
    fprintf(data, "RAS\n{\n");
    if(saveTool->getVersion("printModel").toInt()==10)
         fprintf(data, "     model       %s;\n", model.name);
    else if(saveTool->getVersion("printModel").toInt()==5)
         fprintf(data, "     RASModel       %s;\n", model.name);
    fprintf(data, "     turbulence      on;\n");
    fprintf(data, "     printCoeffs     on;\n");
    if(QString(model.name).compare("kOmegaSSTLM")==0)
        fprintf(data, "     kOmegaSSTCoeffs\n");
    else if(QString(model.name).compare("kOmegaSSTLMCD")==0)
        fprintf(data, "     kOmegaSSTCDCoeffs\n");
    else
        fprintf(data, "     %sCoeffs\n", model.name);
    fprintf(data, "     {\n");
    for(int i=0; i<model.cKey; i++)
    {
         if(saveTool->modelS.index == saveTool->SSTKOMEGA )
         {
             if(i==12 || i==13 )
             {
                 if(int(model.vName[i]))
                     fprintf(data, "             %-16s  yes;\n", model.cName[i], model.vName[i]);
                 else
                     fprintf(data, "             %-16s  no;\n", model.cName[i], model.vName[i]);
             }
             else
             {
                 fprintf(data, "             %-16s  %g;\n", model.cName[i], model.vName[i]);
             }
         }
         else if(saveTool->modelS.index == saveTool->SSTKOMEGACD)
         {
             if(i==12 || i==15 || i==16)
             {
                 if(int(model.vName[i]))
                     fprintf(data, "             %-16s  yes;\n", model.cName[i], model.vName[i]);
                 else
                     fprintf(data, "             %-16s  no;\n", model.cName[i], model.vName[i]);
             }
             else
             {
                 fprintf(data, "             %-16s  %g;\n", model.cName[i], model.vName[i]);
             }
         }
         else if(saveTool->modelS.index == saveTool->SSTLMCD)
         {
             if(i==12 || i==15 || i==16)
             {
                 if(int(model.vName[i]))
                     fprintf(data, "             %-16s  yes;\n", model.cName[i], model.vName[i]);
                 else
                     fprintf(data, "             %-16s  no;\n", model.cName[i], model.vName[i]);
             }
             else
             {
                  fprintf(data, "             %-16s  %g;\n", model.cName[i], model.vName[i]);
             }
         }
         else if(saveTool->modelS.index == saveTool->SSTLM )
         {
             if(i==12 || i==21 )
             {
                 if(int(model.vName[i]))
                     fprintf(data, "             %-16s  yes;\n", model.cName[i], model.vName[i]);
                 else
                     fprintf(data, "             %-16s  no;\n", model.cName[i], model.vName[i]);
             }
             else
             {
                 fprintf(data, "             %-16s  %g;\n", model.cName[i], model.vName[i]);
             }
         }
         else
         {
             fprintf(data, "             %-16s  %g;\n", model.cName[i], model.vName[i]);
         }
    }
    fprintf(data, "     }\n");
    fprintf(data, "}\n");
    printFoot(data);
    fclose(data);
}

void printTool::printMaterial(MATERIAL mt, QString loc)
{
    QString workPath = QDir::currentPath();
    QString file;
    if(saveTool->getVersion("printTool printMaterial 1").toInt()==10)
        file = workPath + "/constant/physicalProperties";
    else if(saveTool->getVersion("printMaterial 2").toInt()==5 )
    {
        if(saveTool->incompressible)
            file = workPath + "/constant/transportProperties";
        else
            file = workPath + "/constant/thermophysicalProperties";
    }

    loc = QString
    (
      "void printTool::printMaterial(MATERIAL mt, QString loc)\n"
    ) + loc;
    FILE *data = fopen(file.toLocal8Bit().data(), "w");
    fileCheck(loc, data, file);

    if(saveTool->getVersion("printTool.h printMaterial 3").toInt() == 5)
    {
        if(saveTool->incompressible)
            printHeader(data,"constant","transportProperties","dictionary");
        else
            printHeader(data,"constant","thermophysicalProperties","dictionary");
    }
    else
        printHeader(data,"constant","physicalProperties","dictionary");
    printFoot(data);
    if(!saveTool->mThermal.heat)
    {
        if(saveTool->getVersion("printTool.h printMaterial 4").toInt() == 5 && saveTool->incompressible)
            fprintf(data, "\ntransportModel Newtonian;\n");
        else
            fprintf(data, "\nviscosityModel  constant;\n");
        for(int i=0; i<MATERIAL_NUM; i++)
        {
            fprintf(data, "%s       %s %lf;\n",
                    saveTool->mtName[i].toLocal8Bit().data(),
                    saveTool->mtDimension[i].toLocal8Bit().data(),
                    mt.materials[i]);
        }
    }
    else
    {
        if(saveTool->getVersion("printTool.h printMaterial 5").toInt() == 5 && saveTool->incompressible)
        {
            fprintf(data, "\ntransportModel Newtonian;\n");
            for(int i=0; i<MATERIAL_NUM; i++)
            {
                fprintf(data, "%s       %s %lf;\n",
                        saveTool->mtName[i].toLocal8Bit().data(),
                        saveTool->mtDimension[i].toLocal8Bit().data(),
                        mt.materials[i]);
            }
        }
        else
        {
            QStringList label;
            label<<"type"<<"mixture"<<"transport"<<"thermo"
                <<"equationOfState"<<"specie"<<"energy";
            QList<QStringList> vDict;
            QStringList lst1, lst2,lst3,lst4,lst5,lst6, lst7;
            lst1<<"heRhoThermo";
            lst2<<"pureMixture";
            lst3<<"const"<<"sutherland"<<"polynomial"<<"logPolynomial"<<"Andrade"
               <<"tabulated"<<"icoTabulated"<<"WLF";
            lst4<<"hConst"<<"eConst"<<"janaf";
            lst5<<"Boussinesq"<<"rPolynomial"<<"perfectGas"<<"adiabaticPerfectFluid"
               <<"icoPolynomial"<<"icoTabulated"<<"incompressiblePerfectGas"<<"linear"
               <<"PengRobinsonGas"<<"perfectFluid"<<"rhoConst"<<"rhoTabulated";
            lst6<<"specie";
            lst7<<"sensibleEnthalpy";
            vDict.append(lst1);
            vDict.append(lst2);
            vDict.append(lst3);
            vDict.append(lst4);
            vDict.append(lst5);
            vDict.append(lst6);
            vDict.append(lst7);

            fprintf(data, "\nthermoType\n{\n");
            for(int i=0; i<7; i++)
            {
                int index = saveTool->mThermal.type[i].toInt();
                fprintf(data, "     %-20s  %s;\n", label[i].toLocal8Bit().data(), vDict[i][index].toLocal8Bit().data());
            }
            fprintf(data, "}\n\n");
            fprintf(data, "mixture\n{\n");
            printThermal(data, saveTool->mThermal.value[0], "specie");
            printThermal(data, saveTool->mThermal.value[1], "thermodynamics");
            printThermal(data, saveTool->mThermal.value[2], "transport");
            printThermal(data, saveTool->mThermal.value[3], "equationOfState");
            fprintf(data, "}\n\n");
        }
    }
    fprintf(data, "%s\n", saveTool->mtAdditional.toLocal8Bit().data());
    printFoot(data);
    fclose(data);
}

void printTool::printThermal(FILE *data, QString value, QString name)
{
    QStringList lst = value.split("\n");
    fprintf(data, "     %s\n", name.toLocal8Bit().data());
    fprintf(data, "     {\n");
    for(int i=0; i<lst.size(); i++)
        fprintf(data, "         %s\n", lst[i].toLocal8Bit().data());
    fprintf(data, "     }\n");
}

void printTool::printSchemes(pSCHEME list, QString loc)
{
    saveTool->scheme = list;

    QString workPath = QDir::currentPath();
    QString file = workPath + "/system/fvSchemes";
    loc = QString
    (
      "void printTool::printSchemes(QList<SCHEME> list, QString loc)\n"
    ) + loc;
    FILE *data = fopen(file.toLocal8Bit().data(), "w");
    fileCheck(loc, data, file);
    printHeader(data,"system","fvSchemes","dictionary");
    printFoot(data);

    //  time
    fprintf(data, "\nddtSchemes\n{\n");
    for(int i=0; i<list.ddt.size(); i++)
    {
        if(list.ddt[i].schemeIndex==2)
            fprintf(data, "     %s      %s    %s;\n",
                list.ddt[i].name.toLocal8Bit().data(),
                list.ddt[i].scheme.toLocal8Bit().data(),
                list.ddt[i].other.toLocal8Bit().data());
        else
            fprintf(data, "     %s     %s;\n",
                list.ddt[i].name.toLocal8Bit().data(),
                list.ddt[i].scheme.toLocal8Bit().data()
                );

    }
    fprintf(data, "}\n\n");
    fprintf(data, "gradSchemes\n{\n");
    for(int i=0; i<list.grad.size(); i++)
    {
        if(list.grad[i].firstIndex==0)
            fprintf(data, "     %s      %s    %s;\n",
                list.grad[i].name.toLocal8Bit().data(),
                list.grad[i].scheme.toLocal8Bit().data(),
                list.grad[i].other.toLocal8Bit().data());
        else
            fprintf(data, "     %s      %s    %s    %s;\n",
                list.grad[i].name.toLocal8Bit().data(),
                list.grad[i].first.toLocal8Bit().data(),
                list.grad[i].scheme.toLocal8Bit().data(),
                list.grad[i].other.toLocal8Bit().data());
    }
    fprintf(data, "}\n\n");
    fprintf(data, "divSchemes\n{\n");
    for(int i=0; i<list.div.size(); i++)
    {
        if(list.div[i].firstIndex==0)
        {
            printSchemesDetail(data, " ", list, i);
        }
        else
        {
            printSchemesDetail(data, "bounded", list, i);
        }
    }
    fprintf(data, "}\n\n");
    fprintf(data, "laplacianSchemes\n{\n");
    for(int i=0; i<list.lap.size(); i++)
    {
        if(list.lap[i].firstIndex==1)
        {
            fprintf(data, "     %s    %s",
                list.lap[i].name.toLocal8Bit().data(),
                list.lap[i].scheme.toLocal8Bit().data());
            if(!list.lap[i].other.isEmpty())
                fprintf(data, "  %s;\n", list.lap[i].other.toLocal8Bit().data());
            else
                fprintf(data, ";\n");
        }
        else
        {
            fprintf(data, "     %s      %s    %s",
                list.lap[i].name.toLocal8Bit().data(),
                list.lap[i].first.toLocal8Bit().data(),
                list.lap[i].scheme.toLocal8Bit().data()
                );
            if(!list.lap[i].other.isEmpty())
                fprintf(data, "  %s;\n", list.lap[i].other.toLocal8Bit().data());
            else
                fprintf(data, ";\n");
        }
    }
    fprintf(data, "}\n\n");
    fprintf(data, "snGradSchemes\n{\n");
    for(int i=0; i<list.snG.size(); i++)
    {
        fprintf(data, "     %s    %s;\n",
            list.snG[i].name.toLocal8Bit().data(),
            list.snG[i].scheme.toLocal8Bit().data());
    }
    fprintf(data, "}\n\n");
    fprintf(data, "interpolationSchemes\n{\n");
    for(int i=0; i<list.inter.size(); i++)
    {
        fprintf(data, "     %s     %s",
            list.inter[i].name.toLocal8Bit().data(),
            list.inter[i].scheme.toLocal8Bit().data());
        if(!list.inter[i].other.isEmpty())
            fprintf(data, "  %s;\n", list.inter[i].other.toLocal8Bit().data());
        else
            fprintf(data, ";\n");
    }
    fprintf(data, "}\n\n");

    //
    fprintf(data, "fluxRequired\n{\n");
    fprintf(data, "     default         no;\n");
    fprintf(data, "     p;\n}\n");

    //
    fprintf(data, "wallDist\n{\n");
    fprintf(data, "     method meshWave;\n");
    fprintf(data, "}\n");

    printFoot(data);
    fclose(data);
}

void printTool::printSchemesDetail(FILE *data, char bounded[], pSCHEME list, int i)
{
    if(list.div[i].schemeIndex==0)
        fprintf(data, "     %s%*snone;\n",
                list.div[i].name.toLocal8Bit().data(),
                8, " ");
    else
    {
        if(list.div[i].schemeIndex==2) //Limited
            fprintf(data, "     %s%*s%s  Gauss %s    %s;\n",
                list.div[i].name.toLocal8Bit().data(),
                    8, " ", bounded,
                list.div[i].scheme.toLocal8Bit().data(),
                list.div[i].other.toLocal8Bit().data());
        else if(list.div[i].schemeIndex==3)
            fprintf(data, "     %s%*s%s  Gauss %s    grad;\n",
                list.div[i].name.toLocal8Bit().data(),
                    8, " ", bounded,
                list.div[i].scheme.toLocal8Bit().data());
        else
            fprintf(data, "     %s%*s%s  Gauss %s;\n",
                list.div[i].name.toLocal8Bit().data(),
                    8, " ", bounded,
                list.div[i].scheme.toLocal8Bit().data());
    }
}

void printTool::printCtrl(CTRL ctrl, QString loc)
{
    saveTool->ctrlT = ctrl;

    QString workPath = QDir::currentPath();
    QString file = workPath + "/system/controlDict";
    loc = QString
    (
      "void printTool::printCtrl(CTRL ctrl, QString loc)\n"
    ) + loc;
    FILE *data = fopen(file.toLocal8Bit().data(), "w");
    fileCheck(loc, data, file);
    printHeader(data,"system","controlDict","dictionary");
    printFoot(data);
    fprintf(data, "\napplication     %s;\n\n", ctrl.appName.toLocal8Bit().data());
    fprintf(data, "startFrom       %s;\n\n", ctrl.keyBox[0].toLocal8Bit().data());
    fprintf(data, "startTime       %s;\n\n", ctrl.list[0].toLocal8Bit().data());
    fprintf(data, "stopAt          %s;\n\n", ctrl.keyBox[1].toLocal8Bit().data());
    fprintf(data, "endTime         %s;\n\n", ctrl.list[1].toLocal8Bit().data());
    fprintf(data, "deltaT          %s;\n\n", ctrl.list[2].toLocal8Bit().data());
    fprintf(data, "writeControl    %s;\n\n", ctrl.keyBox[2].toLocal8Bit().data());
    fprintf(data, "writeInterval   %s;\n\n", ctrl.list[3].toLocal8Bit().data());
    fprintf(data, "purgeWrite      %s;\n\n", ctrl.list[4].toLocal8Bit().data());
    fprintf(data, "writeFormat     ascii;\n\n");
    fprintf(data, "writePrecision  6;\n\n");
    fprintf(data, "writeCompression off;\n\n");
    fprintf(data, "timeFormat      general;\n\n");
    fprintf(data, "timePrecision   6;\n\n");
    if(ctrl.runModi)
       fprintf(data, "runTimeModifiable true;\n\n");
    else
       fprintf(data, "runTimeModifiable false;\n\n");
    if(ctrl.Co)
       fprintf(data, "maxCo 1.0;\n\n");
    fclose(data);
}

void printTool::printResidual(RESIDUAL re, QString loc)
{
    saveTool->re = re;

    if(re.monitor || re.line)
    {
        QString workPath = QDir::currentPath();
        QString file = workPath + "/system/controlDict";
        loc = QString
        (
          "void printTool::printResidual(RESIDUAL re, QString loc)\n"
        ) + loc;
        FILE *data = fopen(file.toLocal8Bit().data(), "a+");
        fileCheck(loc, data, file);
        fprintf(data, "\nfunctions\n{\n");
        if(re.monitor)
            fprintf(data, "        #includeFunc     residuals\n");
        if(re.line)
        {
            for(int i=0; i<saveTool->lg.size(); i++)
            {
                if(!saveTool->lg[i].type.isEmpty())
                    fprintf(data, "        #includeFunc     line%d\n", i);
            }
            for(int i=0; i<saveTool->sampleSur.size(); i++)
            {
                fprintf(data, "        #includeFunc     %s\n",
                        saveTool->sampleSur[i].name.toLocal8Bit().data());
            }
        }
        if(!saveTool->dParaLst.isEmpty())
        {
            for(int i=0; i<saveTool->dParaLst.size(); i++)
            {
                QString name = saveTool->dParaLst[i].name+saveTool->dParaLst[i].field;
                fprintf(data, "        #includeFunc     %s\n", name.toLocal8Bit().data());
            }
            printSampleField(saveTool->dParaLst, loc);
        }
        fprintf(data, "}\n\n");
        printFoot(data);
        fclose(data);

        if(re.monitor)
        {
            file = workPath +"/system/residuals";
            data = fopen(file.toLocal8Bit().data(), "w");
            fileCheck(loc, data, file);
            printHeader(data,"system","residuals","dictionary");
            printFoot(data);
            fprintf(data, "\n#includeEtc \"caseDicts/postProcessing/numerical/residuals.cfg\"\n\n");
            fprintf(data, "fields  (%s);\n\n", re.para.toLocal8Bit().data());
            printFoot(data);
            fclose(data);
        }
    }
    else
    {
       /* QString workPath = QDir::currentPath();
        QString file = workPath +"/system/residuals";
        FILE *data = fopen(file.toLocal8Bit().data(), "r");
        if(data!=NULL)
        {
            QFile::remove(file);
        }
        else
            fclose(data);*/
    }
}

void printTool::printMonitorLine(QList<LINEGRAPH> lg, QString loc)
{
    for(int i=0; i<lg.size(); i++)
    {
        printLineG(lg[i], i);
    }
}

void printTool::printSurfaceMonitor(QList<SURFACEGRAPH> sr, QString loc)
{
    for(int i=0; i<sr.size(); i++)
    {
        printsurfaceG(sr[i], i);
    }
}

void printTool::printSampleField(QList<DEFINEPARA> lst, QString loc)
{
    QString workPath = QDir::currentPath();

    for(int i=0; i<lst.size(); i++)
    {
        QString file = workPath + "/system/"+lst[i].name+lst[i].field;
        loc = QString
        (
          "void printTool::printSampleField(QList<DEFINEPARA> lst, QString loc)\n"
        ) + loc;
        FILE *data = fopen(file.toLocal8Bit().data(), "w");
        fileCheck(loc, data, file);
        printHeader(data,"system/",lst[i].name+lst[i].field,"dictionary");
        printFoot(data);
        fprintf(data, "\ntype            %s;\n", lst[i].name.toLocal8Bit().data() );
        fprintf(data, "libs            (\"libfieldFunctionObjects.so\");\n\n");
        if
        (
                lst[i].name.compare("enstrophy")==0 ||
                lst[i].name.compare("flowType")==0 ||
                lst[i].name.compare("MachNo")==0 ||
                lst[i].name.compare("Lambda2")==0 ||
                lst[i].name.compare("Q")==0 ||
                lst[i].name.compare("vorticity")==0
        )
        {
            fprintf(data, "U               U;");
            fprintf(data, "field           $U;\n\n");
        }
        else if
        (
                lst[i].name.compare("CourantNo")==0 ||
                lst[i].name.compare("PecletNo")==0 ||
                lst[i].name.compare("streamFunction")==0

        )
        {
            fprintf(data, "phi             phi;");
            fprintf(data, "field           $phi;\n\n");
        }
        else if(lst[i].name.compare("wallHeatTransferCoeff")==0)
        {
            fprintf(data, "rho      %e;\n", saveTool->mt.materials[RHO]);
            fprintf(data, "Cp       %e;\n", saveTool->mt.materials[CP]);
            fprintf(data, "Pr              %e;\n", saveTool->mt.materials[PR]);
            fprintf(data, "Prt      %e;\n\n", saveTool->mt.materials[PR]);
        }
        else if(lst[i].name.compare("writeVTK")==0)
        {
            fprintf(data, "objects           %s;\n\n", lst[i].field.toLocal8Bit().data());
        }
        else if
        (
                lst[i].name.compare("wallShearStress")==0 ||
                lst[i].name.compare("wallHeatFlux")==0 ||
                lst[i].name.compare("writeCellCentres")==0 ||
                lst[i].name.compare("writeCellVolumes")==0 ||
                lst[i].name.compare("yPlus")==0
        )
        {
            ;
        }
        else
            fprintf(data, "field           %s;\n\n", lst[i].field.toLocal8Bit().data());

        fprintf(data, "executeControl  writeTime;\n");
        fprintf(data, "writeControl    writeTime;\n\n");
        printFoot(data);
        fclose(data);
    }
}

void printTool::printSolution(QList<SOLUTION> su, RELAXATION re, QString loc)
{
    saveTool->rela = re;

    QString workPath = QDir::currentPath();
    QString file = workPath + "/system/fvSolution";
    loc = QString
    (
      "void printTool::printSolution(QList<SOLUTION> su, QString loc)\n"
    ) + loc;
    FILE *data = fopen(file.toLocal8Bit().data(), "w");
    fileCheck(loc, data, file);
    printHeader(data,"system","fvSolution","dictionary");
    printFoot(data);
    fprintf(data, "\nsolvers\n{\n");
    for(int i=0; i<su.size(); i++)
    {
        fprintf(data, "    %s\n", su[i].name.toLocal8Bit().data());
        fprintf(data, "     {\n");
        fprintf(data, "             solver      %s;\n", su[i].solver.toLocal8Bit().data());
        fprintf(data, "             tolerance   %s;\n", su[i].value[1].toLocal8Bit().data());
        fprintf(data, "             relTol      %s;\n", su[i].value[2].toLocal8Bit().data());
        fprintf(data, "             maxIter     %s;\n", su[i].value[4].toLocal8Bit().data());
        if(su[i].value[0].toInt()==2 || su[i].value[0].toInt()==3) // CG solver
            fprintf(data, "             preconditioner    %s;\n", su[i].pre.toLocal8Bit().data());
        else
        {
            fprintf(data, "             smoother    %s;\n", su[i].smoother.toLocal8Bit().data());
            fprintf(data, "             cacheAgglomeration	true;\n");
            fprintf(data, "             nFinestSweeps	2;\n");
            fprintf(data, "             nPreSweeps	0;\n");
            fprintf(data, "             nPostSweeps	1;\n");
            fprintf(data, "             agglomerator	faceAreaPair;\n");
            fprintf(data, "             nCellsInCoarsestLevel	10;\n");
            fprintf(data, "             mergeLevels	1;\n");
        }
        fprintf(data, "     }\n");
    }
    fprintf(data, "}\n\n");
    fprintf(data, "#include \"solverSettings\"\n\n");
    fprintf(data, "relaxationFactors\n{\n");
    fprintf(data, "    equations\n    {\n");
    QStringList name;
    for(int i=0; i<re.len.toInt(); i++)
    {
        if(re.name[i].compare("p_rgh")==0 || re.name[i].compare("p")==0)
        {
            name.append(re.name[i]);
            name.append(re.value[i]);
            continue;
        }
        fprintf(data, "         %s        %s;\n",
                re.name[i].toLocal8Bit().data(),
                re.value[i].toLocal8Bit().data());
    }
    fprintf(data, "    }\n");
    if(name.size()>0)
    {
        fprintf(data, "    fields\n    {\n");
        for(int i=0; i<name.size(); i=i+2)
            fprintf(data, "         %s        %s;\n",
                    name[i].toLocal8Bit().data(),
                    name[i+1].toLocal8Bit().data());
    }
    fprintf(data, "    }\n");
    fprintf(data, "}\n\n");
    fprintf(data, "%s\n", re.additional.toLocal8Bit().data());
    //printFoot(data);
    fclose(data);
}

void printTool::printSolver(SOLVERSETTING dict, QString loc)
{
    saveTool->sDict = dict;
    QString workPath = QDir::currentPath();
    QString file = workPath + "/system/solverSettings";
    loc = QString
    (
      "void printTool::printSolution(QList<SOLUTION> su, QString loc)\n"
    ) + loc;
    FILE *data = fopen(file.toLocal8Bit().data(), "w");
    fileCheck(loc, data, file);
    printHeader(data,"system","solverSettings","dictionary");
    printFoot(data);
    if(dict.solverDict == C_PIMPLE)
    {
        QStringList nLst;
        nLst<<"nNonOrthogonalCorrectors"<<"nOuterCorrectors"<<"nCorrectors"<<"correctPhi"
           <<"correctMeshPhi"<<"momentumPredictor"<<"pRefPoint"<<"pRefValue";
        fprintf(data, "\nPIMPLE\n{\n");
        for(int i=0; i<pimpleNum; i++)
        {
            fprintf(data, "     %-20s %s;\n",
                nLst[i].toLocal8Bit().data(),
                dict.value[i].toLocal8Bit().data());
        }
        //fprintf(data, "}\n");
    }
    else if(dict.solverDict == C_SIMPLE)
    {
        fprintf(data, "\nSIMPLE\n{\n");
        QStringList nLst;
        nLst<<"nNonOrthogonalCorrectors"<<"consistent"<<"momentumPredictor"<<"pRefPoint"<<"pRefValue";
        for(int i=0; i<simpleNum; i++)
        {
            fprintf(data, "     %-20s %s;\n",
                nLst[i].toLocal8Bit().data(),
                dict.value[i].toLocal8Bit().data());
        }
        //fprintf(data, "}\n");
    }
    else if(dict.solverDict == C_PISO)
    {
        fprintf(data, "\nPISO\n{\n");
        QStringList nLst;
        nLst<<"nNonOrthogonalCorrectors"<<"nOuterCorrectors"<<"nCorrectors"<<"correctPhi"
           <<"correctMeshPhi"<<"momentumPredictor"<<"pRefPoint"<<"pRefValue";
        for(int i=0; i<pimpleNum; i++)
        {
            fprintf(data, "     %-20s %s;\n",
                nLst[i].toLocal8Bit().data(),
                dict.value[i].toLocal8Bit().data());
        }
        //fprintf(data, "}\n");
    }
    fclose(data);
}

void printTool::printResidualControl(QList<unit> ctr, QString loc)
{
    QString workPath = QDir::currentPath();
    QString file = workPath + "/system/solverSettings";
    loc = QString
    (
      "void printTool::printResidualControl(QList<unit> ctr, QString loc)\n"
    ) + loc;
    FILE *data = fopen(file.toLocal8Bit().data(), "a+");
    fileCheck(loc, data, file);
    fprintf(data, "     residualControl\n");
    fprintf(data, "     {\n");
    for(int i=0; i<ctr.size(); i++)
    {
        fprintf(data, "             %s      %s;\n",
                ctr[i].name.toLocal8Bit().data(),
                ctr[i].value.toLocal8Bit().data());
    }
    fprintf(data, "     }\n");
    fprintf(data, "}\n");
    printFoot(data);
    fclose(data);
}

void printTool::printBoundary(BOUNDARY boundary, QString loc)
{
    saveTool->bdr = boundary;
    QString workPath = QDir::currentPath();
    QString file = workPath + "/constant/polyMesh/boundary";
    loc = QString
    (
      "void printTool::printPolyMesh(BOUNDARY boundary, QString loc)\n"
    ) + loc;
    FILE *data = fopen(file.toLocal8Bit().data(), "w");
    fileCheck(loc, data, file);
    printHeader(data,"constant/polyMesh","boundary","dictionary");
    printFoot(data);
    fprintf(data, "\n%s\n(\n", boundary.totalBdr.toLocal8Bit().data());
    for(int i=0; i<boundary.totalBdr.toInt(); i++)
    {
        fprintf(data, "%*s%s\n%*s{\n", 4, " ", boundary.value[i][0].toLocal8Bit().data(), 4, " ");
        fprintf(data, "%*stype%*s%s;\n", 8, " ", 13, " ", boundary.value[i][1].toLocal8Bit().data());
        fprintf(data, "%*snFaces%*s%s;\n", 8, " ", 11, " ",
                boundary.value[i][2].toLocal8Bit().data());
        fprintf(data, "%*sstartFace%*s%s;\n", 8, " ", 8, " ",
                        boundary.value[i][3].toLocal8Bit().data());
        fprintf(data, "%*s}\n", 4, " ");
    }
    fprintf(data, ")\n\n");
    printFoot(data);
    fclose(data);

    QString dirName = workPath +"/0.orig";
    QDir dir(dirName);
    bool su = true;
    if(!dir.exists())
        su = dir.mkdir(dirName);
    if(su)
    {
        //--- detail boundary
        int count = boundary.paraName[0].size()+boundary.paraName[1].size();
        for(int i=0; i<count; i=i+2)
            printBoundaryDetail(boundary, i, loc);
    }
    else
    {
        Mess mes;
        mes.Fun = "void printTool::printBoundary(BOUNDARY boundary, QString loc)";
        mes.Head = "printTool.h";
        mes.Loc = "print detail boundary";
        mes.title = "Warnning";
        mes.Mess = "cannot create the 0.orig folder";
        HError HFASTError;
        HFASTError.HFASTWarning(mes);
    }

}

void printTool::printBoundaryDetail(BOUNDARY boundary, int paraIndex, QString loc)
{
    QStringList paraName;
    for(int i=0; i<boundary.paraName[0].size(); i++)
        paraName.append(boundary.paraName[0][i]);
    for(int i=0; i<boundary.paraName[1].size(); i++)
        paraName.append(boundary.paraName[1][i]);

    QString workPath = QDir::currentPath();
    QString file = workPath + "/0.orig/"+paraName[paraIndex];
    loc = QString
    (
      "void printTool::printBoundaryDetail(BOUNDARY boundary, int paraIndex, QString loc)\n"
    ) + loc;
    FILE *data = fopen(file.toLocal8Bit().data(), "w");
    fileCheck(loc, data, file);
    QString name = paraName[paraIndex];
    if(QString("U").compare(name)==0 || QString("U.orig").compare(name)==0)
        printHeader(data,"0",name,"volVectorField");
    else
        printHeader(data,"0",name,"volScalarField");
    printFoot(data);
    fprintf(data, "\ndimensions%*s%s;\n\n", 9, " ", paraName[paraIndex+1].toLocal8Bit().data());
    fprintf(data, "internalField%*s%s\n\n", 6, " ", boundary.internal[paraIndex/2].toLocal8Bit().data());
    fprintf(data, "boundaryField\n{\n");
    {
        for(int j=0; j<boundary.totalBdr.toInt(); j++)
        {
            fprintf(data, "%*s%s\n%*s{\n", 4, " ", boundary.value[j][0].toLocal8Bit().data(), 4, " ");
            QStringList lst = boundary.paraValue[paraIndex/2][j].split("\n");
            for(int k=0; k<lst.size(); k++)
                fprintf(data, "%*s%s\n", 8, " ", lst[k].toLocal8Bit().data());
            fprintf(data, "%*s}\n\n", 4, " ");
        }
    }
    fprintf(data, "}\n");
    fclose(data);
}

void printTool::initBasic(QString loc)
{
    version = saveTool->getVersion("printTool.h initBasic");
}

void printTool::fileCheck(QString loc, FILE *data, QString file)
{
    Mess mes;
    mes.Fun = "void printTool::fileCheck(Mess mes, FILE *data, QString file)";
    mes.Head = "printTool.h";
    mes.title = "Critical Error";
    mes.Loc = loc;
    mes.Mess = "Cannot create given file in the directory";
    HError HFASTError;
    if(data==NULL)
    {
        int mark = HFASTError.HFASTCritical(mes);
        if(mark==1)
            return;
        else if(mark==2)
            return;
    }
}

void printTool::printLineG(LINEGRAPH lg, int index)
{
    QString workPath = QDir::currentPath();
    QString name = "line"+QString::number(index);;
    QString file = workPath + "/system/"+name;
    FILE *data = fopen(file.toLocal8Bit().data(), "w");
    fileCheck("void printTool::printLineG(LINEGRAPH lg, int index)", data, file);
    if(data!=NULL)
    {
        printHeader(data,"system",name,"dictionary");
        printFoot(data);
        fprintf(data, "\nstart  (%s %s %s);\n",
                lg.points[0].toLocal8Bit().data(),
                lg.points[1].toLocal8Bit().data(),
                lg.points[2].toLocal8Bit().data());
        fprintf(data, "end  (%s %s %s);\n\n",
                lg.points[3].toLocal8Bit().data(),
                lg.points[4].toLocal8Bit().data(),
                lg.points[5].toLocal8Bit().data());
        fprintf(data, "fields  (%s);\n\n", lg.field.toLocal8Bit().data());
        if(saveTool->getVersion("printTool.h printLineG 1").toInt() == 10 || saveTool->getVersion("printTool.h printLineG 2").toInt()  == 9)
        {
            fprintf(data, "#includeEtc \"caseDicts/postProcessing/graphs/graph.cfg\"\n");
            fprintf(data, "sets\n(\n");
            fprintf(data, "%s\n{\n", name.toLocal8Bit().data());
            fprintf(data, "     type    %s;\n", lg.type.toLocal8Bit().data());
            fprintf(data, "     axis    %s;\n", lg.axis.toLocal8Bit().data());
            fprintf(data, "     start   $start;\n");
            fprintf(data, "     end     $end;\n");
            fprintf(data, "     nPoints 100;\n});\n\n");
        }
        else
        {
            fprintf(data, "#includeEtc \"caseDicts/postProcessing/graphs/sampleDict.cfg\"\n");
            fprintf(data, "interpolationScheme cellPoint;\n");
            fprintf(data, "setFormat   raw;\n");
            fprintf(data, "setConfig\n{\n");
            fprintf(data, "     type    %s;\n", lg.type.toLocal8Bit().data());
            fprintf(data, "     axis    %s;\n", lg.axis.toLocal8Bit().data());
            fprintf(data, "     nPoints 100;\n}\n\n");
            fprintf(data, "type     sets;\n");
            fprintf(data, "libs     (\"libsampling.so\");\n");
            fprintf(data, "writeControl    writeTime;\n");
            fprintf(data, "sets\n(\n");
            fprintf(data, "     %s\n{\n", name.toLocal8Bit().data());
            fprintf(data, "     $setConfig;\n");
            fprintf(data, "     start $start;\n");
            fprintf(data, "     end   $end;\n}\n);");
        }
        printFoot(data);
        fclose(data);
    }
}

void printTool::printsurfaceG(SURFACEGRAPH sr, int index)
{
    QString workPath = QDir::currentPath();
    QString name = sr.name;
    QString file = workPath + "/system/"+name;
    FILE *data = fopen(file.toLocal8Bit().data(), "w");
    fileCheck("void printTool::printsurfaceG(SURFACEGRAPH sr, int index)", data, file);
    if(data!=NULL)
    {
        printHeader(data,"system",name,"dictionary");
        printFoot(data);
        fprintf(data, "\npoint  (%s %s %s);\n",
                sr.points[0].toLocal8Bit().data(),
                sr.points[1].toLocal8Bit().data(),
                sr.points[2].toLocal8Bit().data());
        if(sr.normal.compare("0")==0)
            fprintf(data, "normal  (1 0 0);\n\n");
        else if(sr.normal.compare("1")==0)
            fprintf(data, "normal  (0 1 0);\n\n");
        else
            fprintf(data, "normal  (0 0 1);\n\n");
        fprintf(data, "fields  (%s);\n\n", sr.field.toLocal8Bit().data());
        {
            fprintf(data, "interpolate true;\n");
            fprintf(data, "type            surfaces;\n");
            fprintf(data, "libs            (\"libsampling.so\");\n\n");
            fprintf(data, "writeControl    writeTime;\n");
            fprintf(data, "surfaceFormat   raw;\n");
            fprintf(data, "interpolationScheme cellPoint;\n");
            fprintf(data, "surfaces\n(\n");
            fprintf(data, "%s\n{\n", name.toLocal8Bit().data());
            fprintf(data, "     type    cuttingPlane;\n");
            fprintf(data, "     interpolate $interpolate;\n");
            fprintf(data, "     planeType   pointAndNormal;\n");
            fprintf(data, "     point       $point;\n");
            fprintf(data, "     normal      $normal;\n});\n\n");
        }
        printFoot(data);
        fclose(data);
    }
}
