#ifndef BOUNDARYPANEL_H
#define BOUNDARYPANEL_H

#include "printTool.h"
#include "readBoundary.h"
#include <QObject>
#include <QSplitter>

class boundarySetting;
class HComboBox;

class boundaryPanel : public QWidget
{
    Q_OBJECT
public:
    explicit boundaryPanel(printTool *p, QWidget *w);
    printTool *pEvent;
    readBoundary *rBdr;
    QComboBox **value;
    QStringList nameLst;
    BOUNDARY bdr;
    QStringList boundaryName;
    QScrollArea *scroArea;

private:
    QVBoxLayout *vlayout;
    QWidget *basicBdr;
    QLabel **name;
    QHBoxLayout **hLayout;
    QVBoxLayout *bVLayout;
    int totalBasic;
    void deleteBasic(QStringList lst);
    void defineBasic(QStringList lst);
    int modelIndex, solverIndex, solverSelect;

    QTabWidget *tab;
    boundarySetting **bdrVara;
    QSplitter *slpliter;

public:
    int setUpPanel
    (
            QList<QStringList> paraName,
            QStringList name,
            int modelIndex,
            int solverIndex,
            int solverSelect
    );
    int defineMeshPanel();
    void delecteMeshPanel();
    int saveProject();
    void readProject();

};

class boundarySetting : public QScrollArea
{
    Q_OBJECT
public:
    explicit boundarySetting();
    QPlainTextEdit **edit;
    HComboBox **value;
    QLineEdit *interValue;
    QStringList bdrLst;
    QStringList bdrValueLst;
private:
    QLabel **name;
    QHBoxLayout **hLayout;
    QVBoxLayout *vLayout;
    QHBoxLayout *interLayout;
    int count;
    //QScrollArea *scroArea;
    QWidget *widget;


    QVector<int> lastIndex;
    QList<int> lastLastIndex;
    int countIndex;
    QString  *lastResults;

public:
    void defineWidget(BOUNDARY bdr);
    void deleteWidget();
    void setUpPanel(BOUNDARY bdr);


public slots:
    void defineBoundary(int index, int editIndex);
    void defineBoundaryAuto(int index, int editIndex);
    int getTheBdrID(QString bdrName);
};

class HComboBox : public QComboBox
{
    Q_OBJECT
public:
    HComboBox(int id);
    int idx;

protected:
    void wheelEvent(QWheelEvent *e);
signals:
    void activated(int currentIndex, int idx);

public slots:
    void triggered();
};

#endif // BOUNDARYPANEL_H
