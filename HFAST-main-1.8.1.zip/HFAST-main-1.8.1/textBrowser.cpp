#include "textBrowser.h"

textBrowser::textBrowser(QWidget *parent) : QPlainTextEdit(parent)
{
    connect(msgHandle::instance(),
            SIGNAL(message(QtMsgType,QString)),
            SLOT(outputMessage(QtMsgType,QString)));
    this->setMaximumBlockCount(2000);
    run = new basic;
    qDebug()<<BROWSER;
}

void textBrowser::outputMessage(const textBrowser::MessageLevel &level, const QString &msg)
{
    appendPlainText(msg);
    this->moveCursor(QTextCursor::End);
}

void textBrowser::keyPressEvent(QKeyEvent *e)
{
    if(e->key()==Qt::Key_Return || e->key()==Qt::Key_Enter)
    {
        runMsgCommand();
    }
    else
    {
        QPlainTextEdit::keyPressEvent(e);
    }
}

void textBrowser::outputMessage(QtMsgType type, const QString &msg)
{
    switch(type)
    {
        case QtDebugMsg:
             outputMessage(NORMAL_LEVAL, msg);
        break;
        case QtInfoMsg:
             outputMessage(NORMAL_LEVAL, msg);
        break;
        case QtWarningMsg:
             outputMessage(WARNING_LEVEL, msg);
        break;
        case QtCriticalMsg:
             outputMessage(ERROR_LEVAL, msg);
        break;
        case QtFatalMsg:
             outputMessage(ERROR_LEVAL, msg);
        break;
    }
}

void textBrowser::runMsgCommand()
{
    QString qbt;
    qbt = QString::number(this->document()->lineCount());
    qbt = this->document()->findBlockByLineNumber(qbt.toInt()-1).text();
    qbt = qbt.replace(BROWSER, "");

   // QString version = run->getVersion("textBrowser:: runMsgCommand()");
    //run->bashrc = run->getBashrc();
    run->runCommand(qbt);
}
