#ifndef THERMAVALUE_H
#define THERMAVALUE_H

#include <QWidget>
#include "thermal.h"
#include <QLineEdit>
#include "basicdefine.h"

class thermaValue : public QWidget
{
    Q_OBJECT
    #define THERMALVALUENUM 4
public:
    explicit thermaValue(thermal *tGroup);
    thermal *thm;
    QLabel *name[THERMALVALUENUM];
    QPlainTextEdit *textEdit[THERMALVALUENUM];

    QStringList save();
    void read(QStringList lst);
    bool change;
    QStringList vList;

private:
    QVBoxLayout *vLayout;
    QHBoxLayout *hLayout[6];
    MATERIAL mts;
    void defineSpecie();
    void defineEq();
    void defineTher();
    void defineTran();

signals:

public slots:
    void defineValue(MATERIAL mt);
    void thermoChange(int idx);
};

#endif // THERMAVALUE_H
