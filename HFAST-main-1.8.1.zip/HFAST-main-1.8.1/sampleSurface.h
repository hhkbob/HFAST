#ifndef SAMPLESURFACE_H
#define SAMPLESURFACE_H

#include <QWidget>
#include "printTool.h"

namespace Ui {
class sampleSurface;
}

class sampleSurface : public QWidget
{
    Q_OBJECT

public:
    explicit sampleSurface(QWidget *parent = 0);
    ~sampleSurface();
    QList<SURFACEGRAPH> sGraphList;
    int count;

    void definePanel(QList<SURFACEGRAPH>);

private slots:
    void on_pushButton_clicked();

    void on_delete_2_clicked();

    void show(int);

private:
    Ui::sampleSurface *ui;
};

#endif // SAMPLESURFACE_H
