#include "controlPanel.h"

controlPanel::controlPanel(printTool *p, QWidget *widget)
{
    pEvent = p;

    //  define application
    defineSolver();
    definePanel(widget);
}

controlPanel::~controlPanel()
{
    delete title;
    delete app;
    delete sTitle;
    delete solver;
    delete sButGroup;
    delete sLayout;
    delete sVLayout;
    delete sGroup;

    delete keyName;
    delete keyBox;
    delete keyLine;
    delete keyLayout;
    delete kLayout;

    delete vLayout;
}

void controlPanel::saveProject()
{
    ctrlT.appIndex = app->currentIndex();
    ctrlT.appName = app->currentText();
    ctrlT.startFromIndex = keyBox[0]->currentIndex();
    ctrlT.keyBox[0] = keyBox[0]->currentText();
    ctrlT.stopAtIndex = keyBox[1]->currentIndex();
    ctrlT.keyBox[1] = keyBox[1]->currentText();
    ctrlT.writeControlIndex = keyBox[2]->currentIndex();
    ctrlT.keyBox[2] = keyBox[2]->currentText();
    ctrlT.runModi = runModif->isChecked();
    ctrlT.Co = Co->isChecked();
    for(int i=0; i<5; i++)
    {
        ctrlT.list[i]=keyLine[i]->text();
    }
    ctrlT.solverDict = solverDict[ctrlT.appSelect][ctrlT.appIndex];
    pEvent->saveTool->incompressible = solverInCompressilbel[ctrlT.appSelect][ctrlT.appIndex];

    qDebug()<<"save for ";
    qDebug()<<pEvent->saveTool->incompressible;

    pEvent->printCtrl(ctrlT, "void controlPanel::saveProject()");
    SOLVERSETTING sDict;
    if(ctrlT.solverDict==C_SIMPLE)
    {
        sDict = sPanel->sSolver->saveEvery();
        sDict.len = simpleNum;

    }
    else if(ctrlT.solverDict==C_PIMPLE)
    {
        sDict = sPanel->pSolver->saveEvery();
        sDict.len = pimpleNum;
    }
    else if(ctrlT.solverDict==C_PISO)
    {
        sDict = sPanel->piSolver->saveEvery();
        sDict.solverDict = C_PISO;
        sDict.len = pimpleNum;
    }
    pEvent->printSolver(sDict, "void controlPanel::saveProject()");

    //--Eq


}

void controlPanel::readproject()
{
    ctrlT = pEvent->saveTool->ctrlT;
    emit sButGroup->buttonClicked(ctrlT.appSelect);
    app->setCurrentIndex(ctrlT.appIndex);
    solver[ctrlT.appSelect]->setChecked(true);
    keyBox[0]->setCurrentIndex(ctrlT.startFromIndex);
    keyBox[1]->setCurrentIndex(ctrlT.stopAtIndex);
    keyBox[2]->setCurrentIndex(ctrlT.writeControlIndex);
    for(int i=0; i<5; i++)
    {
        keyLine[i]->setText(ctrlT.list[i]);
    }
    runModif->setChecked(ctrlT.runModi);
    Co->setChecked(ctrlT.Co);

    emit sendAppName(app->currentText());

    SOLVERSETTING dict = pEvent->saveTool->sDict;
    emit solverChoose(dict.solverDict);
    if(dict.solverDict==C_SIMPLE)
        sPanel->sSolver->readEvery(dict);
    else if(dict.solverDict==C_PIMPLE)
        sPanel->pSolver->readEvery(dict);
    else if(dict.solverDict==C_PISO)
        sPanel->piSolver->readEvery(dict);
}

void controlPanel::defineSolver()
{
    QStringList lst0;
    QStringList lst;
    QList<QStringList> desLst, desLst0;

    //basic
    {
        solverName[0].append("laplacianFoam");
        solverDict[0].append(C_SIMPLE);
        solverInCompressilbel[0].append(true);
        lst<<"T"<<"[0 0 0 1 0 0 0]";
        desLst.append(lst);
        solverEq[0].append(desLst);

        solverName[0].append("potentialFoam");
        solverDict[0].append(C_PONTENTIAL);
        solverInCompressilbel[0].append(true);
        lst=lst0;
        desLst = desLst0;
        if(pEvent->saveTool->Version.toInt()== 10)
            lst<<"p.org"<<"[0 2 -2 0 0 0 0]"<<"U.org"<<"[0 1 -1 0 0 0 0]";
        else if(pEvent->saveTool->Version.toInt()== 5)
            lst<<"p"<<"[0 2 -2 0 0 0 0]"<<"U"<<"[0 1 -1 0 0 0 0]";
        desLst.append(lst);
        solverEq[0].append(desLst);

        solverName[0].append("scalarTransportFoam");
        solverDict[0].append(C_SIMPLE);
        solverInCompressilbel[0].append(true);
        lst=lst0;
        desLst = desLst0;
        lst<<"T"<<"[0 0 0 1 0 0 0]"<<"U"<<"[0 1 -1 0 0 0 0]";
        desLst.append(lst);
        solverEq[0].append(desLst);
    }

    //  combustion
    {
        solverName[1].append("chemFoam");
        solverDict[1].append(-1);
        solverInCompressilbel[1].append(false);
        lst=lst0;
        desLst = desLst0;
        lst<<"T"<<"[0 0 0 1 0 0 0]"<<"U"<<"[0 1 -1 0 0 0 0]";
        desLst.append(lst);
        solverEq[1].append(desLst);

        if(pEvent->saveTool->Version.toInt()== 10)
        {
            solverName[1].append("buoyantReactingFoam");
            solverDict[1].append(C_PIMPLE);
            solverInCompressilbel[1].append(false);
            lst=lst0;
            desLst = desLst0;
            lst<<"T"<<"[0 0 0 1 0 0 0]"<<"U"<<"[0 1 -1 0 0 0 0]"<<"nut"<<"[0 2 -1 0 0 0 0]"
              <<"p"<<"[1 -1 -2 0 0 0 0]"<<"p_rgh"<<"[1 -1 -2 0 0 0 0]";
            desLst.append(lst);
            solverEq[1].append(desLst);
        }

        solverName[1].append("PDRFoam");
        solverDict[1].append(C_PIMPLE);
        solverInCompressilbel[1].append(false);
        lst=lst0;
        desLst = desLst0;
        if(pEvent->saveTool->Version.toInt()== 10)
            lst<<"T.orig"<<"[0 0 0 1 0 0 0]"<<"U.orig"<<"[0 1 -1 0 0 0 0]"<<"nut.orig"<<"[0 2 -1 0 0 0 0]"
             <<"p.orig"<<"[1 -1 -2 0 0 0 0]"<<"alphat.orig"<<"[1 -1 -1 0 0 0 0]";
        else if(pEvent->saveTool->Version.toInt()== 5)
        {
            lst<<"T"<<"[0 0 0 1 0 0 0]"<<"U"<<"[0 1 -1 0 0 0 0]"<<"nut"<<"[0 2 -1 0 0 0 0]"
             <<"p"<<"[1 -1 -2 0 0 0 0]"<<"alphat"<<"[1 -1 -1 0 0 0 0]";
        }

        desLst.append(lst);
        solverEq[1].append(desLst);
    }
    //  compressible
    {
        solverName[2].append("rhoCentralFoam");
        solverDict[2].append(-1);
        solverInCompressilbel[2].append(false);
        lst=lst0;
        desLst = desLst0;
        lst<<"T"<<"[0 0 0 1 0 0 0]"<<"U"<<"[0 1 -1 0 0 0 0]"<<"p"<<"[1 -1 -2 0 0 0 0]";
        desLst.append(lst);
        solverEq[2].append(desLst);
    }

    //  discreteMethods
    {
        solverName[3].append("dsmcFoam");
        solverDict[3].append(-1);
        solverInCompressilbel[3].append(false);
        lst=lst0;
        desLst = desLst0;
        lst<<"momentum"<<"[1 -2 -1 0 0 0 0]"<<"q"<<"[1 0 -3 0 0 0 0]"<<"boundaryT"<<"[0 0 0 1 0 0 0]"
          <<"boundaryU"<<"[0 1 -1 0 0 0 0]"<<"dsmcRhoN"<<"[0 -3 0 0 0 0 0]"<<"fD"<<"[1 -1 -2 0 0 0 0]"
         <<"iDof"<<"[0 -3 0 0 0 0 0]"<<"rhoM"<<"[1 -3 0 0 0 0 0]"<<"rhoN"<<"[0 -3 0 0 0 0 0]";
        desLst.append(lst);
        solverEq[3].append(desLst);
    }

    //  DNS
    {
        solverName[4].append("dnsFoam");
        solverDict[4].append(C_PISO);
        solverInCompressilbel[4].append(true);
        lst=lst0;
        desLst = desLst0;
        if(pEvent->saveTool->Version.toInt()== 10)
           lst<<"U.orig"<<"[0 1 -1 0 0 0 0]"<<"p"<<"[0 2 -2 0 0 0 0]";
        else if(pEvent->saveTool->Version.toInt()== 5)
            lst<<"U"<<"[0 1 -1 0 0 0 0]"<<"p"<<"[0 2 -2 0 0 0 0]";
        desLst.append(lst);
        solverEq[4].append(desLst);
    }

    //  heat transfer
    {
        if(pEvent->saveTool->Version.toInt()== 10)
        {
            solverName[5].append("buoyantFoam");
            solverDict[5].append(C_PIMPLE);
            solverInCompressilbel[5].append(false);
            lst=lst0;
            desLst = desLst0;
            lst<<"U"<<"[0 1 -1 0 0 0 0]"<<"p"<<"[1 -1 -2 0 0 0 0]"<<"p_rgh"<<"[1 -1 -2 0 0 0 0]"
              <<"alphat"<<"[1 -1 -1 0 0 0 0]"<<"T.orig"<<"[0 0 0 1 0 0 0]"<<"nut"<<"[0 2 -1 0 0 0 0]";
            desLst.append(lst);
            solverEq[5].append(desLst);
        }
        else if(pEvent->saveTool->Version.toInt()== 5)
        {
            solverName[5].append("buoyantBoussinesqSimpleFoam");
            solverDict[5].append(C_SIMPLE);
            solverInCompressilbel[5].append(true);
            lst=lst0;
            desLst = desLst0;
            lst<<"U"<<"[0 1 -1 0 0 0 0]"<<"p"<<"[0 2 -2 0 0 0 0]"<<"p_rgh"<<"[0 2 -2 0 0 0 0]"
              <<"alphat"<<"[0 2 -1 0 0 0 0]"<<"T"<<"[0 0 0 1 0 0 0]"<<"nut"<<"[0 2 -1 0 0 0 0]";
            desLst.append(lst);
            solverEq[5].append(desLst);
        }

        solverName[5].append("chtMultiRegionFoam");
        solverDict[5].append(C_PIMPLE);
        solverInCompressilbel[5].append(false);
        lst=lst0;
        desLst = desLst0;
        lst<<"U"<<"[0 1 -1 0 0 0 0]"<<"p"<<"[1 -1 -2 0 0 0 0]"<<"p_rgh"<<"[1 -1 -2 0 0 0 0]"
          <<"alphat"<<"[1 -1 -1 0 0 0 0]"<<"T"<<"[0 0 0 1 0 0 0]"<<"nut"<<"[0 2 -1 0 0 0 0]";
        desLst.append(lst);
        solverEq[5].append(desLst);

    }

    //  multiphase
    {
        solverName[6].append("interFoam");
        solverDict[6].append(C_PIMPLE);
        solverInCompressilbel[6].append(true);
        lst=lst0;
        desLst = desLst0;
        lst<<"U"<<"[0 1 -1 0 0 0 0]"<<"p_rgh"<<"[1 -1 -2 0 0 0 0]"
          <<"alpha.water.orig"<<"[0 0 0 0 0 0 0]"<<"nut"<<"[0 2 -1 0 0 0 0]";
        desLst.append(lst);
        solverEq[6].append(desLst);

        /*solverName[6].append("interMixingFoam");
        solverDict[6].append(C_PIMPLE);
        lst=lst0;
        desLst = desLst0;
        lst<<"U"<<"[0 1 -1 0 0 0 0]"<<"p_rgh"<<"[1 -1 -2 0 0 0 0]"
          <<"alpha.water.orig"<<"[0 0 0 0 0 0 0]"<<"nut"<<"[0 2 -1 0 0 0 0]";
        desLst.append(lst);
        solverEq[6].append(desLst);*/
    }

    //  imcompressible
    {
        solverName[7].append("simpleFoam");
        solverDict[7].append(C_SIMPLE);
        solverInCompressilbel[7].append(true);
        lst=lst0;
        desLst = desLst0;
        lst<<"U"<<"[0 1 -1 0 0 0 0]"<<"p"<<"[0 2 -2 0 0 0 0]"
          <<"nut"<<"[0 2 -1 0 0 0 0]";
        desLst.append(lst);
        solverEq[7].append(desLst);


        solverName[7].append("pimpleFoam");
        solverDict[7].append(C_PIMPLE);
        solverInCompressilbel[7].append(true);
        lst=lst0;
        desLst = desLst0;
        lst<<"U"<<"[0 1 -1 0 0 0 0]"<<"p"<<"[0 2 -2 0 0 0 0]"
          <<"nut"<<"[0 2 -1 0 0 0 0]";
        desLst.append(lst);
        solverEq[7].append(desLst);

        solverName[7].append("pisoFoam");
        solverDict[7].append(C_PISO);
        solverInCompressilbel[7].append(true);
        lst=lst0;
        desLst = desLst0;
        lst<<"U"<<"[0 1 -1 0 0 0 0]"<<"p"<<"[0 2 -2 0 0 0 0]"
          <<"nut"<<"[0 2 -1 0 0 0 0]";
        desLst.append(lst);
        solverEq[7].append(desLst);
    }
}

void controlPanel::definePanel(QWidget *w)
{
    vLayout = new QVBoxLayout;

    sTitle = new QHBoxLayout;
    app = new QComboBox;
    title = new QLabel(tr("Application"));
    sTitle->addWidget(title);
    sTitle->addWidget(app);
    //sTitle->addStretch();
    app->addItems(solverName[0]);

    QStringList list;
    list<<"basic"<<"combustion"<<"compressibel"<<"discreteMethods"
       <<"DNS"<<"heat transfer"<<"multiphase"<<"incompressible";
    sGroup = new QGroupBox;
    sButGroup = new QButtonGroup;
    for(int i=0; i<SOLVER; i++)
    {
        solver[i] = new QRadioButton(list[i]);
        sButGroup->addButton(solver[i], i);
    }
    solver[0]->setChecked(true);

    int k=0;

    sVLayout = new QVBoxLayout;
    sVLayout->addLayout(sTitle);

    for(int i=0; i<4; i++)
    {
        sLayout[i] = new QHBoxLayout;
        sLayout[i]->addWidget(solver[k]);
        sLayout[i]->addWidget(solver[k+1]);
        k = k+2;
        sVLayout->addLayout(sLayout[i]);
    }
    sGroup->setLayout(sVLayout);
    sGroup->setWindowFlags(Qt::FramelessWindowHint);
    connect(sButGroup, SIGNAL(buttonClicked(int)),this, SLOT(selectApp(int)));

    QStringList ckey;
    ckey<<"startFrom"<<"startTime"<<"stopAt"<<"endTime"<<"deltaT"<<"writeControl"
       <<"writeInterval"<<"purgeWrite";
    kLayout = new QVBoxLayout;
    QStringList keyBoxL[3];
    keyBoxL[0]<<"firstTime"<<"startTime"<<"latestTime";
    keyBoxL[1]<<"endTime"<<"writeNow"<<"noWriteNow"<<"nextWrite";
    keyBoxL[2]<<"timeStep"<<"runTime"<<"adjustableRunTime"<<"cpuTime"<<"clockTime";
    int WIDTH = 100;
    for(int i=0; i<5; i++)
    {
        keyLine[i] = new QLineEdit;
        keyLine[i]->setMinimumWidth(WIDTH);
        keyLine[i]->setMaximumWidth(WIDTH);
    }
    for(int i=0; i<3; i++)
    {
        keyBox[i] = new QComboBox;
        keyBox[i]->addItems(keyBoxL[i]);
        keyBox[i]->setMinimumWidth(WIDTH);
        keyBox[i]->setMaximumWidth(WIDTH);
    }
    int ke=0, kl=0;
    runModif = new QCheckBox("runTimeModifiable");
    Co = new QCheckBox("maxCo");
    for(int i=0; i<CTRKEY; i++)
    {
        keyName[i] = new QLabel(ckey[i]);
        keyName[i]->setMinimumWidth(100);
        keyName[i]->setMaximumWidth(100);
        keyLayout[i] = new QHBoxLayout;
        keyLayout[i]->addWidget(keyName[i]);
        if(i==0 || i==2 || i==5)
        {
            keyLayout[i]->addWidget(keyBox[ke]);
            ke++;
        }
        else
        {
            keyLayout[i]->addWidget(keyLine[kl]);
            kl++;
        }
        if(i==0)
        {
            keyLayout[i]->addWidget(runModif);
        }
        else if(i==1)
            keyLayout[i]->addWidget(Co);
        keyLayout[i]->addStretch();
        kLayout->addLayout(keyLayout[i]);
    }
    keyLine[0]->setText("0");
    keyLine[1]->setText("1000");
    keyLine[2]->setText("1");
    keyLine[3]->setText("10");
    keyLine[4]->setText("0");
    runModif->setChecked(true);
    vLayout->addWidget(sGroup);
    vLayout->addLayout(kLayout);

    sPanel = new solverWidget(vLayout);
    connect(this, SIGNAL(solverChoose(int)), sPanel, SLOT(changeSolver(int)));
    connect(app, SIGNAL(activated(int)), this, SLOT(selectAppIndex()));
    w->setLayout(vLayout);

    ctrlT.appSelect = 0;

    emit solverChoose(solverDict[0][0]);
}

void controlPanel::selectApp(int index)
{
    app->clear();
    ctrlT.appSelect = index;
    app->addItems(solverName[index]);
    sPanel->solverDict = solverDict[index][0];
    emit solverChoose(solverDict[index][0]);
    emit appSelectTrigger(index);
}

void controlPanel::selectAppIndex()
{
    int idx = app->currentIndex();
    sPanel->solverDict = solverDict[ctrlT.appSelect][idx];
    emit solverChoose(solverDict[ctrlT.appSelect][idx]);
    emit sendAppName(app->currentText());
    pEvent->saveTool->eqs = solverEq[ctrlT.appSelect][idx];
}

void controlPanel::saveForNextStep()
{
    ctrlT.appIndex = app->currentIndex();
    pEvent->saveTool->eqs = solverEq[ctrlT.appSelect][ctrlT.appIndex];
    pEvent->saveTool->ctrlT.appIndex = ctrlT.appIndex;
    pEvent->saveTool->ctrlT.appSelect = ctrlT.appSelect;
    pEvent->saveTool->ctrlT.appName = app->currentText();
    pEvent->saveTool->ctrlT.startFromIndex = keyBox[0]->currentIndex();
}
