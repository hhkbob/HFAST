#ifndef THERMAL_H
#define THERMAL_H

#include "basic.h"

class thermal : public QWidget
{
    Q_OBJECT
    #define THERMALNUM 7
public:
    thermal();
    QStringList save();
    void read(QStringList lst);
    QComboBox *value[THERMALNUM];

private:
    QVBoxLayout *vLayout;
    QHBoxLayout *hLayout[THERMALNUM];
    QLabel *name[THERMALNUM];

    QLabel *recom;
    QComboBox *recomValue;
    QHBoxLayout *rLayout;
public slots:
    void setType(int index);
};

#endif // THERMAL_H
