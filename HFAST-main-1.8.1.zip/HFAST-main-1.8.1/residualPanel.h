#ifndef RESIDUALPANEL_H
#define RESIDUALPANEL_H

#include <QObject>
//#include "printTool.h"
#include "sampleSurface.h"
#include <QSpinBox>
#include <QTimer>

class lineMonitor;
class probe;
class ButtonLine;
class ReControl;
class lineReCtr;

#define MAXIMUMLINE 20
#define MAXIMUMCHECK 2

class residualPanel : public QObject
{
    Q_OBJECT
public:
    explicit residualPanel(printTool *p, QWidget *w);
    ~residualPanel();
    printTool *pEvent;
    void saveProject();
    void readProject();
    ButtonLine *lBt[MAXIMUMLINE];
    lineReCtr *reCtr;
    void saveForNextStep();
    //QTimer *timer;
    //void timeBegin();
private:
    QVBoxLayout *vLayout;
    QCheckBox *reButton[MAXIMUMCHECK];
    QLineEdit   *reLine;
    QGroupBox *lGroup;
    QVBoxLayout *lLayout;
    QHBoxLayout *hGLayout;
    QPushButton *add;
    int index;
    sampleSurface *sampleS;
    QPushButton *sButton;
    //QCheckBox *sample;
    //QLineEdit *sampleEdit;
    //QSpinBox *time;



signals:

public slots:
    int addWidget();
    void surfaceGraph();
    //void onTimeOut();

};

class lineMonitor :public QGroupBox
{
    Q_OBJECT
public:
    explicit lineMonitor( );
    ~lineMonitor();
    QLabel *ckey[3];
    QLineEdit *cLine[7];
    QLabel *type;
    QLabel *axis;
    QComboBox *keyBox[2];
    LINEGRAPH lg;
    QPushButton *save;

private:
    QVBoxLayout *vLayout;
    QHBoxLayout *hLayout[4];
    QHBoxLayout *sLayout;
    

signals:
    void close(bool);

protected:
    virtual void closeEvent(QCloseEvent *e);

public slots:
    void saveEvery();
    void readEvery();
    void cancelClicked();
};

class probe : public QGroupBox
{
    Q_OBJECT
public:
    explicit probe( );
    ~probe();

};

class ButtonLine : public QPushButton
{
    Q_OBJECT
public:
    explicit ButtonLine(QString label, int idx);
    int index;
    ~ButtonLine();
    lineMonitor *line;
    LINEGRAPH lg;

public slots:
    void showWidget();
    void changeLabel();
};

class ReControl : public QWidget
{
    Q_OBJECT
public:
    ReControl();
    ~ReControl();
    bool use;
    QLineEdit *name;
    QLineEdit *value;
private:
    QHBoxLayout *hLayout;
public slots:
    QStringList save();
};

class lineReCtr : public QGroupBox
{
    Q_OBJECT
public:
    lineReCtr(QString name);
    ~lineReCtr();
    ReControl *reT[MAXIMUMLINE];
    QPushButton *add;
    QList<unit> ctr;
    int count;
private:
    QVBoxLayout *vlayout;
    QHBoxLayout *hLayout;
    QLabel *name;
    QLabel *value;
public:
    void save();
private slots:
    void addTriggered();
};

#endif // RESIDUALPANEL_H
