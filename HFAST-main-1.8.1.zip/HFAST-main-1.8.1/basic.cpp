#include "basic.h"
#include "QTextStream"
#include "QFile"
#include "QDebug"
#include "functions.h"

basic::basic(QObject *parent) : QObject(parent)
{
    Version = getVersion("basic::basic(QObject *parent)");
    mtName.append("nu");  mtDimension.append("[0 2 -1 0 0 0 0]");
    mtName.append("rho"); mtDimension.append("[0 1 -3 0 0 0 0]");
    mtName.append("beta"); mtDimension.append("[0 0 0 -1 0 0 0]");
    if(Version.toInt()==10)
    {
        mtName.append("T0"); mtDimension.append("[0 0 0 1 0 0 0]");
    }
    else if(Version.toInt()==5)
    {
        mtName.append("TRef"); mtDimension.append("[0 0 0 1 0 0 0]");
    }
    mtName.append("Pr"); mtDimension.append("[0 0 0 0 0 0 0]");
    mtName.append("Prt"); mtDimension.append("[0 0 0 0 0 0 0]");

    isReady = true;
    caseChange = false;
    stopBt = new QPushButton("stop");
    runLayout = new QHBoxLayout;
    runLayout->addWidget(stopBt);
    runGroup = new QGroupBox;
    runGroup->setLayout(runLayout);
    runGroup->setMinimumSize(260, 40);
    runGroup->setAttribute(Qt::WA_QuitOnClose, false);
    connect(stopBt, SIGNAL(clicked(bool)), this, SLOT(closeRunGroup()));

    pr = new mProcess;
    connect(pr, SIGNAL(isReady(bool)),this,SLOT(processFinished()));

    proc = new QProcess;
    connect(proc, SIGNAL(finished(int,QProcess::ExitStatus)),this,SLOT(QprocessFinished()));

    connect(stopBt, SIGNAL(clicked(bool)), this, SLOT(processFinished()));
    connect(pr->process, SIGNAL(finished(int,QProcess::ExitStatus)), this, SLOT(closeRunGroup()));
}

basic::~basic()
{
    //delete pr;
}

void basic::saveProject
(
    QString loc
)
{
    //  保存当前路径以及版本信息
    loc = "void basic::saveProject(...)\n"+loc;
    QString path = QDir::currentPath();
    savePath(path, loc);

    QJsonObject rootObj;
    QJsonObject gravityObj;
    //  保存gravity信息
    gravityObj.insert("gravityX", gravity[0]);
    gravityObj.insert("gravityY", gravity[1]);
    gravityObj.insert("gravityZ", gravity[2]);

    //  for parallel
    saveParallel();

    //  for model
    saveModel();

    saveMaterial();

    saveSchemes();

    saveControl();

    saveResidual();

    saveLineMonitor();

    saveSurfaceMonitor();

    saveSolute();

    saveBoundary();

    saveDefineField();

    //  定义根节点{}
    rootObj.insert("pathAndVersion", pathAndVersion);
    rootObj.insert("gravity", gravityObj);
    rootObj.insert("parallel", paraObj);
    rootObj.insert("TurbulenceModel", modelObj);
    rootObj.insert("material", mtObj);
    rootObj.insert("schemeNumbers", schemeNum);
    rootObj.insert("schemes", schemeObj);
    rootObj.insert("controlDict", ctrlObj);
    rootObj.insert("Residuals", reObj);
    rootObj.insert("lineMonitor", lineArray);
    rootObj.insert("surfaceMonitor", surfaceArray);
    rootObj.insert("solution", soluteObj);
    rootObj.insert("boundary", bdrObj);
    rootObj.insert("defineField", defineFieldObj);

    //  实例化对象
    QJsonDocument doc;
    doc.setObject(rootObj);

    //  保存文件
    //  检查是否是一个已经存在json文件，否的话就创建，是的话就保存
    QString fileName = path + "/"+JSONFILE;
    QFile file(fileName);
    int mark=0;
A:  if(!file.open(QIODevice::WriteOnly | QIODevice::Truncate))
    {
        HError HFASTError;
        Mess mes;
        mes.Fun = "void basic::saveProject(QString path)";
        mes.Head = "basic.h";
        mes.title = "Critical Error";
        mes.Loc = loc;
        mes.Mess = "Cannot create file in the current directory";
        mark = HFASTError.HFASTCritical(mes);
        if(mark == 1)
            goto A; // retry
    }
    if(mark != 2)
    {
        QTextStream stream(&file);
        stream.setCodec("UTF-8");
        stream << doc.toJson();
        file.close();

        // remember old results
        bool exist = false;
        for(int i=0; i<memoryResult.bdrLst.size(); i++)
        {
            if(QString(memoryResult.modelLst[i].name).compare(modelS.name)==0)
            {
                exist = true;
                memoryResult.bdrLst[i] = bdr;
                memoryResult.modelLst[i] = modelS;
                memoryResult.relaxationLst[i] = rela;
                memoryResult.residualLst[i] = re;
                memoryResult.schemeLst[i] = scheme;
                memoryResult.soluLst[i] = solute;
                break;
            }
        }
        if(!exist)
        {
            memoryResult.bdrLst.append(bdr);
            memoryResult.modelLst.append(modelS);
            memoryResult.relaxationLst.append(rela);
            memoryResult.residualLst.append(re);
            memoryResult.schemeLst.append(scheme);
            memoryResult.soluLst.append(solute);
        }
    }
    else
    {
        //  没有保存文件
        HError HFASTError;
        Mess mes;
        mes.Fun = "void basic::saveProject(QString path)";
        mes.Head = "basic.h";
        mes.title = "Informed news";
        mes.Loc = loc;
        mes.Mess = "The current project does not save";
        HFASTError.HFASTInform(mes);
    }
}

void basic::savePath(QString path, QString loc)
{
    QJsonObject templateObj;
    //  保存当前路径
    templateObj.insert("workDir", path);
    templateObj.insert("foamVersion", Version);

    pathAndVersion = templateObj;

    //  保存到系统里面
    QString corePath = QCoreApplication::applicationDirPath()+"/work.ini";
    FILE *data;
J:  data = fopen(corePath.toLocal8Bit().data(), "w");
    if(data==NULL)
    {
        HError HFASTError;
        Mess mes;
        mes.Fun = "void basic::savePath(QString path)";
        mes.Head = "basic.h";
        mes.title = "Critical Error";
        mes.Loc = loc;
        mes.Mess = "Cannot create the file in the core application directory";
        int mark = HFASTError.HFASTCritical(mes);
        if(mark == 1)
            goto J;
    }
    else
    {
        fprintf(data, "%s", path.toLocal8Bit().data());
        fclose(data);
    }
}

void basic::saveParallel()
{
    QJsonObject parNum, simple, hiera;

    parNum.insert("number", QString::number(para.num));
    parNum.insert("mark", QString::number(para.mark));

    simple.insert("x", para.simple[0]);
    simple.insert("y", para.simple[1]);
    simple.insert("z", para.simple[2]);
    simple.insert("delta", para.simple[3]);

    hiera.insert("x", para.hiera[0]);
    hiera.insert("y", para.hiera[1]);
    hiera.insert("z", para.hiera[2]);
    hiera.insert("delta", para.hiera[3]);
    hiera.insert("order", para.hiera[4]);

    QJsonArray  paraObjTemp;
    paraObjTemp.append(parNum);
    paraObjTemp.append(simple);
    paraObjTemp.append(hiera);

    paraObj = paraObjTemp;
}

void basic::saveModel()
{
    QJsonObject modelObjTemp;
    modelObjTemp.insert("model", modelS.name);
    modelObjTemp.insert("cKey", QString::number(modelS.cKey));
    modelObjTemp.insert("index",QString::number(modelS.index));
    char buffer[50], value[50], vName[50];
    for(int i=0; i<modelS.cKey; i++)
    {
        sprintf(buffer, "c%d", i);
        sprintf(value, "v%d", i);
        sprintf(vName, "%lf", modelS.vName[i]);
        modelObjTemp.insert(buffer, modelS.cName[i]);
        modelObjTemp.insert(value, vName);
    }
    modelObj = modelObjTemp;
}

void basic::saveMaterial()
{
    QJsonObject mtObjTemp;
    mtObjTemp.insert("name", mt.name);
    mtObjTemp.insert("index", QString::number(mt.index));
    char buffer[50];
    for(int i=0; i<MATERIAL_NUM; i++)
    {
        sprintf(buffer, "%lf", mt.materials[i]);
        mtObjTemp.insert(mtName[i], buffer);
    }

    //  save heat
    mtObjTemp.insert("heat", QString::number(mThermal.heat));
    if(mThermal.heat)
    {
        for(int i=0; i<7; i++)
        {
            sprintf(buffer, "type%d", i);
            mtObjTemp.insert(buffer, mThermal.type[i]);
        }
        mtObjTemp.insert("specie", mThermal.value[0]);
        mtObjTemp.insert("thermodynamics", mThermal.value[1]);
        mtObjTemp.insert("transport", mThermal.value[2]);
        mtObjTemp.insert("equationOfState", mThermal.value[3]);
    }
    if(!mtAdditional.isEmpty())
    {
        mtObjTemp.insert("additional", "1");
        mtObjTemp.insert("additional_value", mtAdditional);
    }
    else
        mtObjTemp.insert("additional", "0");

    mtObj = mtObjTemp;
}

QJsonObject basic::saveObjForSchemes(QList<SCHEME> lst, int mark)
{
    QJsonObject dest;
    char buffer[50];
    for(int i=0; i<lst.size(); i++)
    {
        sprintf(buffer, "name%d_%d", i, mark);
        dest.insert(buffer, lst[i].name);
        sprintf(buffer, "firstIndex%d_%d", i, mark);
        dest.insert(buffer, QString::number(lst[i].firstIndex));
        sprintf(buffer, "schemeIndex%d_%d", i, mark);
        dest.insert(buffer, QString::number(lst[i].schemeIndex));
        sprintf(buffer, "other%d_%d", i, mark);
        dest.insert(buffer, lst[i].other);
    }
    return dest;
}

void basic::saveSchemes()
{
    QJsonObject ddt, grad, div, lap, inter, snG;
    ddt = saveObjForSchemes(scheme.ddt, 0);
    grad = saveObjForSchemes(scheme.grad, 1);
    div = saveObjForSchemes(scheme.div, 2);
    lap = saveObjForSchemes(scheme.lap, 3);
    inter = saveObjForSchemes(scheme.inter, 4);
    snG = saveObjForSchemes(scheme.snG, 5);

    QJsonArray schemeObjTemp;

    schemeObjTemp.append(ddt);
    schemeObjTemp.append(grad);
    schemeObjTemp.append(div);
    schemeObjTemp.append(lap);
    schemeObjTemp.append(inter);
    schemeObjTemp.append(snG);

    schemeObj = schemeObjTemp;

    QJsonObject schemeNumTemp;

    schemeNumTemp.insert("ddtNum", QString::number(scheme.ddt.size()));
    schemeNumTemp.insert("gradNum", QString::number(scheme.grad.size()));
    schemeNumTemp.insert("divNum", QString::number(scheme.div.size()));
    schemeNumTemp.insert("lapNum", QString::number(scheme.lap.size()));
    schemeNumTemp.insert("interNum", QString::number(scheme.inter.size()));
    schemeNumTemp.insert("snGNum", QString::number(scheme.snG.size()));

    schemeNum = schemeNumTemp;
}

void basic::saveControl()
{
    QJsonObject ctrlObjTemp;
    ctrlObjTemp.insert("appIndex", QString::number(ctrlT.appIndex));
    ctrlObjTemp.insert("appSelect", QString::number(ctrlT.appSelect));
    ctrlObjTemp.insert("startFromIndex", QString::number(ctrlT.startFromIndex));
    ctrlObjTemp.insert("stopAtIndex", QString::number(ctrlT.stopAtIndex));
    ctrlObjTemp.insert("wrteIndex", QString::number(ctrlT.writeControlIndex));
    char buffer[50];
    for(int i=0; i<5; i++)
    {
        sprintf(buffer, "line%d", i);
        ctrlObjTemp.insert(buffer, ctrlT.list[i]);
    }
    ctrlObjTemp.insert("runModi", QString::number(ctrlT.runModi));
    ctrlObjTemp.insert("maxCo", QString::number(ctrlT.Co));
    ctrlObjTemp.insert("solverDict", QString::number(sDict.solverDict));
    ctrlObjTemp.insert("solverLen", QString::number(sDict.len));
    for(int i=0; i<sDict.value.size(); i++)
    {
        sprintf(buffer, "solverDict%d", i);
        ctrlObjTemp.insert(buffer, sDict.value[i]);
    }
    ctrlObj = ctrlObjTemp;
}

void basic::saveResidual()
{
    QJsonObject reObjTemp;
    reObjTemp.insert("monitor", QString::number(re.monitor));
    reObjTemp.insert("line", QString::number(re.line));
    reObjTemp.insert("para", re.para);
    reObjTemp.insert("Re_num", QString::number(re.residual.size()));
    char buffer[50];
    for(int i=0; i<re.residual.size(); i++)
    {
        sprintf(buffer, "Re_name%d", i);
        reObjTemp.insert(buffer, re.residual[i].name);
        sprintf(buffer, "Re_value%d", i);
        reObjTemp.insert(buffer, re.residual[i].value);
    }
    reObjTemp.insert("sampleCommand", re.sampleCommand);
    reObjTemp.insert("sampleTime", re.sampleTime);
    reObj = reObjTemp;
}

void basic::saveLineMonitor()
{
    QJsonArray lineArrayTemp;
    QString p;
    for(int i=0; i<lg.size(); i++)
    {
        QJsonObject lObj;
        for(int j=0; j<7; j++)
        {
           p = "key"+QString::number(i)+"_"+QString::number(j);
           if(j<6)
               lObj.insert(p, lg[i].points[j]);
           else
               lObj.insert(p, lg[i].field);
        }
        p = "type"+QString::number(i);
        lObj.insert(p, QString::number(lg[i].typeIndex));

        p = "axis"+QString::number(i);
        lObj.insert(p, QString::number(lg[i].axisIndex));
        lineArrayTemp.append(lObj);
    }
    lineArray = lineArrayTemp;
}

void basic::saveSurfaceMonitor()
{
    QJsonArray surfaceArrayTemp;
    QString p;
    for(int i=0; i<sampleSur.size(); i++)
    {
        QJsonObject sObj;
        for(int j=0; j<3; j++)
        {
           p = "point"+QString::number(i)+"_"+QString::number(j);
           sObj.insert(p, sampleSur[i].points[j]);
        }
        p = "name"+QString::number(i);
        sObj.insert(p, sampleSur[i].name);

        p = "normal"+QString::number(i);
        sObj.insert(p, sampleSur[i].normal);

        surfaceArrayTemp.append(sObj);
    }
    surfaceArray = surfaceArrayTemp;
}

void basic::saveSolute()
{
    QJsonObject soluteObjTemp;
    char buffer[50];
    int count=0;
    for(int i=0; i<solute.size(); i++)
    {
        //qDebug()<<solute[i].use;
        if(solute[i].use)
        {
            sprintf(buffer, "solver%d", count);
            soluteObjTemp.insert(buffer, solute[i].value[0]);
            sprintf(buffer, "tolerance%d", count);
            soluteObjTemp.insert(buffer, solute[i].value[1]);
            sprintf(buffer, "relTol%d", count);
            soluteObjTemp.insert(buffer, solute[i].value[2]);
            sprintf(buffer, "smoother%d", count);
            soluteObjTemp.insert(buffer, solute[i].value[3]);
            sprintf(buffer, "maxIter%d", count);
            soluteObjTemp.insert(buffer, solute[i].value[4]);
            sprintf(buffer, "preconditioner%d", count);
            soluteObjTemp.insert(buffer, solute[i].value[5]);
            sprintf(buffer, "name%d", count);
            soluteObjTemp.insert(buffer, solute[i].name);
            count++;
        }
    }
    soluteObjTemp.insert("number", QString::number(count));
    soluteObjTemp.insert("relaxationNumber", rela.len);
    for(int i=0; i<rela.len.toInt(); i++)
    {
        sprintf(buffer, "relaxation%d", i);
        soluteObjTemp.insert(buffer, rela.value[i]);
    }
    soluteObjTemp.insert("additional", rela.additional);

    soluteObj = soluteObjTemp;
}

void basic::saveBoundary()
{
    QJsonObject bdrObjTemp;
    bdrObjTemp.insert("bdrNum", bdr.totalBdr);
    char buffer[100];
    for(int i=0; i<bdr.totalBdr.toInt(); i++)
    {
        sprintf(buffer, "name%d", i);
        bdrObjTemp.insert(buffer, bdr.value[i][0]);
        sprintf(buffer, "type%d", i);
        bdrObjTemp.insert(buffer, bdr.value[i][1]);
        sprintf(buffer, "nFaces%d", i);
        bdrObjTemp.insert(buffer, bdr.value[i][2]);
        sprintf(buffer, "startFace%d", i);
        bdrObjTemp.insert(buffer, bdr.value[i][3]);
    }

    QStringList paraName;
    for(int i=0; i<bdr.paraName[0].size(); i++)
        paraName.append(bdr.paraName[0][i]);
    for(int i=0; i<bdr.paraName[1].size(); i++)
        paraName.append(bdr.paraName[1][i]);

    bdrObjTemp.insert("number", QString::number(paraName.size()));
    int k=0;
    for(int i=0; i< paraName.size(); i=i+2)
    {
        sprintf(buffer, "dimension%d", k);
        bdrObjTemp.insert(buffer, paraName[i+1]);
        sprintf(buffer, "paraName%d", k);
        bdrObjTemp.insert(buffer, paraName[i]);
        sprintf(buffer, "internal%d", k);
        bdrObjTemp.insert(buffer, bdr.internal[k]);
        for(int j=0; j<bdr.totalBdr.toInt(); j++)
        {
            sprintf(buffer, "paraValue%d_%d", k, j);
            bdrObjTemp.insert(buffer, bdr.paraValue[k][j]);
            sprintf(buffer, "paraIndex%d_%d", k, j);
            bdrObjTemp.insert(buffer, bdr.paraIndex[k][j]);
        }
        k = k+1;
    }
    bdrObj = bdrObjTemp;
}

void basic::saveDefineField()
{
    QJsonObject define;
    define.insert("defineParaNum", QString::number(dParaLst.size()));
    char buffer[50];
    for(int i=0; i<dParaLst.size(); i++)
    {
        sprintf(buffer, "paraName%d", i);
        define.insert(buffer, dParaLst[i].name);
        sprintf(buffer, "paraField%d", i);
        define.insert(buffer, dParaLst[i].field);
    }
    defineFieldObj = define;
}

void basic::readProject(QString path, QString loc)
{
    //  读取json文件
    //init.newCase(path, QString("void basic::readProject(QString path) ")+
    //                   "found in foamInit::newCase(..)\n"+loc);

    QString fileName = path + "/"+JSONFILE;
    QFile file(fileName);
    int mark=0;
B:  if(!file.open(QIODevice::ReadOnly | QFile::Text))
    {
        HError HFASTError;
        Mess mes;
        mes.Fun = "void basic::readProject(QString path)";
        mes.Head = "basic.h";
        mes.title = "Critical Error";
        mes.Loc = loc;
        mes.Mess = "Cannot open project in the current directory";
        mark = HFASTError.HFASTCritical(mes);
        if(mark == 1)
            goto B; // retry
    }
    if(mark!=2)
    {
        QTextStream stream(&file);
        stream.setCodec("UTF-8");
        QString content = stream.readAll();
        file.close();

        //  解析成QJsonDocument
        QJsonParseError jsonError;
        QJsonDocument doc
                = QJsonDocument::fromJson(content.toUtf8(), &jsonError);
        if(jsonError.error != QJsonParseError::NoError && !doc.isNull())
        {
            HError HFASTError;
            Mess mes;
            mes.Fun = "void basic::readProject(QString path)";
            mes.Head = "basic.h";
            mes.title = "Critical Error";
            mes.Loc = loc;
            mes.Mess = "Json file is error";
            HFASTError.HFASTCritical(mes);
            return;
        }

        //  获取根
        QJsonObject rootObj = doc.object();

        Mess mes;
        mes.Fun = "void basic::readProject(QString path)";
        mes.Head = "basic.h";
        mes.title = "Critical Error";

        //  获取路径和版本号
        QJsonValue pathAndVersionV = rootObj.value("pathAndVersion");
        if(pathAndVersionV.type() == QJsonValue::Object)
        {
            pathAndVersion = pathAndVersionV.toObject();
            workPath = pathAndVersion.value("workDir").toString();
            QString ver = pathAndVersion.value("foamVersion").toString();
        }
        else
        {
            mes.Loc = loc;
            mes.Mess = "pathAndVersionV is not an object";
            readJsonValueErr(mes);
        }

        //  获取重力设置
        QJsonValue gV = rootObj.value("gravity");
        QJsonObject gravityObj;
        if(gV.type() == QJsonValue::Object)
        {
            gravityObj = gV.toObject();
            gravity[0] = gravityObj.value("gravityX").toString();
            gravity[1] = gravityObj.value("gravityY").toString();
            gravity[2] = gravityObj.value("gravityZ").toString();
        }
        else
        {
            mes.Loc = loc;
            mes.Mess = "gV is not an object";
            readJsonValueErr(mes);
        }

        // for paralel
        readParallel(rootObj, loc);
        readModel(rootObj, loc);
        readMaterial(rootObj, loc);
        readSchemes(rootObj, loc);
        readControl(rootObj, loc);
        readResidual(rootObj, loc);
        readLineMonitor(rootObj, loc);
        readSolute(rootObj, loc);
        readBoundaryDetail(rootObj, loc);
        readSurfaceMonitor(rootObj, loc);
        readDefineField(rootObj, loc);
        qDebug()<<"read project : " <<Version;
    }
}

void basic::runCommand(QString cmd)
{
    qDebug()<<"HFAST: "<<cmd<<endl;

    QString curWork = QDir::currentPath();
    QString source = bashrc;
    QString command;
    #ifdef _WIN32
        QStringList workList = curWork.split(":");
        QString work = "/mnt/"+workList[0].toLower()+workList[1];
        command = QString("ubuntu1804 -c \"source ") + source + QString(" && cd ") + work;
    #else
        command = QString("bash -c \"source ") + source + QString(" && cd ") + curWork;
    #endif
    command = command + QString(" && ") + cmd +QString("\"");

    isReady = false;

    pr->cmd = command;
    pr->startCommand();

    runGroup->show();

}

void basic::runCommandNoWindow(QString cmd)
{
    QString curWork = QDir::currentPath();
    QString source = bashrc;
    QString command;
    #ifdef _WIN32
        QStringList workList = curWork.split(":");
        QString work = "/mnt/"+workList[0].toLower()+workList[1];
        command = QString("ubuntu1804 -c \"source ") + source + QString(" && cd ") + work;
    #else
        command = QString("bash -c \"source ") + source + QString(" && cd ") + curWork;
    #endif
    command = command + QString(" && ") + cmd +QString("\"");

    isReady = false;

    if(!proc->state())
        proc->start(command);
}

void basic::runCommandNoWindowEn(QString cmd)
{
    QString curWork = QDir::currentPath();
    QString source = bashrc;
    QString command;
    #ifdef _WIN32
        QStringList workList = curWork.split(":");
        QString work = "/mnt/"+workList[0].toLower()+workList[1];
        command = QString("ubuntu1804 -c \"source ") + source + QString(" && cd ") + work;
    #else
        command = QString("bash -c \"source ") + source + QString(" && cd ") + curWork;
    #endif
    command = command + QString(" && ") + cmd +QString("\"");

    //isReady = false;

    QProcess *pr = new QProcess;
    pr->start(command);
    //if(!proc->state())
    //    proc->start(command);
}

QString basic::getVersion(QString loc)
{
    if(Version.isEmpty())
    {
        FILE *data = fopen("./core/version.ini", "r");
        QString ver;
        if(data!=NULL)
        {
            int v;
            fscanf(data, "%d", &v);
            fclose(data);
            ver = QString::number(v);
        }
        else if(data==NULL)
        {
            Mess mes;
            mes.Fun = "QString basic::getVersion()";
            mes.Head = "basic.h";
            mes.Loc = loc;
            mes.title = "critical error";
            mes.Mess = "cannot find file core/version.ini. The application will abort.";
            HError HFASTEror;
            HFASTEror.HFASTWarning(mes);
            abort();
        }
        Version = ver;
        bashrc = getBashrc();
    }

    return Version;
}

QString basic::getBashrc()
{
    FILE *data = fopen("./core/foamVersion.ini", "r");
    QString result;
    if(data!=NULL)
    {
        char buffer[500];
        while(!feof(data))
        {
            fscanf(data, "%s", buffer);
            if(Version.toInt()==QString(buffer).toInt())
            {
                fscanf(data, "%s", buffer);
                result = buffer;
                break;
            }
            else
                fscanf(data, "%s", buffer);
        }
        fclose(data);
    }
    return result;
}

void basic::readJsonValueErr(Mess mes)
{
    HError HFASTError;
    HFASTError.HFASTCritical(mes);
    return;
}

void basic::readParallel(QJsonObject root, QString loc)
{
    QJsonValue paraArrayV = root.value("parallel");
    if(paraArrayV.type() == QJsonValue::Array)
    {
        QJsonArray paraArray = paraArrayV.toArray();
        for(int i=0; i<paraArray.size(); i++)
        {
            QJsonValue paraChild = paraArray.at(i);
            if(paraChild.type()==QJsonValue::Object && i==0)
            {
                QJsonObject paraNum = paraChild.toObject();
                para.num = paraNum.value("number").toString().toInt();
                para.mark = paraNum.value("mark").toString().toInt();
            }
            else if(paraChild.type()==QJsonValue::Object && i==1)
            {
                QJsonObject simple = paraChild.toObject();
                para.simple[0] = simple.value("x").toString();
                para.simple[1] = simple.value("y").toString();
                para.simple[2] = simple.value("z").toString();
                para.simple[3] = simple.value("delta").toString();
            }
            else if(paraChild.type()==QJsonValue::Object && i==2)
            {
                QJsonObject hir = paraChild.toObject();
                para.hiera[0] = hir.value("x").toString();
                para.hiera[1] = hir.value("y").toString();
                para.hiera[2] = hir.value("z").toString();
                para.hiera[3] = hir.value("delta").toString();
                para.hiera[4] = hir.value("order").toString();
            }
        }
    }
    else
    {
        Mess mes;
        mes.Fun = "void basic::readParallel()";
        mes.Head = "basic.h";
        mes.title = "Critical Error";
        mes.Loc = loc;
        mes.Mess = "paraArrayV is not an array";
        readJsonValueErr(mes);
    }
}

QList<SCHEME> basic::readSchemePart(QJsonArray array, int number, int index)
{
    QList<SCHEME> pList;
    QJsonValue aChild = array.at(index);
    char buffer[50];
    if(aChild.type()==QJsonValue::Object)
    {
        QJsonObject h = aChild.toObject();
        SCHEME se;
        for(int i=0; i<number; i++)
        {
            sprintf(buffer, "name%d_%d", i, index);
            se.name = h.value(buffer).toString();
            sprintf(buffer, "firstIndex%d_%d", i, index);
            se.firstIndex = h.value(buffer).toString().toInt();
            sprintf(buffer, "schemeIndex%d_%d", i, index);
            se.schemeIndex = h.value(buffer).toString().toInt();
            sprintf(buffer, "other%d_%d", i, index);
            se.other = h.value(buffer).toString();
            pList.append(se);
        }
        return pList;
    }
    else
    {
        Mess mes;
        mes.Fun = "void basic::readSchemePart()";
        mes.Head = "basic.h";
        mes.title = "Critical Error";
        mes.Loc = "try to read schemes";
        mes.Mess = "aChild is not an object. The application will abort";
        readJsonValueErr(mes);
        abort();
    }
}

void basic::readSchemes(QJsonObject root, QString loc)
{
    QJsonValue schemeNums = root.value("schemeNumbers");
    if(schemeNums.type() == QJsonValue::Object)
    {
        QJsonObject m2 =  schemeNums.toObject();
        numbers[0] = m2.value("ddtNum").toString().toInt();
        numbers[1] = m2.value("gradNum").toString().toInt();
        numbers[2] = m2.value("divNum").toString().toInt();
        numbers[3] = m2.value("lapNum").toString().toInt();
        numbers[4] = m2.value("interNum").toString().toInt();
        numbers[5] = m2.value("snGNum").toString().toInt();
    }
    else
    {
        Mess mes;
        mes.Fun = "void basic::readSchemes()";
        mes.Head = "basic.h";
        mes.title = "Critical Error";
        mes.Loc = "try to read schemes numbers";
        mes.Mess = "schemeNums is not an object. The application will abort";
        readJsonValueErr(mes);
        abort();
    }

    QJsonValue schemeV = root.value("schemes");

    if(schemeV.type() == QJsonValue::Array)
    {
        QJsonArray schemeArray = schemeV.toArray();
        QList<SCHEME> pse[6];
        for(int i=0; i<6; i++)
        {
            pse[i] = readSchemePart(schemeArray, numbers[i], i);
        }
        scheme.ddt = pse[0];
        scheme.grad = pse[1];
        scheme.div = pse[2];
        scheme.lap = pse[3];
        scheme.inter = pse[4];
        scheme.snG = pse[5];
    }
    else
    {
        Mess mes;
        mes.Fun = "void basic::readSchemes()";
        mes.Head = "basic.h";
        mes.title = "Critical Error";
        mes.Loc = loc;
        mes.Mess = "schemeV is not an array";
        readJsonValueErr(mes);
    }
}

void basic::readModel(QJsonObject root, QString loc)
{
    QJsonValue model = root.value("TurbulenceModel");
    if(model.type() == QJsonValue::Object)
    {
        QJsonObject m1 = model.toObject();
        strcpy(modelS.name, m1.value("model").toString().toLocal8Bit().data());
        modelS.cKey = m1.value("cKey").toString().toInt();
        modelS.index = m1.value("index").toString().toInt();
        char buffer[50], value[50];
        for(int i=0; i<modelS.cKey; i++)
        {
            sprintf(buffer, "c%d", i);
            sprintf(value, "v%d", i);
            strcpy(modelS.cName[i], m1.value(buffer).toString().toLocal8Bit().data());
            modelS.vName[i]= m1.value(value).toString().toDouble();
        }
    }
    else
    {
        Mess mes;
        mes.Fun = "void basic::readModel(QJsonObject root, QString loc)";
        mes.Head = "basic.h";
        mes.title = "Critical Error";
        mes.Loc = loc;
        mes.Mess = "model is not an object";
        readJsonValueErr(mes);
    }
}

void basic::readMaterial(QJsonObject root, QString loc)
{
    QJsonValue mtValue = root.value("material");
    if(mtValue.type() == QJsonValue::Object)
    {
        QJsonObject mtV = mtValue.toObject();
        strcpy(mt.name, mtV.value("name").toString().toLocal8Bit().data());
        mt.index = mtV.value("index").toString().toInt();
        for(int i=0; i<MATERIAL_NUM; i++)
        {
            mt.materials[i] = mtV.value(mtName[i]).toString().toDouble();
        }

        //  read heat
        mThermal.heat = mtV.value("heat").toString().toInt();
        if(mThermal.heat)
        {
            QStringList type;
            char buffer[50];
            for(int i=0; i<7; i++)
            {
                sprintf(buffer, "type%d", i);
                type.append(mtV.value(buffer).toString());
            }
            QStringList lst;
            lst.append(mtV.value("specie").toString());
            lst.append(mtV.value("thermodynamics").toString());
            lst.append(mtV.value("transport").toString());
            lst.append(mtV.value("equationOfState").toString());
            mThermal.value = lst;
            mThermal.type = type;
        }
        int notEmpty = mtV.value("additional").toString().toInt();
        if(notEmpty)
        {
            mtAdditional = mtV.value("additional_value").toString();
        }
    }
    else
    {
        Mess mes;
        mes.Fun = "void basic::readMaterial(QJsonObject root, QString loc)";
        mes.Head = "basic.h";
        mes.title = "Critical Error";
        mes.Loc = loc;
        mes.Mess = "mtValue is not an object";
        readJsonValueErr(mes);
    }
}

void basic::readControl(QJsonObject root, QString loc)
{
    QJsonValue con = root.value("controlDict");
    if(con.type() == QJsonValue::Object)
    {
        QJsonObject cObj = con.toObject();
        ctrlT.appIndex = cObj.value("appIndex").toString().toInt();
        ctrlT.appSelect = cObj.value("appSelect").toString().toInt();
        ctrlT.startFromIndex = cObj.value("startFromIndex").toString().toInt();
        ctrlT.stopAtIndex = cObj.value("stopAtIndex").toString().toInt();
        ctrlT.writeControlIndex = cObj.value("wrteIndex").toString().toInt();
        char buffer[50];
        for(int i=0; i<5; i++)
        {
            sprintf(buffer, "line%d", i);
            ctrlT.list[i] = cObj.value(buffer).toString();
        }
        ctrlT.runModi = cObj.value("runModi").toString().toInt();
        ctrlT.Co = cObj.value("maxCo").toString().toInt();
        SOLVERSETTING dict;
        dict.solverDict = cObj.value("solverDict").toString().toInt();
        dict.len = cObj.value("solverLen").toString().toInt();
        for(int i=0; i<dict.len; i++)
        {
            sprintf(buffer, "solverDict%d", i);
            dict.value.append(cObj.value(buffer).toString());
        }
        sDict = dict;
    }
    else
    {
        Mess mes;
        mes.Fun = "void basic::readControl(QJsonObject root, QString loc)";
        mes.Head = "basic.h";
        mes.title = "Critical Error";
        mes.Loc = loc;
        mes.Mess = "con is not an object";
        readJsonValueErr(mes);
    }
}

void basic::readResidual(QJsonObject root, QString loc)
{
    QJsonValue R = root.value("Residuals");
    if(R.type() == QJsonValue::Object)
    {
        QJsonObject rObj = R.toObject();
        re.monitor = rObj.value("monitor").toString().toInt();
        re.line = rObj.value("line").toString().toInt();
        re.para = (rObj.value("para").toString());
        re.ReNum = rObj.value("Re_num").toString().toInt();
        char buffer[50];
        for(int i=0; i<re.ReNum; i++)
        {
            unit reUnit;
            sprintf(buffer, "Re_name%d", i);
            reUnit.name = rObj.value(buffer).toString();
            sprintf(buffer, "Re_value%d", i);
            reUnit.value = rObj.value(buffer).toString();
            re.residual.append(reUnit);
        }
        re.sampleCommand = rObj.value("sampleCommand").toString();
        re.sampleTime = rObj.value("sampleTime").toString();
    }
    else
    {
        Mess mes;
        mes.Fun = "void basic::readResidual(QJsonObject root, QString loc)";
        mes.Head = "basic.h";
        mes.title = "Critical Error";
        mes.Loc = loc;
        mes.Mess = "R is not an object";
        readJsonValueErr(mes);
    }
}

void basic::readLineMonitor(QJsonObject root, QString loc)
{
    //lineMonitor;
    QJsonValue lArray = root.value("lineMonitor");

    if(lArray.type() == QJsonValue::Array)
    {
        QJsonArray lA = lArray.toArray();
        QList<LINEGRAPH> line;
        for(int i=0; i<lA.size(); i++)
        {
            QJsonValue aChild = lA.at(i);
            LINEGRAPH lgx;
            QString p;
            if(aChild.type() == QJsonValue::Object)
            {
                QJsonObject lObj = aChild.toObject();
                for(int j=0; j<7; j++)
                {
                    p = "key"+QString::number(i)+"_"+QString::number(j);
                    if(j<6)
                       lgx.points[j] = lObj.value(p).toString();
                    else
                       lgx.field = lObj.value(p).toString();
                }
                p = "type"+QString::number(i);
                lgx.typeIndex = lObj.value(p).toString().toInt();
                p = "axis"+QString::number(i);
                lgx.axisIndex = lObj.value(p).toString().toInt();
                line.append(lgx);
            }
        }
        lg = line;
    }
    else
    {
        Mess mes;
        mes.Fun = "void basic::readLineMonitor(QJsonObject root, QString loc)";
        mes.Head = "basic.h";
        mes.title = "Critical Error";
        mes.Loc = loc;
        mes.Mess = "lArray is not an array";
        readJsonValueErr(mes);
    }
}

void basic::readSurfaceMonitor(QJsonObject root, QString loc)
{
    //========
    QJsonValue sArray = root.value("surfaceMonitor");

    if(sArray.type() == QJsonValue::Array)
    {
        QJsonArray lA = sArray.toArray();
        QList<SURFACEGRAPH> surface;
        for(int i=0; i<lA.size(); i++)
        {
            QJsonValue aChild = lA.at(i);
            SURFACEGRAPH sr;
            QString p;
            if(aChild.type() == QJsonValue::Object)
            {
                QJsonObject lObj = aChild.toObject();
                for(int j=0; j<3; j++)
                {
                    p = "point"+QString::number(i)+"_"+QString::number(j);
                    sr.points[j] = lObj.value(p).toString();
                }
                p = "name"+QString::number(i);
                sr.name = lObj.value(p).toString();
                p = "normal"+QString::number(i);
                sr.normal = lObj.value(p).toString();
                surface.append(sr);
            }
        }
        sampleSur = surface;
    }
    else
    {
        Mess mes;
        mes.Fun = "void basic::readSurfaceMonitor(QJsonObject root, QString loc)";
        mes.Head = "basic.h";
        mes.title = "Critical Error";
        mes.Loc = loc;
        mes.Mess = "sArray is not an array";
        readJsonValueErr(mes);
    }
}

void basic::readSolute(QJsonObject root, QString loc)
{
    QJsonValue su = root.value("solution");
    if(su.type() == QJsonValue::Object)
    {
        QJsonObject sObj = su.toObject();
        int count = sObj.value("number").toString().toInt();
        char buffer[50];
        SOLUTION slu;
        QList<SOLUTION> sluT;
        for(int i=0; i<count; i++)
        {
            sprintf(buffer, "solver%d", i);
            slu.value[0] = sObj.value(buffer).toString();
            sprintf(buffer, "tolerance%d", i);
            slu.value[1] = sObj.value(buffer).toString();
            sprintf(buffer, "relTol%d", i);
            slu.value[2] = sObj.value(buffer).toString();
            sprintf(buffer, "smoother%d", i);
            slu.value[3] = sObj.value(buffer).toString();
            sprintf(buffer, "maxIter%d", i);
            slu.value[4] = sObj.value(buffer).toString();
            sprintf(buffer, "preconditioner%d", i);
            slu.value[5] = sObj.value(buffer).toString();
            sprintf(buffer, "name%d", i);
            slu.name = sObj.value(buffer).toString();
            slu.use = true;
            sluT.append(slu);
        }
        solute = sluT;
        rela.len = sObj.value("relaxationNumber").toString();
        QStringList lst;
        for(int i=0; i<rela.len.toInt(); i++)
        {
            sprintf(buffer, "relaxation%d", i);
            lst.append(sObj.value(buffer).toString());
        }
        rela.value = lst;
        rela.additional = sObj.value("additional").toString();
    }
    else
    {
        Mess mes;
        mes.Fun = "void basic::readSolute(QJsonObject root, QString loc)";
        mes.Head = "basic.h";
        mes.title = "Critical Error";
        mes.Loc = loc;
        mes.Mess = "su  is not an array";
        readJsonValueErr(mes);
    }
}

void basic::readBoundaryDetail(QJsonObject root, QString loc)
{
    QJsonValue bdaryV = root.value("boundary");
    if(bdaryV.type() == QJsonValue::Object)
    {
        QJsonObject bObj = bdaryV.toObject();
        bdr.totalBdr = bObj.value("bdrNum").toString();
        int count = bdr.totalBdr.toInt();
        char buffer[100];
        QList<QStringList> bValue;
        for(int i=0; i<count; i++)
        {
            QStringList basicV;
            sprintf(buffer, "name%d", i);
            basicV.append(bObj.value(buffer).toString());
            sprintf(buffer, "type%d", i);
            basicV.append(bObj.value(buffer).toString());
            sprintf(buffer, "nFaces%d", i);
            basicV.append(bObj.value(buffer).toString());
            sprintf(buffer, "startFace%d", i);
            basicV.append(bObj.value(buffer).toString());
            bValue.append(basicV);
        }
        bdr.value = bValue;

        int paraSize = bObj.value("number").toString().toInt();
        int k=0;
        QStringList paraName, inter;
        QList<QStringList> index, paraValue;
        for(int i=0; i< paraSize; i=i+2)
        {
            sprintf(buffer, "paraName%d", k);
            paraName.append(bObj.value(buffer).toString());
            sprintf(buffer, "dimension%d", k);
            paraName.append(bObj.value(buffer).toString());
            sprintf(buffer, "internal%d", k);
            inter.append(bObj.value(buffer).toString());
            QStringList value, idx;
            for(int j=0; j<bdr.totalBdr.toInt(); j++)
            {
                sprintf(buffer, "paraValue%d_%d", k, j);
                value.append(bObj.value(buffer).toString());
                sprintf(buffer, "paraIndex%d_%d", k, j);
                idx.append(bObj.value(buffer).toString());
            }
            k = k+1;
            paraValue.append(value);
            index.append(idx);
        }
        bdr.paraIndex = index;
        bdr.internal = inter;
        bdr.paraValue = paraValue;

        QList<QStringList> paraTemp;
        paraTemp.append(paraName);

        bdr.paraName = paraTemp;
    }
    else
    {
        Mess mes;
        mes.Fun = "void basic::readBoundaryDetail(QJsonObject root, QString loc)";
        mes.Head = "basic.h";
        mes.title = "Critical Error";
        mes.Loc = loc;
        mes.Mess = "bdaryV is not an object";
        readJsonValueErr(mes);
    }

}

void basic::readDefineField(QJsonObject root, QString loc)
{
    QList<DEFINEPARA> paraList;
    QJsonValue defineV = root.value("defineField");
    if(defineV.type() == QJsonValue::Object)
    {
        QJsonObject dObj = defineV.toObject();
        int num = dObj.value("defineParaNum").toString().toInt();
        char buffer[50];
        for(int i=0; i<num; i++)
        {
            DEFINEPARA para;
            sprintf(buffer, "paraName%d", i);
            para.name = dObj.value(buffer).toString();
            sprintf(buffer, "paraField%d", i);
            para.field = dObj.value(buffer).toString();
            paraList.append(para);
        }
        dParaLst = paraList;
    }
    else
    {
        Mess mes;
        mes.Fun = "void basic::readDefineField(QJsonObject root, QString loc)";
        mes.Head = "basic.h";
        mes.title = "Critical Error";
        mes.Loc = loc;
        mes.Mess = "defineV is not an object";
        readJsonValueErr(mes);
    }
}

void basic::processFinished()
{
    pr->process->terminate();
    pr->process->close();
    isReady = true;
    emit finished();
}

void basic::QprocessFinished()
{
    proc->terminate();
}

void basic::closeRunGroup()
{
    runGroup->close();
}

mProcess::mProcess(QObject *parent)
{
    process = new QProcess;
    process->setProcessChannelMode(QProcess::MergedChannels);
    connect(process, SIGNAL(readyRead()), this, SLOT(outputMsg()));
    connect(process, SIGNAL(finished(int,QProcess::ExitStatus)), this, SLOT(finished()));
}

mProcess::~mProcess()
{
    process->terminate();
}

void mProcess::outputMsg()
{
    QByteArray qbt = process->readAllStandardOutput();
    QString msg = QString::fromLocal8Bit(qbt);
    qDebug().noquote()<<msg;
}

void mProcess::finished()
{
    qDebug().noquote()<<BROWSER;
    emit isReady(true);
}

void mProcess::startCommand()
{
    process->start(cmd);
}

paraProcess::paraProcess(int ID, QList<QStringList> para, QString taskPath, QString brc, QString ref, QString lineName, int varIdx)
{
    paraControl = para;
    process = new QProcess;
    //connect(process, SIGNAL(finished(int,QProcess::ExitStatus)), this, SLOT(isFinished()));
    //connect(this, SIGNAL(isReady(bool)), this, SLOT(startAgain()));
    keyFinished = 0;
    workPath = taskPath;
    bashrc = brc;
    refData = ref;
    sampleLine = lineName;
    varIndex = varIdx;
    procID = ID;
    refDatas = getRefData();
    timer = new QTimer;
    timer->setInterval(5000);
    connect(timer, SIGNAL(timeout()), this, SLOT(onTimeOut()));
    connect(this, SIGNAL(isReady(bool)), this, SLOT(startAgain()));
}

paraProcess::~paraProcess()
{
    delete process;
}

int paraProcess::getKeyPara(int runInt)
{
    //print control file to task
    QString file = workPath +"/keyPara.H";
    FILE *data = fopen(file.toLocal8Bit().data(), "w");
    QStringList para = paraControl[runInt];
    if(data!=NULL)
    {
        for(int i=0; i<para.size(); i++)
           fprintf(data, "var%d  %g;\n", i, para[i].toDouble());
        fclose(data);
        return 1;
    }
    else
    {
        qDebug()<<"cannot create the keyPara.H in the task for process "<<procID;
        return 0;
    }
}

QList<QVector<double>>  paraProcess::getRefData()
{
    QString file = workPath + "/refData.txt";
    FILE *data = fopen(file.toLocal8Bit().data(), "r");
    QList<QVector<double>> refTmp;
    if(data!=NULL)
    {
        while(!feof(data))
        {
            double var;
            int su=1;
            QVector<double> xy(2);
            su = fscanf(data, "%lf", &var);
            if(su<0)
            {
                QString inf = "refdata.txt format is not correct in process "
                        +QString::number(procID);
                //generalFunc ge;
                //ge.FatalErrors(inf);
                return refTmp;
            }
            xy[0] = var;
            su = fscanf(data, "%lf", &var);
            if(su<0)
            {
                QString inf = "refdata.txt format is not correct in process "
                        +QString::number(procID);
                //generalFunc ge;
                //ge.FatalErrors(inf);
                return refTmp;
            }
            xy[1] = var;
            refTmp.append(xy);
        }
        return refTmp;
    }
    else
    {
        QString inf = "cannot find refdata.txt in the task folder in process "
                +QString::number(procID);;
        generalFunc ge;
        ge.FatalErrors(inf);
    }
    return refTmp;
}

QList<QStringList> paraProcess::getSampleData(QStringList timeList)
{
    QString latestTime = timeList[timeList.size()-1];
    if(latestTime.toInt()==0)
    {
        qDebug()<<"only 0 time exists in the task"<<procID;
        QList<QStringList> dataSample;
        return dataSample;
    }
    QString file = workPath +"/postProcessing/"+sampleLine+"/"+latestTime;
    file = file + "/"+ sampleLine+".xy";
    generalFunc ge;
    QList<QStringList> dataSample = ge.readXYData(file);
    return dataSample;
}

void paraProcess::onTimeOut()
{
    FILE *data;
    QString path = workPath + "/finished.txt";
    {
        data=fopen(path.toLocal8Bit().data(), "r");
        if(data!=NULL)
        {
            fclose(data);
            QString cmd = "rm -rf " + path;
            system(cmd.toLocal8Bit().data());
            timer->stop();
            process->terminate();
            isFinished();
            emit isReady(true);
        }
    }
}

void paraProcess::isFinished()
{
    qDebug()<<"\n"<<"start to compared with the ref data in task"<<procID;
    // compared data
    QString path = workPath;
    generalFunc ge;
AZ: QStringList timeLst= ge.getTimeName(workPath, "/processor0");
    if(timeLst.isEmpty())
        timeLst = ge.getTimeName(workPath, "");
    if(timeLst.isEmpty())
    {
        qDebug()<<"cannot get time folder name";
    }
    QList<QStringList> sample = getSampleData(timeLst);
    if(sample.isEmpty())
    {

        qDebug()<<"reading sample data wrongly in task"<<procID<<" so process exits";
        QString fileError = workPath+"/fileError.txt";
        FILE *data = fopen(fileError.toLocal8Bit().data(), "w+");
        if(data!=NULL)
        {
            for(int i=0; i<paraControl[keyFinished].size(); i++)
                fprintf(data, "%g ", paraControl[keyFinished][i].toDouble());
            fprintf(data, "\n");
            fclose(data);
        }
        return;
    }
    double sum = 0;
    if(varIndex==0) //Nu y is the vertical
    {
        for(int k=0; k<refDatas.size(); k++)
        {
            double x = refDatas[k][0];
            double y = refDatas[k][1];
            for(int i=0; i<sample[0].size()-1; i++)
            {
                if(sample[0][0].toDouble()>sample[0][1].toDouble())
                {
                    if(sample[0][i].toDouble()>x && sample[0][i+1].toDouble()<x)
                    {
                        //--Nu
                        double Nu1 = -1*sample[2][i].toDouble()*0.04/10.0;
                        double Nu2 = -1*sample[2][i+1].toDouble()*0.04/10.0;
                        double sampleX1 = sample[0][i].toDouble();
                        double sampleX2 = sample[0][i+1].toDouble();
                        double sampleY = (Nu1-Nu2)/(sampleX1-sampleX2)*(sampleX2-x)+Nu2;
                        sum += sqrt((sampleY-y)*(sampleY-y));
                        break;
                    }
                }
                else
                {
                    if(sample[0][i].toDouble()<x && sample[0][i+1].toDouble()>x)
                    {
                        //--Nu
                        double Nu1 = -1*sample[2][i].toDouble()*0.04/10.0;
                        double Nu2 = -1*sample[2][i+1].toDouble()*0.04/10.0;
                        double sampleX1 = sample[0][i].toDouble();
                        double sampleX2 = sample[0][i+1].toDouble();
                        double sampleY = (Nu1-Nu2)/(sampleX1-sampleX2)*(sampleX2-x)+Nu2;
                        sum += sqrt((sampleY-y)*(sampleY-y));
                        break;
                    }
                }

            }
        }
    }
    if(keyFinished==0)
    {
        bestPara = paraControl[keyFinished];
        minSum = sum;
        qDebug()<<"get best para: "<<bestPara<<" "<<"sum: "<<minSum/(refData.size()*1.0)
               << " in task"<<procID;
    }
    else
    {
        if(minSum>sum)
        {
            minSum = sum;
            bestPara = paraControl[keyFinished];
            qDebug()<<"get best para: "<<bestPara<<" "<<"sum: "<<minSum/(refData.size()*1.0)
                   << " in task"<<procID;
        }
    }
    QString path1 = workPath +"/OptimizeResult.txt";
    FILE *data = fopen(path1.toLocal8Bit().data(), "w");
    if(data!=NULL)
    {
        fprintf(data, "avarage error:  %g\n", minSum/(refData.size()*1.0));
        fprintf(data, "best var:\n");
        for(int i=0; i<bestPara.size(); i++)
            fprintf(data, "var%d  %g\n", i, bestPara[i].toDouble());
        fclose(data);
    }
    else
    {
        qDebug()<< "in task"<<procID<<" cannot store the optimize data";
        emit isReady(true);
        return;
    }
    keyFinished++;
    if(keyFinished>paraControl.size()-1)
    {
        qDebug()<<keyFinished+" calculation finished in task"<<procID;
        return;
    }
}

void paraProcess::isStarted()
{
    if(keyFinished>paraControl.size()-1)
    {
        qDebug()<<keyFinished+" calculation finished in task"<<procID;
        return;
    }
    int su = getKeyPara(keyFinished);
    qDebug()<<"progress "<<keyFinished<<"/"<<paraControl.size()<<"for task"<<procID<<" starts";
    if(su==0)
    {
        qDebug()<<"\ncannot print the keyPara.H in the path for task"<<procID;
        return;
    }
    QString cmd1 = "./runTask.sh && touch finished.txt";
    QString source = bashrc;
    QString command;
    #ifdef _WIN32
        QStringList workList = workPath.split(":");
        QString work = "/mnt/"+workList[0].toLower()+workList[1];
        command = QString("ubuntu1804 -c \"source ") + source + QString(" && cd ") + work;
    #else
        command = QString("bash -c \"source ") + source + QString(" && cd ") + workPath;
    #endif
    //
    command = command + QString(" && ") + cmd1 +QString("\"");
    cmd = command;

    timer->start();

    process->start(cmd);
    //bs->runCommand(cmd1);
}

void paraProcess::startAgain()
{
    isStarted();
}

runThread::runThread(QString cmds)
{
    cmd = cmds;
}

void runThread::run()
{
    system(cmd.toLocal8Bit().data());
}
