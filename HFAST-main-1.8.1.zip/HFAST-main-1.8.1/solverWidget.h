#ifndef SOLVERWIDGET_H
#define SOLVERWIDGET_H

#include <QWidget>
#include "printTool.h"

class simple;
class pimple;
class piso;

class solverWidget : public QWidget
{
    Q_OBJECT
public:
    explicit solverWidget(QVBoxLayout *vlayout);
    QLabel *solverText;
    QPushButton *triggerBt;
    int solverDict;
    simple *sSolver;
    pimple *pSolver;
    piso *piSolver;
    void readProject(SOLVERSETTING dict);
    bool set;
    SOLVERSETTING sDict;

public slots:
    void solverSettings();
    void changeSolver(int dict);

signals:

public slots:
};

class simple : public QGroupBox
{
    Q_OBJECT
public:
    simple();
    QLabel *name[simpleNum ];
    QLineEdit *value[simpleNum ];
    QHBoxLayout *hLayout[simpleNum];
    QVBoxLayout *vLayout;
    SOLVERSETTING dict;
    SOLVERSETTING saveEvery();
    void readEvery(SOLVERSETTING dict);
signals:
    void close(bool);
protected:
    virtual void closeEvent(QCloseEvent *e);

};

class pimple : public QGroupBox
{
    Q_OBJECT
public:
    pimple();
    QLabel *name[pimpleNum ];
    QLineEdit *value[pimpleNum ];
    QHBoxLayout *hLayout[pimpleNum];
    QVBoxLayout *vLayout;
    SOLVERSETTING dict;
    SOLVERSETTING saveEvery();
    void readEvery(SOLVERSETTING dict);

signals:
    void close(bool);

protected:
    virtual void closeEvent(QCloseEvent *e);
};

class piso : public pimple
{
    Q_OBJECT
public:
    piso();
};

#endif // SOLVERWIDGET_H
