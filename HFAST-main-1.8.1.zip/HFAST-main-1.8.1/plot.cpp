#include "plot.h"

plot::plot(residualPanel *rP, QTabWidget *tabEdit)
{
    rPanel = rP;
    tab = tabEdit;
    for(int i=0; i<MAXPLOT; i++)
        plt[i] = new plotWidget(i);
    tab->addTab(plt[0], "residual");

    curTimeStep = "0";
    first = false;
}

void plot::readResidual(PLOTDATA data)
{

    curTimeStep = data.curTime;
    int idx = 0;

    //  plot
    //plt[idx]->clearGraphs();
    plotInTab(idx, "residual");
    if(!first)
    {
        plt[idx]->legend->setVisible(true);
        first = true;
        plt[idx]->addLayer(data.name.size()-1);
    }
    for(int i=0; i<data.name.size()-1; i++)
    {
        pltPROPERTY pl;
        pl.name = data.name[i+1];
        pl.xLabel = data.name[0];
        pl.yLabel = "residual";
        pl.x = data.data[0];
        pl.y = data.data[i+1];
        plt[idx]->plotXY(pl, i);
    }
}

void plot::plotInTab(int index, QString name)
{
    int tabIndex = tab->count();
    if(tabIndex<index+1)
    {
        tab->addTab(plt[index], name);
    }
}

myThread::myThread()
{
    curTimeStep = "0";
    isReady = true;
    connect(this, SIGNAL(finished()), this, SLOT(workFinished()));
}

void myThread::run()
{
    isReady = false;
    QString path = QDir::currentPath();
    if(timeFolder.isEmpty())
        return;
    QString file = path +"/postProcessing/residuals/"+timeFolder+"/residuals.dat";
    QFile re(file);
    if(!re.open(QIODevice::ReadOnly | QIODevice::Text))
    {
        //qCritical() <<"Error cannot open file: "<< file;
        return ;
    }
    QTextStream in(&re);
    in.setCodec("UTF-8");
    PLOTDATA datPlot;

    while(!in.atEnd())
    {
        QString line = in.readLine().toUtf8();
        QStringList lineLst = line.split(QRegExp(" "));
        if(lineLst[0]=="#" && lineLst[1]=="Time")
        {
            QString nameT;
            for(int i=1; i<lineLst.size(); i++)
                nameT = nameT+ lineLst[i];
            datPlot.name = nameT.split(QRegExp("\t"));
            break;
        }
    }

    if(datPlot.name.size()>0)
    {
        QStringList *data1;
        data1 = new QStringList[datPlot.name.size()];

        while(!in.atEnd())
        {
            QString line = in.readLine().toUtf8();
            QStringList lineLst = line.split("\t");
            if(lineLst.size()!=datPlot.name.size())
            {
                continue;
            }
            else
            {
                for(int i=0; i<datPlot.name.size(); i++)
                {
                    bool OK;
                    double tr = lineLst[i].toDouble(&OK);
                    if(OK)
                    {
                       data1[i].append(lineLst[i]);
                    }
                    else
                    {
                        break;
                    }
                }
            }
        }
        re.close();
        for(int i=0; i<datPlot.name.size(); i++)
            datPlot.data.append(data1[i]);

        if(data1[0].size()>0)
        {
            curTimeStep = data1[0][data1[0].size()-1];
            datPlot.curTime = curTimeStep;
            emit transData(datPlot);
        }
#ifdef _WIN32
        for(int i=0; i<datPlot.name.size(); i++)
            data1[i].clear();
        delete data1;
#endif
    }
    else
        re.close();;
}

void myThread::workFinished()
{
    this->terminate();
    this->wait();
    isReady = true;
}


PLOTDATA::PLOTDATA()
{
}
