#include "fileToolh.h"

fileToolh::fileToolh(printTool *p, QMenu *menu)
{
    pEvent = p;
    dPanel = new defineFields(p);

    Allclean = new QAction(tr("Allclean"));
    define = new QAction(tr("define"));
    plotResiudal = new QAction(tr("plot residual"));
    repeat = new QAction(tr("repeat bash"));

    QStringList app;
    app = read("./core/tool.dat");

    connect(Allclean, SIGNAL(triggered()), this, SLOT(cleanTrigger()));
    connect(define, SIGNAL(triggered(bool)), this, SLOT(defineTrigger()));
    connect(repeat, SIGNAL(triggered(bool)), this, SLOT(repeatTrigger()));

    menu->addAction(Allclean);
    menu->addAction(define);
    menu->addAction(plotResiudal);
    menu->addAction(repeat);
    action = new HFASTAction*[app.size()];
    for(int i=0; i<app.size(); i++)
    {
        action[i] = new HFASTAction(i, app[i]);
        menu->addAction(action[i]);
        connect(action[i], SIGNAL(triggered(int, QString)), this, SLOT(runCommand(int, QString)));
    }
}

QStringList fileToolh::read(QString file)
{
    QStringList lst;
    FILE *data = fopen(file.toLocal8Bit().data(), "r");
    if(data==NULL)
    {
        Mess mes;
        mes.Fun = "QStringList fileToolh::read(QString file)";
        mes.Head = "fileToolh.h";
        mes.Loc = "fileToolh definition";
        mes.title = "Critical Error";
        mes.Mess = "Core file (" + file + ") is missing. application will be aborted";
        HError HFASTErr;
        HFASTErr.HFASTCritical(mes);
        abort();
    }
    char buffer[50];
    while(!feof(data))
    {
        fscanf(data, "%s", buffer);
        lst.append(buffer);
    }
    fclose(data);
    return lst;
}

bool fileToolh::runCommand(int idx, QString cmd)
{
    if(cmd.compare("decomposePar")==0)
        cmd = "rm -rf 0 && cp -rf 0.orig 0 && " + cmd;
    if(pEvent->saveTool->isReady)
        pEvent->saveTool->runCommand(cmd);
    else
    {
        Mess mes;
        mes.Fun = "void fileToolh::runCommand(QString cmd)";
        mes.Head = "fileTool.h";
        mes.Loc = "Run command:"+cmd;
        mes.title = "Informed";
        mes.Mess = "The application is busy. Please try again in a few minutes";
        HError HFASTErr;
        HFASTErr.HFASTInform(mes);
        return false;
    }
    return true;
}

void fileToolh::repeatTrigger()
{
    //QProcess *pr = new QProcess;
    pEvent->saveTool->runCommandNoWindowEn("repeat");
}

void fileToolh::cleanTrigger()
{
    Mess mes;
    mes.Fun = "void fileToolh::cleanTrigger()";
    mes.Head = "fileTool.h";
    mes.Loc = "Allclean trigger";
    mes.title = "warnning";
    mes.Mess = "This action will clean the case.";
    HError HFASTErr;
    int cti = HFASTErr.HFASTWarning(mes);
    if(cti)
    {
       runCommand(0, "rm -rf *[1-9]* && rm -rf postProcessing && rm -rf processor*");
    }
}

void fileToolh::defineTrigger()
{
    dPanel->readEvery();
    dPanel->showNormal();
}
