#ifndef MODELPAGE_H
#define MODELPAGE_H

#include <QMainWindow>
#include <QVBoxLayout>
#include <QPushButton>
#include <QLabel>
#include <QLineEdit>
#include <QRadioButton>
#include <QGroupBox>
#include <QButtonGroup>
#include "HError.h"
#include "printTool.h"

class modelPage : public QMainWindow
{
    Q_OBJECT
public:
    enum //the same with CMODEL
    {
        KEPSILON=0,
        RNGKEPSILON=1,
        SSTKOMEGA=2,
        SSTKOMEGACD=3,
        V2F=4
    };
    explicit modelPage(printTool *p, QWidget *model);
    QList<mStr> list;
    int count;
    ~modelPage();

private:
    QHBoxLayout *hLayout;
    QVBoxLayout *gLayout[2];
    QHBoxLayout **cLayout;
    QLabel **constant;
    QLineEdit **value;
    int whole;
    QButtonGroup *bGroup;
    QRadioButton **model;
    QGroupBox *nvgGroup[2];
    QList<QStringList> eq;
    QScrollArea *scroArea;

private:
    void setModel();
    void showDetail(mStr m);
    void printModel(QString loc, mStr m);
    void readModel(QString loc);
    void showModel();
    printTool *pEvent;
    int currentIndex;

protected:
   void saveModel();
   void kEpsilon();
   void RNG();
   void SSTKOmega();
   void SSTLM();
   void SSTCD();
   void SSTLMCD();
   void v2f();

signals:

public slots:
   void defineModel(int index);
   void saveProject();
   void readProject();
   void saveEq();
};

#endif // MODELPAGE_H
