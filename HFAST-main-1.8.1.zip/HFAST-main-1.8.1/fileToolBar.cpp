#include "fileToolBar.h"
#include "HError.h"

fileToolBar::fileToolBar(printTool *p, QMenu *File)
{
    pEvent = p;

    //  初始化动作
    setWorkDir = new QAction(tr("Set working directory"));
    readProj = new QAction(tr("Read project (*.json)"));
    savePr = new QAction(tr("Save project"));
    readMesh = new QAction(tr("Read mesh"));
    readBash = new QAction(tr("read bash"));

    //  槽函数链接
    connect(setWorkDir, SIGNAL(triggered()), this, SLOT(setWDTrigger()));

    //  放置动作按钮
    File->addAction(setWorkDir);
    File->addAction(readMesh);
    File->addAction(readProj);
    File->addAction(readBash);
    File->addAction(savePr); 
}

fileToolBar::~fileToolBar()
{

}

void fileToolBar::setWorkDirBash(QString path)
{
    QDir::setCurrent(path);
    emit changeDir(path);
}

bool fileToolBar::readProjectBash(QString json)
{
    pEvent->saveTool->readProject(json, "void fileToolBar::readProject()\n");
    readProj->setEnabled(false);
    setWorkDir->setEnabled(false);
    readMesh->setEnabled(false);
    return true;
}

void fileToolBar::setWDTrigger()
{
    //  打开文件对话框，选择路径
    filePath = QFileDialog::getExistingDirectory(
                this, tr("Please choose a directorey")
                );

    //  设置当前工作目录
    QDir::setCurrent(filePath);
    emit changeDir(filePath);
}

bool fileToolBar::readProject()
{
    setWDTrigger();
    QString file = filePath +"/" +JSONFILE;
    FILE *doc;
    doc = fopen(file.toLocal8Bit().data(),"r");
    if(doc==NULL)
    {
        HError HFASTError;
        Mess mes;
        mes.Fun = "void fileToolBar::readProject()";
        mes.Head = "fileTooBar.h";
        mes.Loc = "void fileToolBar::readProject()\n";
        mes.title = "Warning";
        mes.Mess = "The " + file +" cannot be found. Reading project fails.";
        HFASTError.HFASTWarning(mes);
        return false;
    }
    else
    {
        pEvent->saveTool->readProject(filePath, "void fileToolBar::readProject()\n");
    }
    readProj->setEnabled(false);
    setWorkDir->setEnabled(false);
    readMesh->setEnabled(false);
    return true;
}
