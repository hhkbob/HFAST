#ifndef POST_H
#define POST_H

#include <QWidget>
#include "printTool.h"
#include "HFASTPlot.h"

//#include "fvCFD.H"
//#include "wallFvPatch.H"

namespace Ui {
class post;
}

class post : public QWidget
{
    Q_OBJECT
struct DATA
{
    QStringList variables;
    QList<QStringList> data1;
    bool sucess;
};

public:
    explicit post(printTool *p, QTabWidget *tabEdit);
    ~post();
    printTool *pEvent;
    HFASTPlot **hPlot;
    QTabWidget *tab;
    HFASTPlot *contour;
    QStringList getTimeName(QString path, QString fileName);

private:
    QStringList variables;
    QList<QStringList> data1;
    QStringList timeName;
    bool readRawData(QString fileName, QString timeStep);
    QString externalFile;

    DATA readExterNalFile(QString file);
    void refreshComboBoxItem(QComboBox *box, QStringList lst);
signals:
    void lineEditTrigger(QString item, int idx);

private:
    Ui::post *ui;
    //double getSpecificPointValue(int argc, char *argv[], point p); //int argc, char *argv[]

public slots:
    void lineEditClick(int index);
    void showLineDetail(QString item, int idx);
    void plotXYTrigger();
    void definePanel(printTool *p);
    void plotContour();
private slots:
    void on_surfaceName_activated(const QString &arg1);
    void on_surfaceTime_activated(const QString &arg1);
    void on_surfacePlotBt_clicked();
    void on_dataReadBt_clicked();
    void on_dataDelBt_clicked();
};

#endif // POST_H
