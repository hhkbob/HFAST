#ifndef OPTIMIZE_H
#define OPTIMIZE_H

#include <QObject>

class optimize : public QObject
{
    Q_OBJECT
public:
    explicit optimize();
    QList<QStringList> result;
    QList<QStringList> paraValue;
    QList<QStringList> createSchemes
    (
            QList<QStringList> range,
            int interval
    );
    QList<int> randomNum(int MAX);
    int getNum(int varNum, int currentPosition, int *sorted, int currentvar, int inter);

signals:

public slots:
};

#endif // OPTIMIZE_H
