#include "sampleSurface.h"
#include "ui_sampleSurface.h"

sampleSurface::sampleSurface(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::sampleSurface)
{
    ui->setupUi(this);
    count = 0;
    connect(ui->surface, SIGNAL(activated(int)), this, SLOT(show(int)));
}

sampleSurface::~sampleSurface()
{
    delete ui;
}

void sampleSurface::definePanel(QList<SURFACEGRAPH> lst)
{
    if(count>0)
    {
        for(int i=0; i<ui->surface->count(); i++)
            ui->surface->removeItem(i);
    }
    {
        for(int i=0; i<lst.size(); i++)
        {
            ui->surface->addItem(lst[i].name);
        }
    }
    sGraphList = lst;
}

void sampleSurface::on_pushButton_clicked()
{
    QList<SURFACEGRAPH> List;
    SURFACEGRAPH sGraph;
    sGraph.field = ui->field->text();
    sGraph.normal = QString::number(ui->normal->currentIndex());
    sGraph.points[0] = ui->px->text();
    sGraph.points[1] = ui->py->text();
    sGraph.points[2] = ui->pz->text();
    sGraph.name = ui->name->text();
    int total = ui->surface->count();
    bool exist=false;
    int index=0;
    for(int i=0; i<total; i++)
    {
        if(ui->surface->currentText().compare(sGraph.name)==0)
        {
            exist = true;
            index = i;
        }
        List.append(sGraphList[i]);
    }
    if(total==0 || !exist)
    {
        ui->surface->addItem(sGraph.name);
        List.append(sGraph);
        count++;
    }
    else
        List[index] = sGraph;

    sGraphList = List;
}

void sampleSurface::on_delete_2_clicked()
{
    if(count>0)
    {
        int index = ui->surface->currentIndex();
        ui->surface->removeItem(index);
        sGraphList.removeAt(index);
        count--;
    }
    if(count<0)
        count=0;
}

void sampleSurface::show(int index)
{
    ui->px->setText(sGraphList[index].points[0]);
    ui->py->setText(sGraphList[index].points[1]);
    ui->pz->setText(sGraphList[index].points[2]);
    ui->name->setText(sGraphList[index].name);
    ui->field->setText(sGraphList[index].field);
}
