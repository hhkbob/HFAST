#include "thermal.h"

thermal::thermal()
{
    vLayout = new QVBoxLayout;
    recom = new QLabel("recommand type");
    QStringList reLst;
    reLst<<"none"<<"Boussinesq"<<"rPolynomial"<<"perfectGas";
    recomValue = new QComboBox;
    recomValue->addItems(reLst);
    rLayout = new QHBoxLayout;
    rLayout->addWidget(recom);
    rLayout->addWidget(recomValue);
    vLayout->addLayout(rLayout);
    connect(recomValue, SIGNAL(activated(int)), this, SLOT(setType(int)));

    QStringList label;
    label<<"type"<<"mixture"<<"transport"<<"thermo"
        <<"equationOfState"<<"specie"<<"energy";
    QList<QStringList> vDict;
    QStringList lst1, lst2,lst3,lst4,lst5,lst6, lst7;
    lst1<<"heRhoThermo";
    lst2<<"pureMixture";
    lst3<<"const"<<"sutherland"<<"polynomial"<<"logPolynomial"<<"Andrade"
       <<"tabulated"<<"icoTabulated"<<"WLF";
    lst4<<"hConst"<<"eConst"<<"janaf";
    lst5<<"Boussinesq"<<"rPolynomial"<<"perfectGas"<<"adiabaticPerfectFluid"
       <<"icoPolynomial"<<"icoTabulated"<<"incompressiblePerfectGas"<<"linear"
       <<"PengRobinsonGas"<<"perfectFluid"<<"rhoConst"<<"rhoTabulated";
    lst6<<"specie";
    lst7<<"sensibleEnthalpy";
    vDict.append(lst1);
    vDict.append(lst2);
    vDict.append(lst3);
    vDict.append(lst4);
    vDict.append(lst5);
    vDict.append(lst6);
    vDict.append(lst7);

    for(int i=0; i<THERMALNUM; i++)
    {
        name[i] = new QLabel(label[i]);
        name[i]->setMinimumWidth(120);
        name[i]->setMaximumWidth(120);
        value[i] = new QComboBox;
        value[i]->addItems(vDict[i]);
        hLayout[i] = new QHBoxLayout;
        hLayout[i]->addWidget(name[i]);
        hLayout[i]->addWidget(value[i]);
        vLayout->addLayout(hLayout[i]);
    }
    vLayout->addStretch();
    this->setLayout(vLayout);
}

QStringList thermal::save()
{
    QStringList lst;
    for(int i=0; i<THERMALNUM; i++)
    {
        lst.append(QString::number(value[i]->currentIndex()));
    }
    return lst;
}

void thermal::read(QStringList lst)
{
    for(int i=0; i<THERMALNUM; i++)
    {
        int index = lst[i].toInt();
        value[i]->setCurrentIndex(index);
    }
}

void thermal::setType(int index)
{
    //--none
    //--Boussinesq
    if(index==1)
    {
        value[0]->setCurrentIndex(0);
        value[1]->setCurrentIndex(0);
        value[2]->setCurrentIndex(0);
        value[3]->setCurrentIndex(0);
        value[4]->setCurrentIndex(0);
        value[5]->setCurrentIndex(0);
        value[6]->setCurrentIndex(0);
    }
    else if(index==2) // rPoly
    {
        value[0]->setCurrentIndex(0);
        value[1]->setCurrentIndex(0);
        value[2]->setCurrentIndex(0);
        value[3]->setCurrentIndex(1);
        value[4]->setCurrentIndex(1);
        value[5]->setCurrentIndex(0);
        value[6]->setCurrentIndex(0);
    }
    else if(index==3) //perfectGas
    {
        value[0]->setCurrentIndex(0);
        value[1]->setCurrentIndex(0);
        value[2]->setCurrentIndex(0);
        value[3]->setCurrentIndex(0);
        value[4]->setCurrentIndex(2);
        value[5]->setCurrentIndex(0);
        value[6]->setCurrentIndex(0);
    }
}
