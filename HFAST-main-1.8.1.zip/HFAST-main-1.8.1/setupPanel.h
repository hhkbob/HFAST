#ifndef SETUPPANEL_H
#define SETUPPANEL_H

#include <QDialog>
#include "HError.h"

namespace Ui {
class setUpPanel;
}

class setUpPanel : public QDialog
{
    Q_OBJECT

public:
    explicit setUpPanel(QWidget *parent = 0);
    ~setUpPanel();
    QStringList bashrc;
    QStringList version;
    QString skin;
    QString bashrcPath;
    QString currentVersion;

private:
    Ui::setUpPanel *ui;
    QStringList skinList;
private slots:
    void showBashrc(int idx);
    void on_pushButton_clicked();
    void on_pushButton_2_clicked();
    void on_buttonBox_rejected();
    void showSkin(int idx);
};

#endif // SETUPPANEL_H
