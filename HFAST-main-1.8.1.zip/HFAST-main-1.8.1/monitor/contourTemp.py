from matplotlib.font_manager import FontProperties
import numpy as np
from matplotlib import rcParams
import matplotlib
import matplotlib.pyplot as plt
import math as mt
import os
from scipy.interpolate import griddata 
from decimal import *
Context(prec=28, rounding=ROUND_HALF_EVEN, Emin=-999999, Emax=999999, capitals=1, clamp=0, flags=[], traps=[InvalidOperation, DivisionByZero, Overflow])
getcontext().prec = 50


def plotFoam(fileName, intX, intY, intZ, name, xLabel, yLabel):
   lenSize = 30      #legend size
   labelSize = 40    #label size
   lineWidth=3    #line width
   width = 13.5
   height = 7
   #plt.figure(figsize=(width,height))

   config = {
      "font.family":'serif',
      "font.size": labelSize,
      "mathtext.fontset":'stix',
      "font.serif": ['Times New Roman'],
   }
   #rcParams.update(config)

   #from small to large 
   a = np.loadtxt(fileName)
   x = a[:, intX];
   y = a[:, intY];
   z = a[:, intZ];

   xi=np.linspace(min(x),max(x),400)
   yi=np.linspace(min(y),max(y),400)

   [X,Y]=np.meshgrid(xi,yi)
   V=griddata((x,y),z,(X,Y),method='linear')
   im=plt.contourf(X,Y,V,15,cmap=matplotlib.cm.coolwarm) #cmap=matplotlib.cm.coolwarm
   isoline=plt.contour(X,Y,V,15, linewidths=0.5)
   cbar=plt.colorbar(im)
   cbar.set_label(name)
   plt.xlabel(xLabel); 
   plt.ylabel(yLabel)
   
   #plt.tight_layout()
   plt.show()
   

