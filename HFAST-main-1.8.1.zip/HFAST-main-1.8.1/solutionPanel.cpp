#include "solutionPanel.h"

solutionPanel::solutionPanel(printTool *p, QWidget *w)
{
    tab = new QTabWidget;
    sPanel = new QWidget;
    rePanel = new QWidget;
    add = new QPlainTextEdit;
    wLayout = new QVBoxLayout;
    vLayout = new QVBoxLayout;

    /*QStringList name = getVariables(p);
    if(name.size()>0)
    {
        sGroup = new paraGroup*[name.size()];
        for(int i=0; i<name.size(); i++)
        {
            sGroup[i] = new paraGroup;
            vLayout->addWidget(sGroup[i]);
        }
        sGroupNum = name.size();
    }
    else
    {
        sGroup = NULL;
        sGroupNum = 0;
    }
    vLayout->addStretch();*/
    sGroup = NULL;
    sPanel->setLayout(vLayout);

    QScrollArea *scroArea = new QScrollArea;
    scroArea->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOn);
    scroArea->setWidgetResizable(true);
    scroArea->setWidget(sPanel);
    //scroArea->setStyleSheet("background-color: #242424");

    pEvent = p;
    tab->addTab(scroArea,"solution");
    tab->addTab(rePanel, "relaxation factor");
    QLabel *additional = new QLabel("Additional");

    QVBoxLayout *aLayout = new QVBoxLayout;
    QWidget *aWidget = new QWidget;
    aLayout->addWidget(additional);
    aLayout->addWidget(add);
    aWidget->setLayout(aLayout);
    QSplitter *spliter = new QSplitter(Qt::Vertical);
    spliter->addWidget(tab);
    spliter->addWidget(aWidget);

    wLayout->addWidget(spliter);
    //wLayout->addStretch();
    w->setLayout(wLayout);
    //w->setMaximumWidth(MAXIMUMVIEWPANELWIDTH);

    reName = NULL;
    reValue = NULL;
    reHLayout = NULL;
    reVLayout = new QVBoxLayout;
}

void solutionPanel::defineRe(printTool *pEvents)
{
    if(reName==NULL || reValue==NULL || reHLayout == NULL)
    {
        createLayout(pEvents);
        rePanel->setLayout(reVLayout);
    }
    else
    {
        if(mSelect!=pEvents->saveTool->modelS.index)
        {
            deleteLayout(pEvents);
            createLayout(pEvents);
        }
    }
}

void solutionPanel::deleteLayout(printTool *pEvents)
{
    if(sGroup!=NULL)
    {
        for(int i=0; i<sGroupNum; i++)
            delete sGroup[i];
        delete [] sGroup;
        sGroup = NULL;

        for(int i=0; i<vLayout->count(); i++)
        {
            QLayoutItem *Item = vLayout->itemAt(i);
            if(Item->spacerItem())
            {
                vLayout->removeItem(Item);
                i--;
            }
        }
    }



    for(int i=0; i<reVLayout->count(); i++)
    {
        QLayoutItem *Item = reVLayout->itemAt(i);
        if(Item->spacerItem())
        {
            reVLayout->removeItem(Item);
            i--;
        }
    }

    mSelect = pEvents->saveTool->modelS.index;
    pEvent = pEvents;

    // delete everything
    for(int i=0; i<count; i++)
    {
        delete reName[i];
        delete reValue[i];
        delete reHLayout[i];
    }
    delete [] reName;
    delete [] reValue;
    delete [] reHLayout;
    reName = NULL;
    reValue = NULL;
    reHLayout = NULL;
}

void solutionPanel::createLayout(printTool *pEvents)
{
    QStringList lst = getVariables(pEvents);

    count = lst.size();

    relaxation.len = QString::number(lst.size());
    relaxation.name = lst;

    reName = new QLabel* [count];
    reValue = new QLineEdit* [count];
    reHLayout = new QHBoxLayout*[count];
    for(int i=0; i<count; i++)
    {
        reName[i] = new QLabel(lst[i]);
        reName[i]->setMinimumWidth(60);
        reName[i]->setMaximumWidth(60);
        reValue[i] = new QLineEdit;
        if(lst[i].compare("U")==0)
            reValue[i]->setText("0.2");
        else
            reValue[i]->setText("0.5");
        reHLayout[i] = new QHBoxLayout;
        reHLayout[i]->addWidget(reName[i]);
        reHLayout[i]->addWidget(reValue[i]);
        reVLayout->addLayout(reHLayout[i]);
    }
    //reValue[0]->setText("0.5");
    //reValue[1]->setText("0.7");
    reVLayout->addStretch();
    mSelect = pEvents->saveTool->modelS.index;
    pEvent = pEvents;

    //-- refresh the solution
    sGroup = new paraGroup*[lst.size()];
    for(int i=0; i<lst.size(); i++)
    {
        sGroup[i] = new paraGroup;
        sGroup[i]->para->setText(lst[i]);
        vLayout->addWidget(sGroup[i]);
    }
    vLayout->addStretch();
    sGroupNum = lst.size();
}

QStringList solutionPanel::getVariables(printTool *p)
{
    QStringList mEq = p->saveTool->modelEq;
    QStringList gEq = p->saveTool->eqs;
    QStringList name;
    for(int i=0; i<gEq.size(); i=i+2)
    {
        if(gEq[i].compare("U.orig")==0 || gEq[i].compare("U.org")==0)
            name.append("U");
        else if(gEq[i].compare("T.orig")==0 || gEq[i].compare("T.org")==0)
            name.append("T");
        else if(gEq[i].compare("nut")==0 || gEq[i].compare("alphat")==0)
            continue;
        else
            name.append(gEq[i]);
    }
    for(int i=0; i<mEq.size(); i=i+2)
    {
        if(mEq[i].compare("nut")==0)
            continue;
        else
           name.append(mEq[i]);
    }
    if(pEvent->saveTool->mThermal.heat)
    {
        int thermalIndex = pEvent->saveTool->mThermal.type[3].toInt();
        //if(thermalIndex==0)
        name.append("\"(h|e)\"");
        //else if(thermalIndex==1)
            //name.append("e");
    }
    return name;
}

void solutionPanel::save()
{
    QList<SOLUTION> su;
    for(int i=0; i<sGroupNum; i++)
    {
         if(sGroup[i]->soluteSave.use)
         {
             sGroup[i]->soluteSave.solver = sGroup[i]->line->keyBox[0]->currentText();
             sGroup[i]->soluteSave.smoother = sGroup[i]->line->keyBox[1]->currentText();
             sGroup[i]->soluteSave.pre = sGroup[i]->line->keyBox[2]->currentText();
             su.append(sGroup[i]->soluteSave);
         }
    }
    pEvent->saveTool->solute = su;

    // relaxation factor

    QStringList lst;
    for(int i=0; i<relaxation.len.toInt(); i++)
    {
        lst.append(reValue[i]->text());
    }
    relaxation.value = lst;

    //  additional
    relaxation.additional = add->toPlainText();

    pEvent->printSolution(su, relaxation, "void solutionPanel::save()");
}

void solutionPanel::read(printTool *p)
{
    int count = p->saveTool->solute.size();
    relaxation = p->saveTool->rela;

    defineRe(p);

    for(int i=0; i<sGroupNum; i++)
    {
        if(i<count)
        {
            sGroup[i]->line->soluteSave = pEvent->saveTool->solute[i];
            sGroup[i]->line->readEvery();
            sGroup[i]->para->setText(pEvent->saveTool->solute[i].name);
            sGroup[i]->soluteSave = pEvent->saveTool->solute[i];
        }
        else
        {
            sGroup[i]->soluteSave.use = false;
            sGroup[i]->para->setText(" ");
        }
    }

    for(int i=0; i<relaxation.value.size(); i++)
    {
        reValue[i]->setText(relaxation.value[i]);
    }
    add->appendPlainText(relaxation.additional);
}

linePara::linePara(QObject *parent)
{
    vLayout = new QVBoxLayout;
    for(int i=0; i<6; i++)
    {
        name[i] = new QLabel(" ");
        hLayout[i] = new QHBoxLayout;       
    }
    for(int i=0; i<3; i++)
        value[i] = new QLineEdit;
    for(int i=0; i<3; i++)
        keyBox[i] = new QComboBox;

    name[0]->setText("solver");
    name[1]->setText("tolerance");
    name[2]->setText("relTol");
    name[3]->setText("smoother");
    name[4]->setText("maxIter");
    name[5]->setText("preconditioner");

    value[0]->setText("1e-7");
    value[1]->setText("0.01");
    value[2]->setText("10");

    QStringList solverLst;
    solverLst<<"GAMG"<<"smoothSolver"<<"PBiCGStab"<<"PCG";

    QStringList smootherLst;
    smootherLst<<"symGaussSeidel"<<"GaussSeidel"<<"DICGaussSeidel";

    QStringList preLst;
    preLst<<"DILU"<<"DIC";

    keyBox[0]->addItems(solverLst);
    keyBox[1]->addItems(smootherLst);
    keyBox[2]->addItems(preLst);

    hLayout[0]->addWidget(name[0]);
    hLayout[0]->addWidget(keyBox[0]);

    hLayout[1]->addWidget(name[1]);
    hLayout[1]->addWidget(value[0]);

    hLayout[2]->addWidget(name[2]);
    hLayout[2]->addWidget(value[1]);

    hLayout[3]->addWidget(name[3]);
    hLayout[3]->addWidget(keyBox[1]);

    hLayout[4]->addWidget(name[4]);
    hLayout[4]->addWidget(value[2]);

    hLayout[5]->addWidget(name[5]);
    hLayout[5]->addWidget(keyBox[2]);

    for(int i=0; i<6; i++)
        vLayout->addLayout(hLayout[i]);
    vLayout->addStretch();
    this->setLayout(vLayout);
    soluteSave.use = false;
}

void linePara::saveEvery()
{
    soluteSave.value[0] = QString::number(keyBox[0]->currentIndex());
    soluteSave.value[1] = value[0]->text();
    soluteSave.value[2] = value[1]->text();
    soluteSave.value[3] = QString::number(keyBox[1]->currentIndex());
    soluteSave.value[4] = value[2]->text();
    soluteSave.value[5] = QString::number(keyBox[2]->currentIndex());
    soluteSave.use = true;
}

void linePara::readEvery()
{
    keyBox[0]->setCurrentIndex(soluteSave.value[0].toInt());
    value[0]->setText(soluteSave.value[1]);
    value[1]->setText(soluteSave.value[2]);
    keyBox[1]->setCurrentIndex(soluteSave.value[3].toInt());
    value[2]->setText(soluteSave.value[4]);
    keyBox[2]->setCurrentIndex(soluteSave.value[5].toInt());
    soluteSave.use = true;
}

paraGroup::paraGroup()
{
    para = new QLineEdit;
    line = new linePara;
    Button = new QPushButton("...");
    saveBt = new QPushButton("save");
    delBt = new QPushButton("del");
    hLayout = new QHBoxLayout;
    hLayout->addWidget(para);
    hLayout->addWidget(Button);
    hLayout->addWidget(saveBt);
    hLayout->addWidget(delBt);
    line->saveEvery();
    soluteSave = line->soluteSave;
    soluteSave.use = false;
    connect(Button, SIGNAL(clicked(bool)), this, SLOT(triggered()));
    connect(saveBt, SIGNAL(clicked(bool)), this, SLOT(save()));
    connect(delBt, SIGNAL(clicked(bool)), this, SLOT(clearPanel()));
    this->setLayout(hLayout);
    //this->setStyleSheet("QGroupBox{ margin-top:0px;} QGroupBox:title {margin-top: 0px;}");
}

void paraGroup::save()
{
    line->saveEvery();
    soluteSave = line->soluteSave;
    soluteSave.use = true;
    soluteSave.name = para->text();
    soluteSave.solver = line->keyBox[0]->currentText();
    soluteSave.smoother  = line->keyBox[1]->currentText();
    soluteSave.pre = line->keyBox[2]->currentText();
}

void paraGroup::triggered()
{
    line->soluteSave = soluteSave;
    line->readEvery();
    line->show();
}

void paraGroup::clearPanel()
{
    soluteSave.use = false;
    para->setText("..");
}
