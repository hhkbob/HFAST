#include "schemePanel.h"


schemeWidget::schemeWidget(QStringList first, QStringList lst, int idx, int schemKey)
{
    bounded = new QComboBox;
    bounded->addItems(first);

    scheme = new QComboBox;
    scheme->addItems(lst);

    other = new QLineEdit;
    other->setEnabled(false);
    name = new QLineEdit;
    addWidget = new QPushButton("+");
    addWidget->setMinimumSize(12, 12);
    addWidget->setMaximumSize(12, 12);
    layout = new QHBoxLayout;

    name->setMinimumWidth(100);
    name->setMaximumWidth(100);

    layout->addWidget(name);
    layout->addWidget(bounded);
    layout->addWidget(scheme);
    layout->addWidget(other);
    layout->addWidget(addWidget);
    layout->setMargin(0);
    this->setLayout(layout);
    index = idx;
    if(schemKey==DDV || schemKey==DDT)
        connect(scheme, SIGNAL(activated(int)), this, SLOT(hideOther(int)));
    else if(schemKey==DDG)
        connect(bounded, SIGNAL(activated(int)),this, SLOT(hideGrad(int)));
    connect(addWidget, SIGNAL(clicked(bool)), this, SLOT(addClicked()));
}

schemeWidget::~schemeWidget()
{
    delete bounded;
    delete scheme;
    delete name;
    delete other;
    delete addWidget;
    delete layout;
}

SCHEME schemeWidget::saveState()
{
    sch.name = name->text();
    sch.first = bounded->currentText();
    sch.firstIndex = bounded->currentIndex();
    sch.scheme = scheme->currentText();
    sch.schemeIndex = scheme->currentIndex();
    sch.other = other->text();
    return sch;
}

void schemeWidget::hideOther(int index)
{
    if(index==2)
       other->setEnabled(true);
    else
        other->setEnabled(false);
}

void schemeWidget::hideGrad(int index)
{
    if(index==0)
        other->setEnabled(false);
    else
        other->setEnabled(true);
}

void schemeWidget::addClicked()
{
    emit addButtonClicked(index);
}

schemePanel::schemePanel(printTool *p, QWidget *w)
{
     pEvent = p;

     QStringList ddvFirst;
     ddvFirst.append("none");
     ddvFirst.append("bounded");
     QStringList lst;
     lst.append("none");
     lst.append("upwind");
     lst.append("limitedLinear");
     lst.append("linearUpwind");
     lst.append("linear");
     lst.append("MUSCL");
     lst.append("QUICK");
     lst.append("midPoint");
     lst.append("vanLeer");
     ddvGroup = new schemeGroup("ddvSchemes", ddvFirst, lst, false, DDV, false, false);

     // time
     QStringList timeFirst;
     timeFirst.append("none");
     QStringList timeList;
     timeList.append("steadyState");
     timeList.append("Euler");
     timeList.append("CrankNicolson");
     timeList.append("backward");
     timeList.append("localEuler");
     ddtGroup = new schemeGroup
     (
          "ddtSchemes",
          timeFirst,
          timeList,
          false,
          DDT,
          true,
          false
     );

     QStringList gradFirst;
     gradFirst.append("none");
     gradFirst.append("cellMDLimited");
     gradFirst.append("cellLimited");
     gradFirst.append("faceMDLimited");
     gradFirst.append("faceLimited");

     QStringList gradList;
     gradList.append("Gauss linear");
     gradList.append("leastSquares");
     gradList.append("edgeCellsLeastSquares");
     gradList.append("Gauss cubic");
     gradGroup = new schemeGroup
     (
         "gradSchemes",
         gradFirst,
         gradList,
         false,
         DDG,
         false,
         false
     );

     QStringList laps;
     laps.append("Gauss linear");
     laps.append("none");
     QStringList snGrad;
     snGrad.append("corrected");
     snGrad.append("none");
     snGrad.append("limited corrected");
     snGrad.append("orthogonal");
     snGrad.append("uncorrected");
     QStringList inter;
     inter<<"linear"<<"none";
     lapGroup = new schemeGroup("laplacianSchemes", laps, snGrad, true, DDV, false, false);

     snGroup = new schemeGroup("snGradSchemes", inter, snGrad, true, DDV, true, false);

     interGroup = new schemeGroup("interpolationSchemes", inter, inter, true, DDV, true, true);

     for(int i=0; i<3; i++)
     {
         tabW[i] = new QWidget;
         tabLayout[i] = new QVBoxLayout;
     }
     schemeT = new QTabWidget;
     schemeT->addTab(tabW[0], "ddtSchemes");
     schemeT->addTab(tabW[1], "gradSchemes");
     schemeT->addTab(tabW[2], "divSchemes");
     schemeT->setStyleSheet("QTabWidget:panel{border: 1px solid; border-color: rgb(255, 255, 255);}");

     divWidget = new QWidget;
     useRecommend = new QPushButton(tr("open recommand"));
     divLayout = new QVBoxLayout;
     divLayout->addWidget(useRecommend);
     divLayout->addWidget(ddvGroup);
     divWidget->setLayout(divLayout);
     useRec = false;
     connect(useRecommend, SIGNAL(clicked(bool)), this, SLOT(reBtTrigger()));

     tabLayout[0]->addWidget(ddtGroup);
     tabLayout[1]->addWidget(gradGroup);
     tabLayout[2]->addWidget(divWidget);


     connect(schemeT, SIGNAL(currentChanged(int)), this, SLOT(tabChange(int)));

     wLayout = new QVBoxLayout;
     scroArea = new QScrollArea;
     scroArea->setWidgetResizable(true);
     scroArea->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOn);
     scroArea->setWidget(schemeT);

     spliter = new QSplitter(Qt::Vertical);
     spliter->addWidget(scroArea);

     QGroupBox *gemp = new QGroupBox;
     QVBoxLayout *gempLayout = new QVBoxLayout;
     gempLayout->addWidget(lapGroup);
     gempLayout->addWidget(interGroup);
     gempLayout->addWidget(snGroup);
     gemp->setLayout(gempLayout);
     gempLayout->addStretch();
     spliter->addWidget(gemp);

     wLayout->addWidget(spliter);
     w->setLayout(wLayout);
     //w->setMaximumWidth(MAXIMUMVIEWPANELWIDTH);
     tabChange(0);
     firstRead = true;
}

schemePanel::~schemePanel()
{
    delete ddtGroup;
    delete gradGroup;
    delete ddvGroup;
    delete lapGroup;
    delete interGroup;
    delete snGroup;
    delete tabW;
    delete tabLayout;
    delete schemeT;
    delete wLayout;
}

void schemePanel::saveProject()
{
    //  time scheme
    pSCHEME psch = saveScheme();
    pEvent->printSchemes(psch, "void schemePanel::saveProject()");
}

pSCHEME schemePanel::saveScheme()
{
    pSCHEME psch;
    psch.ddt = ddtGroup->saveState();
    psch.div = ddvGroup->saveState();
    psch.lap = lapGroup->saveState();
    psch.snG = snGroup->saveState();
    psch.inter = interGroup->saveState();
    psch.grad = gradGroup->saveState();
    return psch;
}

int schemePanel::hiddenScheme(schemeGroup *group)
{
    int schemeCount = group->saveState().size();
    for(int i=0; i<schemeCount; i++)
        group->schemeW[i]->setHidden(true);
    return schemeCount;
}

QStringList schemePanel::getVariables(printTool *p)
{
    QStringList mEq = p->saveTool->modelEq;
    QStringList gEq = p->saveTool->eqs;
    QStringList name;
    for(int i=0; i<gEq.size(); i=i+2)
    {
        if(gEq[i].compare("U.orig")==0 || gEq[i].compare("U.org")==0)
            name.append("U");
        else if(gEq[i].compare("T.orig")==0 || gEq[i].compare("T.org")==0)
            name.append("T");
        else if(gEq[i].compare("nut")==0 || gEq[i].compare("alphat")==0)
            continue;
        else
            name.append(gEq[i]);
    }
    for(int i=0; i<mEq.size(); i=i+2)
    {
        if(mEq[i].compare("nut")==0)
            continue;
        else
           name.append(mEq[i]);
    }
    if(pEvent->saveTool->mThermal.heat)
    {
        int thermalIndex = pEvent->saveTool->mThermal.type[3].toInt();
        if(thermalIndex==0)
            name.append("h");
        else if(thermalIndex==1)
            name.append("e");
    }
    return name;
}

void schemePanel::readProject()
{
    if(firstRead)
    {
        pSCHEME psch;
        psch = pEvent->saveTool->scheme;

        // time
        //int schemeCount = hiddenScheme(ddtGroup);
        for(int i=0; i<psch.ddt.size(); i++)
        {
            ddtGroup->schemeW[i]->name->setText(psch.ddt[i].name);
            ddtGroup->schemeW[i]->bounded->setCurrentIndex(psch.ddt[i].firstIndex);
            ddtGroup->schemeW[i]->scheme->setCurrentIndex(psch.ddt[i].schemeIndex);
            if(psch.ddt[i].firstIndex!=0)
               ddtGroup->schemeW[i]->other->setText(psch.ddt[i].other);

            //  show in the panel
            emit ddtGroup->schemeW[i]->scheme->activated(i);
            if(i>0)
            {
                emit ddtGroup->schemeW[i-1]->addWidget->clicked(true);
            }
        }
        // div
        //schemeCount = hiddenScheme(ddvGroup);
        for(int i=0; i<psch.div.size(); i++)
        {
            ddvGroup->schemeW[i]->name->setText(psch.div[i].name);
            ddvGroup->schemeW[i]->bounded->setCurrentIndex(psch.div[i].firstIndex);
            ddvGroup->schemeW[i]->scheme->setCurrentIndex(psch.div[i].schemeIndex);
            if(psch.div[i].schemeIndex==2)
               ddvGroup->schemeW[i]->other->setText(psch.div[i].other);

            //  show in the panel
            emit ddvGroup->schemeW[i]->scheme->activated(i);
            if(i>0 )
            {
                emit ddvGroup->schemeW[i-1]->addWidget->clicked(true);
            }
        }
        // grad
        for(int i=0; i<psch.grad.size(); i++)
        {
            gradGroup->schemeW[i]->name->setText(psch.grad[i].name);
            gradGroup->schemeW[i]->bounded->setCurrentIndex(psch.grad[i].firstIndex);
            gradGroup->schemeW[i]->scheme->setCurrentIndex(psch.grad[i].schemeIndex);
            if(psch.grad[i].firstIndex!=0)
               gradGroup->schemeW[i]->other->setText(psch.grad[i].other);

            emit gradGroup->schemeW[i]->bounded->activated(i);
            //  show in the panel
            if(i>0)
            {
                emit gradGroup->schemeW[i-1]->addWidget->clicked(true);
            }
        }
        // lap
        for(int i=0; i<psch.lap.size(); i++)
        {
            lapGroup->schemeW[i]->name->setText(psch.lap[i].name);
            lapGroup->schemeW[i]->bounded->setCurrentIndex(psch.lap[i].firstIndex);
            lapGroup->schemeW[i]->scheme->setCurrentIndex(psch.lap[i].schemeIndex);
            lapGroup->schemeW[i]->other->setText(psch.lap[i].other);

            //  show in the panel
            emit lapGroup->schemeW[i]->scheme->activated(i);
            if(i>0)
            {
                emit lapGroup->schemeW[i-1]->addWidget->clicked(true);
            }
        }
        // inter
        for(int i=0; i<psch.inter.size(); i++)
        {
            interGroup->schemeW[i]->name->setText(psch.inter[i].name);
            interGroup->schemeW[i]->scheme->setCurrentIndex(psch.inter[i].schemeIndex);
            interGroup->schemeW[i]->other->setText(psch.inter[i].other);
            interGroup->schemeW[i]->bounded->setCurrentIndex(psch.inter[i].firstIndex);

            //  show in the panel
            emit interGroup->schemeW[i]->scheme->activated(i);
            if(i>0)
            {
                emit interGroup->schemeW[i-1]->addWidget->clicked(true);
            }
        }
        //  snGrad
        for(int i=0; i<psch.snG.size(); i++)
        {
            snGroup->schemeW[i]->name->setText(psch.snG[i].name);
            snGroup->schemeW[i]->scheme->setCurrentIndex(psch.snG[i].schemeIndex);
            snGroup->schemeW[i]->other->setText(psch.snG[i].other);
            snGroup->schemeW[i]->bounded->setCurrentIndex(psch.snG[i].firstIndex);

            //  show in the panel
            emit snGroup->schemeW[i]->scheme->activated(i);
            if(i>0)
            {
                emit snGroup->schemeW[i-1]->addWidget->clicked(true);
            }
        }
        firstRead = false;
    }
    else
    {
        Mess mes;
        mes.Fun = "void schemePanel::readProject()";
        mes.Head = "schemePanel.h";
        mes.Loc = "read project";
        mes.title = "Warnning";
        mes.Mess = "The scheme is not read";
        HError HFASTError;
        HFASTError.HFASTWarning(mes);
    }
}

void schemePanel::tabChange(int index)
{
    schemeT->currentWidget()->setLayout(tabLayout[index]);
    tabLayout[index]->addStretch();
}

void schemePanel::reBtTrigger()
{
    if(!useRec)
    {
        Mess mes;
        mes.Fun = "void schemePanel::reBtTrigger()";
        mes.Head = "schemePanel.h";
        mes.Loc = "recommand button is triggered";
        mes.title = "Warnning";
        mes.Mess = "Pay attention: all the div scheme settings will be clear";
        HError HFASTError;
        int mark = HFASTError.HFASTWarning(mes);
        if(mark ==1)
        {
            useRec = true;
            reScheme(pEvent);
            useRecommend->setText("close recommand");
        }
    }
    else
    {
        useRec = false;
        useRecommend->setText("open recommand");
    }
}

void schemePanel::reScheme(printTool *p)
{
    //  give recommand
    QList<SCHEME> se = ddvGroup->saveState();
    int count = se.size();
    for(int i=0; i<count; i++)
        ddvGroup->schemeW[i]->setHidden(true);

    QStringList name = getVariables(p);

    if(name.size()>20)
    {
        Mess mes;
        mes.Fun = "void schemeGroup::reScheme(printTool *p)";
        mes.Head = "schemePanel.h";
        mes.Loc = "add scheme";
        mes.title = "Warning";
        mes.Mess = "The maximum count of parameter is only 20";
        HError HFASTError;
        HFASTError.HFASTWarning(mes);
        return;
    }
    char buffer[200];

    for(int i=0; i<name.size()+1; i++)
    {
        //  show in the panel
        emit ddvGroup->schemeW[i]->scheme->activated(i);
        if(i>0 && i>=count)
        {
            emit ddvGroup->schemeW[i-1]->addWidget->clicked(true);
        }

        if(i==name.size())
        {
            int solverSelect = pEvent->saveTool->ctrlT.appSelect;
            if(solverSelect==2||solverSelect==5)
                ddvGroup->schemeW[i]->name->setText("div(((rho*nuEff)*dev2(T(grad(U)))))");
            else
                ddvGroup->schemeW[i]->name->setText("div((nuEff*dev2(T(grad(U)))))");
            ddvGroup->schemeW[i]->bounded->setCurrentIndex(0);
            ddvGroup->schemeW[i]->scheme->setCurrentIndex(4);
            ddvGroup->schemeW[i]->setHidden(false);
        }
        else
        {
            sprintf(buffer, "div(phi,%s)", name[i].toLocal8Bit().data());
            ddvGroup->schemeW[i]->name->setText(buffer);
            ddvGroup->schemeW[i]->bounded->setCurrentIndex(1);
            ddvGroup->schemeW[i]->scheme->setCurrentIndex(3);
            ddvGroup->schemeW[i]->setHidden(false);
        }
    }
}

schemeGroup::schemeGroup
(
        QString name,
        QStringList First,
        QStringList scheme,
        bool titleShow,
        int mark,
        bool hiFirst,
        bool hilast
)
{
    this->setWindowFlags(Qt::FramelessWindowHint);
    title = new QLabel(name);
    title->setMinimumHeight(12);
    title->setMaximumHeight(12);

    vLayout = new QVBoxLayout;
    hLayout = new QHBoxLayout;
    hLayout->addWidget(title);
    hLayout->setContentsMargins(0,0,0,0);

    if(titleShow)
        vLayout->addLayout(hLayout);

    for(int i=0; i<20; i++)
    {
        schemeW[i] = new schemeWidget(First, scheme, i, mark);
        schemeW[i]->name->setText("default");
        if(hiFirst)
            schemeW[i]->bounded->setHidden(true);
        if(hilast)
            schemeW[i]->other->setHidden(true);
        connect(schemeW[i]->addWidget, SIGNAL(clicked(bool)), this, SLOT(addScheme()));
    }
    count = 1;

    vLayout->addWidget(schemeW[0]);
    vLayout->setContentsMargins(0, 0, 0, 0);
    this->setLayout(vLayout);
}

schemeGroup::~schemeGroup()
{}

QList<SCHEME> schemeGroup::saveState()
{
    QList<SCHEME> se1;
    for(int i=0; i<count; i++)
    {
        SCHEME sch;
        sch =  schemeW[i]->saveState();
        se1.append(sch);
    }
    return se1;
}

void schemeGroup::deleteStretch()
{
    for(int index=0; index<vLayout->count(); index++)
    {
        QLayoutItem *items = vLayout->itemAt(index);
        if(items->spacerItem())
        {
            vLayout->removeItem(items);
            --index;
        }
    }
}

void schemeGroup::addScheme()
{
    if(count>=20)
    {
        Mess mes;
        mes.Fun = "void schemePanel::addScheme(int index)";
        mes.Head = "schemePanel.h";
        mes.Loc = "add scheme";
        mes.title = "Warning";
        mes.Mess = "The maximum count of parameter is only 20";
        HError HFASTError;
        HFASTError.HFASTWarning(mes);
        return;
    }
    else
    {
        deleteStretch();
        for(int i=0; i<count; i++)
        {
            schemeW[i]->addWidget->setEnabled(false);
        }
        vLayout->addWidget(schemeW[count]);
        vLayout->addStretch();
        vLayout->update();
        count++;
        emit currentCount(count);
    }
}

void schemeGroup::showWidget()
{
    if(show)
    {
        show = false;
    }
    else
    {
        for(int i=0; i<count; i++)
        {
           schemeW[i]->setHidden(true);
        }
        show = true;
    }
}
