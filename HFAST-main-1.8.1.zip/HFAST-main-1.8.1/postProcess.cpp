#include "postProcess.h"


postProcess::postProcess(printTool *p, QMenu *menu, controlPanel *ctrol)
{
    pEvent = p;
    ctr = ctrol;
    connect(ctr, SIGNAL(sendAppName(QString)), this, SLOT(recieveApp(QString)));

    app = read("./core/postProcess_graphs.dat");
    appField = read("./core/postProcess_field.dat");

    //--define menu;
    QStringList menuList;
    menuList<<"field"<<"graphs";
    pMenu = new QMenu*[menuList.size()];
    for(int i=0; i<menuList.size(); i++)
    {
         pMenu[i] = new QMenu(menuList[i]);
         menu->addMenu(pMenu[i]);
    }

    // field
    actionField = new HFASTAction*[appField.size()];
    for(int i=0; i<appField.size(); i++)
    {
        actionField[i] = new HFASTAction(i, appField[i]);
        pMenu[0]->addAction(actionField[i]);
        connect(actionField[i], SIGNAL(triggered(int, QString)), this, SLOT(runFieldCommand(int, QString)));
    }

    //graph
    action = new HFASTAction*[app.size()];
    for(int i=0; i<app.size(); i++)
    {
        action[i] = new HFASTAction(i, app[i]);
        pMenu[1]->addAction(action[i]);
        connect(action[i], SIGNAL(triggered(int, QString)), this, SLOT(runCommand(int, QString)));
    }

}

QStringList postProcess::read(QString file)
{
    QStringList lst;
    FILE *data = fopen(file.toLocal8Bit().data(), "r");
    if(data==NULL)
    {
        Mess mes;
        mes.Fun = "postProcess::read(QString file)";
        mes.Head = "postProcess.h";
        mes.Loc = "postProcess definition";
        mes.title = "Critical Error";
        mes.Mess = "Core file (" + file + ") is missing. application will be aborted";
        HError HFASTErr;
        HFASTErr.HFASTCritical(mes);
        abort();
    }
    char buffer[50];
    while(!feof(data))
    {
        fscanf(data, "%s", buffer);
        lst.append(buffer);
    }
    fclose(data);
    return lst;
}

void postProcess::runCommand(int idx, QString cmd)
{
    QString command = "postProcess -func " + cmd;
    if(pEvent->saveTool->isReady)
        pEvent->saveTool->runCommand(command);
    else
    {
        Mess mes;
        mes.Fun = "void postProcess::runCommand(QString cmd)";
        mes.Head = "postProcess.h";
        mes.Loc = "postProcess:"+cmd;
        mes.title = "Informed";
        mes.Mess = "The application is busy. Please try again in a few minutes";
        HError HFASTErr;
        HFASTErr.HFASTInform(mes);
        return;
    }
}

void postProcess::runFieldCommand(int idx, QString cmd)
{
    QString command = appName + " -postProcess -func " + cmd;
    if(pEvent->saveTool->isReady)
        pEvent->saveTool->runCommand(command);
    else
    {
        Mess mes;
        mes.Fun = "void postProcess::runFieldCommand(QString cmd)";
        mes.Head = "postProcess.h";
        mes.Loc = appName+" postProcess:"+cmd;
        mes.title = "Informed";
        mes.Mess = "The application is busy. Please try again in a few minutes";
        HError HFASTErr;
        HFASTErr.HFASTInform(mes);
        return;
    }
}

void postProcess::recieveApp(QString appNme)
{
    appName = appNme;
}
