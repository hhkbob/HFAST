#ifndef PLOTWIDGET_H
#define PLOTWIDGET_H

#include <QObject>
#include "basic.h"
#include "qcustomplot.h"

class plotWidget : public QCustomPlot
{
    Q_OBJECT
public:
    explicit plotWidget(int idx);
    int index;
    bool first;

public:
    void plotXY(pltPROPERTY plt, int index);
    QList<QColor> color;
    QList<Qt::PenStyle> line;

    //QCPAxisTickerLog *logTicker;
    void addLayer(int num);

signals:

public slots:
    void mouseReEvent(QMouseEvent *event);
};

#endif // PLOTWIDGET_H
