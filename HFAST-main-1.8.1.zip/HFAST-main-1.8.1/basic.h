/**
  * @file     	basic.h
  * @author   	Huakun Huang
  * @email   	huanghuakun0902@163.com
  * @version	V1.0
  * @date    	11-SEP-2022
  * @license  	GNU General Public License (GPL)
  * @brief   	专门存储和解析当前文件的所有项目信息
  * @detail		详细
  * @attention
  *  This file is part of HFAST.                                                \n
  *  This program is free software; you can redistribute it and/or modify 		\n
  *  it under the terms of the GNU General Public License version 3 as 		    \n
  *  published by the Free Software Foundation.                               	\n
  *  You should have received a copy of the GNU General Public License   		\n
  *  along with OST. If not, see <http://www.gnu.org/licenses/>.       			\n
  *  Unless required by applicable law or agreed to in writing, software       	\n
  *  distributed under the License is distributed on an "AS IS" BASIS,         	\n
  *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  	\n
  *  See the License for the specific language governing permissions and     	\n
  *  limitations under the License.   											\n
  *   																			\n
  * @htmlonly
  * <span style="font-weight: bold">History</span>
  * @endhtmlonly
  * Version|Auther|Date|Describe
  * ------|----|------|--------
  * V1.0|Huang Huakun|10-SEP-2022|Create File
  * <h2><center>&copy;COPYRIGHT 2017 WELLCASA All Rights Reserved.</center></h2>
  */

#ifndef BASIC_H
#define BASIC_H

#include <QObject>
#include <QJsonObject>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonValue>
#include <QJsonParseError>
#include <QDir>
#include <QTextBrowser>
#include "QCoreApplication"
#include <QProcess>
#include "foamInit.h"
#include <QDebug>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QComboBox>
#include <QPushButton>
#include <QGroupBox>
#include <QLabel>
#include <QTabWidget>
#include <QRadioButton>
#include <QButtonGroup>
#include <QCheckBox>
#include <QFile>
#include <QPlainTextEdit>
#include <QScrollArea>
#include <QSplitter>
#include "math.h"
#include "QThread"
#include "QTimer"

#include "basicdefine.h"

class generalFunc
{
public:
    generalFunc();
    void FatalErrors(QString inf);
    QList<QStringList> readXYData(QString file);
    QStringList getTimeName(QString path, QString name);
};

class mProcess : public QObject
{
    Q_OBJECT
public:
    explicit mProcess(QObject *parent = nullptr);
    ~mProcess();
    QProcess *process;
    QString cmd;

signals:
    void isReady(bool);

public slots:
    void outputMsg();
    void finished();
    void startCommand();
};

class runThread : public QThread
{
public:
    runThread(QString cmds);
    QString cmd;
protected:
    void run();
};

class basic;
class paraProcess : public QObject
{
    Q_OBJECT
public:
    explicit paraProcess(int ID, QList<QStringList> para, QString taskPath, QString bashrc, QString ref, QString lineName, int varIndex);
    ~paraProcess();
    QList<QStringList> paraControl;
    QString workPath;
    QString bashrc;
    QString refData;
    QString sampleLine;
    int keyFinished;
    int varIndex;
    int procID;
    QList<QVector<double>> refDatas;
    basic *bs;

    int getKeyPara(int runInt);
    QList<QVector<double>> getRefData();
    QList<QStringList> getSampleData(QStringList timeList);
    double minSum;
    QStringList bestPara;

    QProcess *process;
    runThread *run;
    QString cmd;
    QTimer *timer;
signals:
    void isReady(bool);

private slots:
    void onTimeOut();

public slots:
    void isFinished();
    void isStarted();
    void startAgain();
};

class basic : public QObject
{
    Q_OBJECT
public:
    enum //the same with CMODEL
    {
        KEPSILON=0,
        RNGKEPSILON=1,
        SSTKOMEGA=2,
        SSTKOMEGACD=3,
        SSTLMCD=4,
        SSTLM=5,
        V2F=6
    };
    explicit basic(QObject *parent = nullptr);
    QString Version;
    QString gravity[3];
    QString workPath;
    QString bashrc;
    PARADICT para;
    mStr modelS;
    MATERIAL mt;
    QString  mtAdditional;
    THERMAL mThermal;
    QList<QString> mtName;
    QList<QString> mtDimension;
    pSCHEME scheme;
    CTRL ctrlT;
    RESIDUAL re;
    QList<LINEGRAPH> lg;
    QList<SURFACEGRAPH> sampleSur;
    ~basic();
    bool isReady;
    bool incompressible;
    mProcess *pr;
    QList<SOLUTION> solute;
    SOLVERSETTING sDict;
    QStringList modelEq;
    QStringList eqs;
    RELAXATION rela;
    BOUNDARY bdr;

    QList<DEFINEPARA> dParaLst;

    struct MEMORY
    {
        QList<BOUNDARY> bdrLst;
        QList<RELAXATION> relaxationLst;
        QList<QList<SOLUTION>> soluLst;
        QList<RESIDUAL> residualLst;
        QList<pSCHEME> schemeLst;
        QList<mStr> modelLst;
    };
    MEMORY memoryResult;
    bool caseChange;

public:
    void saveProject(QString loc);
    void savePath(QString path, QString);
    void saveParallel();
    void saveModel();
    void saveMaterial();
    QJsonObject saveObjForSchemes(QList<SCHEME> lst, int mark);
    void saveSchemes();
    void saveControl();
    void saveResidual();
    void saveLineMonitor();
    void saveSurfaceMonitor();
    void saveSolute();
    void saveBoundary();
    void saveDefineField();
    void readProject(QString path, QString);
    void runCommand(QString cmd);
    void runCommandNoWindow(QString cmd);
    void runCommandNoWindowEn(QString cmd);
    QString getVersion(QString loc);
    QString getBashrc();

    QJsonObject pathAndVersion;
    QJsonArray  paraObj;
    QJsonObject modelObj;
    QJsonObject mtObj;
    QJsonObject schemeNum;
    QJsonArray schemeObj;
    QJsonObject ctrlObj;
    QJsonObject reObj;
    QJsonObject soluteObj;
    QJsonArray lineArray;
    QJsonArray surfaceArray;
    QJsonObject bdrObj;
    QJsonObject defineFieldObj;
private:
    int numbers[6];

    QPushButton *stopBt;
    QGroupBox *runGroup;
    QHBoxLayout *runLayout;
    QProcess *proc;

private:
    void readJsonValueErr(Mess mes);
    void readParallel(QJsonObject rootObj, QString loc);
    QList<SCHEME> readSchemePart(QJsonArray array, int number, int index);
    void readSchemes(QJsonObject rootObj, QString loc);
    void readModel(QJsonObject rootObj, QString loc);
    void readMaterial(QJsonObject rootObj, QString loc);
    void readControl(QJsonObject rootObj, QString loc);
    void readResidual(QJsonObject rootObj, QString loc);
    void readLineMonitor(QJsonObject root, QString loc);
    void readSurfaceMonitor(QJsonObject root, QString loc);
    void readSolute(QJsonObject root, QString loc);
    void readBoundaryDetail(QJsonObject root, QString loc);
    void readDefineField(QJsonObject root, QString loc);


signals:
    void finished();

public slots:
    void processFinished();
    void QprocessFinished();
    void closeRunGroup();
};


#endif // BASIC_H
