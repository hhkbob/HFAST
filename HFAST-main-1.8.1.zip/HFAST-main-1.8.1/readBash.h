#ifndef READBASH_H
#define READBASH_H

#include <QObject>
#include "runPanel.h"
#include "fileToolBar.h"
#include "generalPanel.h"

class readBash
{
public:
    readBash();
    struct optStr
    {
        QString max;
        QString min;
        QString interval;
        int process;
        int task;
        int varIdx;
        QString ref;
        QString line;
        bool active;
    };
    optStr optimize;

    void readBashFile(QString desFile);
    bool readOptimize(FILE *data);
    bool readRunPanel(QString file, runPanel *p);
    void setRunPanel(runPanel *panel);
    void changeWorkPath(QString file, fileToolBar *f);
    void setProcess(QString file, generalPanel *gpanel);
private:
    QString findValue(QString name, QString file);
};

#endif // READBASH_H
