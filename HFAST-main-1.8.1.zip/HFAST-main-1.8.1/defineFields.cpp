#include "defineFields.h"
#include "ui_defineFields.h"

defineFields::defineFields(printTool *p) :
    ui(new Ui::defineFields)
{
    ui->setupUi(this);
    pEvent = p;
    if(pEvent->saveTool->Version.toInt()==10)
        nameLst<<"components"<<"CourantNo"<<"ddt"<<"div"<<"enstrophy"<<"fieldAverage"
              <<"fieldAverage"<<"grad"<<"Lambda2"<<"log"<<"MachNo"<<"mag"<<"magSqr"<<"Q"
              <<"shearStress"<<"streamFunction"<<"turbulenceFields"<<"turbulenceIntensity"
              <<"vorticity"<<"wallHeatFlux"<<"wallHeatTransferCoeff"<<"wallShearStress"<<"writeCellCentres"
              <<"writeCellVolumes"<<"writeVTK"<<"yPlus";
    else if(pEvent->saveTool->Version.toInt()==5)
        nameLst<<"components"<<"CourantNo"<<"ddt"<<"div"<<"enstrophy"<<"fieldAverage"
              <<"fieldAverage"<<"grad"<<"Lambda2"<<"log"<<"MachNo"<<"mag"<<"magSqr"<<"Q"
              <<"shearStress"<<"streamFunction"<<"turbulenceFields"<<"turbulenceIntensity"
              <<"vorticity"<<"wallHeatFlux"<<"wallHeatTransferCoeff"<<"wallShearStress"<<"writeCellCentres"
              <<"writeCellVolumes"<<"yPlus";

    ui->nameBox->addItems(nameLst);
    //this->setStyleSheet("background-color: rgb(64, 66, 68)");
}

defineFields::~defineFields()
{
    delete ui;
}

void defineFields::on_defineBt_clicked()
{
    // define Fields
    HError HFASTEroor;
    Mess mes;
    mes.Fun = "void defineFields::on_defineBt_clicked()";
    mes.Head = "defineFields.h";
    QString name = ui->nameBox->currentText() +" " + ui->Field->text();
    if(ui->Field->text().isEmpty())
    {
        mes.Loc = " ";
        mes.title = "Warnning";
        mes.Mess = "Field is not defined";
        HFASTEroor.HFASTWarning(mes);
        return;
    }
    else
    {
        int ItemCount = paraList.size();
        bool exist=false;
        for(int i=0; i<ItemCount; i++)
        {
            QString nameItem = paraList[i];
            if(nameItem.compare(name)==0)
            {
                mes.Loc = " ";
                mes.title = "Warnning";
                mes.Mess = "The field has been defined and is not added";
                HFASTEroor.HFASTWarning(mes);
                exist = true;
                break;
            }
        }

        //  add the new item
        if(!exist)
        {
            DEFINEPARA temp;
            temp.name = ui->nameBox->currentText();
            temp.field = ui->Field->text();
            dParaList.append(temp);
            paraList.append(name);
            qDebug()<<"define new field: " + name;
            qDebug()<<BROWSER;
        }
    }
}

void defineFields::on_deleteBt_clicked()
{
    QListWidgetItem *item = ui->list->currentItem();
    if(item==NULL)
    {
        Mess mes;
        mes.Fun = "void defineFields::on_deleteBt_clicked()";
        mes.Head = "defineField.h";
        mes.Loc = "delete button is clicked";
        mes.title = "Warnning";
        mes.Mess = "Item is not choose";;
        HError HFASTError;
        HFASTError.HFASTWarning(mes);
        return ;
    }
    else
    {
        int row = ui->list->currentRow();
        QListWidgetItem *delItem = ui->list->takeItem(row);
        if(delItem)
        {
            delete delItem;
            dParaList.removeAt(row);
            //removeAt(row);
        }

    }
}

void defineFields::removeAllItems()
{
    ui->list->clear();
}

void defineFields::readEvery()
{
    removeAllItems();
    QList<DEFINEPARA> temp;
    QStringList paraTemp;

    temp = dParaList;
    for(int i=0; i<temp.size(); i++)
    {
        ui->nameBox->setCurrentText(temp[i].name);
        ui->Field->setText(temp[i].field);
        QString name = temp[i].name +" " + temp[i].field;
        paraTemp.append(name);
    }
    paraList = paraTemp;
    if(!paraList.isEmpty())
        ui->list->addItems(paraList);
}

void defineFields::readProject()
{
    dParaList = pEvent->saveTool->dParaLst;
    readEvery();
}

void defineFields::closeEvent(QCloseEvent *e)
{
    pEvent->saveTool->dParaLst = dParaList;
}
