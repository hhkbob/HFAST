#include "residualPanel.h"

residualPanel::residualPanel(printTool *p, QWidget *w)
{
    pEvent = p;

    vLayout = new QVBoxLayout;
    //QLabel *sampleL = new QLabel("sample command");
    //time = new QSpinBox;
    //time->setValue(5);
    //sampleEdit = new QLineEdit;
    //QHBoxLayout *sampleH = new QHBoxLayout;
    //sampleH->addWidget(sampleL);
    //sampleH->addWidget(time);
    //QLabel *second = new QLabel("seconds");
    //sampleH->addWidget(second);
    //vLayout->addLayout(sampleH);
    //vLayout->addWidget(sampleEdit);
    //timer = new QTimer;
    //connect(timer,SIGNAL(timeout()), this, SLOT(onTimeOut()));

    reButton[0] = new QCheckBox("Monitor residuals");
    reLine = new QLineEdit;
    reLine->setText("U");

    QLabel *sLabel = new QLabel("surface monitor");
    sButton = new QPushButton("add surface");
    sampleS = new sampleSurface;

    reButton[1] = new QCheckBox("Monitor Lines");
    lGroup = new QGroupBox;
    lLayout = new QVBoxLayout;
    hGLayout = new QHBoxLayout;
    add = new QPushButton("+");
    add->setMinimumSize(12, 12);
    add->setMaximumSize(12, 12);
    for(int i=0; i<MAXIMUMLINE; i++)
    {
        QString label = "line"+QString::number(i);
        lBt[i] = new ButtonLine(label, i);
    }
    reCtr = new lineReCtr("Residual control");
    index = 0;
    lGroup->setLayout(lLayout);
    hGLayout->addWidget(reButton[1]);
    hGLayout->addWidget(add);

    QScrollArea *scroArea = new QScrollArea;
    scroArea->setWidgetResizable(true);
    scroArea->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
    scroArea->setWidget(lGroup);
    //scroArea->setStyleSheet("background-color: #242424");

    QScrollArea *reScroArea = new QScrollArea;
    reScroArea->setWidgetResizable(true);
    reScroArea->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
    reScroArea->setWidget(reCtr);
    //reScroArea->setStyleSheet("background-color: #242424");

    QSplitter *splitter = new QSplitter(Qt::Vertical);
    splitter->addWidget(scroArea);
    splitter->addWidget(reScroArea);

    vLayout->addWidget(reButton[0]);
    vLayout->addWidget(reLine);
    vLayout->addWidget(sLabel);
    vLayout->addWidget(sButton);
    vLayout->addLayout(hGLayout);
    vLayout->addWidget(splitter);
    w->setLayout(vLayout);
    connect(add, SIGNAL(clicked(bool)), this, SLOT(addWidget()));
    connect(sButton, SIGNAL(clicked(bool)), this, SLOT(surfaceGraph()));
}

residualPanel::~residualPanel()
{
    delete reButton;
    delete reLine;
    delete add;
    delete lBt;
    delete reCtr;
    delete lLayout;
    delete hGLayout;
    delete vLayout;
}

void residualPanel::saveForNextStep()
{
    //  save line
    QList<LINEGRAPH> lg;
    for(int i=0; i<index; i++)
    {
        if(!lBt[i]->line->lg.field.isEmpty())
            lg.append(lBt[i]->line->lg);
    }

    pEvent->saveTool->lg = lg;
    reCtr->save();

    QList<SURFACEGRAPH> sampleSur = sampleS->sGraphList;
    pEvent->saveTool->sampleSur = sampleSur;
}

/*void residualPanel::timeBegin()
{
    if(!sampleEdit->text().isEmpty())
    {
        timer->setInterval(time->value()*1000);
        timer->start();
    }
}*/

void residualPanel::saveProject()
{
    //  save line
    QList<LINEGRAPH> lg;
    for(int i=0; i<index; i++)
    {
        if(!lBt[i]->line->lg.field.isEmpty())
            lg.append(lBt[i]->line->lg);
    }
    if(index>0)
        pEvent->printMonitorLine(lg, "void residualPanel::saveProject()");

    pEvent->saveTool->lg = lg;
    reCtr->save();

    RESIDUAL re;
    re.monitor = reButton[0]->isChecked();
    re.line = reButton[1]->isChecked();
    re.para = (reLine->text());
    re.residual = reCtr->ctr;
    re.ReNum = reCtr->ctr.size();
    re.sampleCommand = "save";//sampleEdit->text();
    re.sampleTime = "5";//QString::number(time->value());

    QList<SURFACEGRAPH> sampleSur = sampleS->sGraphList;
    pEvent->saveTool->sampleSur = sampleSur;

    pEvent->printResidual(re, "void residualPanel::saveProject()");
    pEvent->printResidualControl(reCtr->ctr, "void residualPanel::saveProject()");
    pEvent->printSurfaceMonitor(sampleSur, "void residualPanel::saveProject()");
}

void residualPanel::readProject()
{
    reButton[0]->setChecked(pEvent->saveTool->re.monitor);
    reLine->setText(pEvent->saveTool->re.para);

    // read line
    reButton[1]->setChecked(pEvent->saveTool->re.line);
    int count = pEvent->saveTool->lg.size();
    index  = 0;
    for(int i=0; i<count; i++)
    {
        if(addWidget())
        {
            lBt[i]->line->lg = pEvent->saveTool->lg[i];
            lBt[i]->line->readEvery();
            emit lBt[i]->line->save->click();
        }
        else
            break;
    }

    // read Residual
    count = pEvent->saveTool->re.ReNum;
    for(int i=0; i<count; i++)
    {
        if(count>1 && i!=count-1)
           emit reCtr->add->clicked(true);
        reCtr->reT[i]->name->setText(pEvent->saveTool->re.residual[i].name);
        reCtr->reT[i]->value->setText(pEvent->saveTool->re.residual[i].value);
    }

    //sampleEdit->setText(pEvent->saveTool->re.sampleCommand);
    //time->setValue(pEvent->saveTool->re.sampleTime.toInt());


    QList<SURFACEGRAPH> sampleSur = pEvent->saveTool->sampleSur;
    sampleS->definePanel(sampleSur);
}

int residualPanel::addWidget()
{
    if(index<MAXIMUMLINE)
    {
        lLayout->addWidget(lBt[index]);
        index++;
    }
    else
    {
        add->setEnabled(false);
        Mess mes;
        mes.Fun = "void residualPanel::addWidget()";
        mes.Head = "residualPanel.h";
        mes.Loc = "add button is clicked";
        mes.title = "warnning";
        mes.Mess = "Cannot add the monitor line. Exceeding maximum lines";
        HError HFASTErr;
        HFASTErr.HFASTWarning(mes);
        return 0;
    }
    return 1;
}

void residualPanel::surfaceGraph()
{
    sampleS->showNormal();
}

/*void residualPanel::onTimeOut()
{
    QString command = sampleEdit->text();
    pEvent->saveTool->runCommandNoWindow(command);
}*/

lineMonitor::lineMonitor()
{
    //  定义输入框
    for(int i=0; i<7; i++)
        cLine[i] = new QLineEdit;

    //  定义标签
    int kk=0;
    for(int i=0; i<3; i++)
    {
        ckey[i] = new QLabel(" ");
        ckey[i]->setMinimumWidth(40);
        ckey[i]->setMaximumWidth(40);
        hLayout[i] = new QHBoxLayout;
        hLayout[i]->addWidget(ckey[i]);
        if(i<2)
        {
            hLayout[i]->addWidget(cLine[kk]);
            hLayout[i]->addWidget(cLine[kk+1]);
            hLayout[i]->addWidget(cLine[kk+2]);
            kk = kk+3;
        }
        if(i==2)
        {
            hLayout[i]->addWidget(cLine[6]);
        }
    }

    hLayout[3] = new QHBoxLayout;
    type = new QLabel(tr("type"));
    axis = new QLabel(tr("axis"));
    QStringList ty, ax;
    basic *saveTool = new basic;
    if(saveTool->Version.toInt()==10)
        ty<<"lineUniform"<<"lineCell"<<"lineCellFace";
    else if(saveTool->Version.toInt()==5)
        ty<<"uniform"<<"midPoint"<<"midPointAndFace";
    delete saveTool;
    ax<<"distance"<<"x"<<"y"<<"z"<<"xyz";
    keyBox[0] = new QComboBox();
    keyBox[1] = new QComboBox();
    keyBox[0]->addItems(ty);
    keyBox[1]->addItems(ax);
    hLayout[3]->addWidget(type);
    hLayout[3]->addWidget(keyBox[0]);
    hLayout[3]->addWidget(axis);
    hLayout[3]->addWidget(keyBox[1]);

    ckey[0]->setText("start");
    ckey[1]->setText("end");
    ckey[2]->setText("fields");

    save = new QPushButton(tr("save"));

    //  定义布局
    vLayout = new QVBoxLayout;
    sLayout = new QHBoxLayout;

    //  添加组件
    sLayout->addWidget(save);
    sLayout->setAlignment(Qt::AlignRight);

    vLayout->addLayout(hLayout[3]);
    vLayout->addLayout(hLayout[0]);
    vLayout->addLayout(hLayout[1]);
    vLayout->addLayout(hLayout[2]);
    vLayout->addLayout(sLayout);
    //vLayout->setContentsMargins(0, 0, 0, 0);
    this->setLayout(vLayout);
   // this->setStyleSheet("QGroupBox{ margin-top:0px;} QGroupBox:title {margin-top: 0px;}");

    this->setWindowTitle(tr("Sampling for graphs"));

    this->setMaximumSize(100, 80);

    connect(save, SIGNAL(clicked(bool)), this, SLOT(saveEvery()));
}

lineMonitor::~lineMonitor()
{
    delete ckey;
    delete cLine;
    delete type;
    delete axis;
    delete keyBox;
    delete save;
    delete hLayout;
    delete sLayout;
    delete vLayout;
}

void lineMonitor::closeEvent(QCloseEvent *e)
{
    emit close(true);
}

void lineMonitor::saveEvery()
{
    for(int i=0; i<6; i++)
    {
        lg.points[i] = cLine[i]->text();
    }
    lg.field = cLine[6]->text();
    lg.type = keyBox[0]->currentText();
    lg.axis = keyBox[1]->currentText();
    lg.typeIndex = keyBox[0]->currentIndex();
    lg.axisIndex = keyBox[1]->currentIndex();
}

void lineMonitor::readEvery()
{
    for(int i=0; i<6; i++)
    {
        cLine[i]->setText(lg.points[i]);
    }
    cLine[6]->setText(lg.field);
    keyBox[0]->setCurrentText(lg.type);
    keyBox[1]->setCurrentText(lg.axis);
}

void lineMonitor::cancelClicked()
{
}

probe::probe()
{

}

probe::~probe()
{

}

ButtonLine::ButtonLine(QString label, int idx)
{
    this->setText(label);

    index = idx;
    line = new lineMonitor;
    connect(this, SIGNAL(clicked(bool)), this, SLOT(showWidget()));
    connect(line, SIGNAL(close(bool)), this, SLOT(changeLabel()));

    lg.axisIndex = 0;
    lg.typeIndex = 0;
}

ButtonLine::~ButtonLine()
{
    //delete line;
}

void ButtonLine::showWidget()
{
    lg = line->lg;
    line->keyBox[0]->setCurrentIndex(lg.typeIndex);
    line->keyBox[1]->setCurrentIndex(lg.axisIndex);
    for(int i=0; i<6; i++)
    {
        line->cLine[i]->setText(lg.points[i]);
    }
    line->cLine[6]->setText(lg.field);
    line->show();
}

void ButtonLine::changeLabel()
{
    QString str = line->lg.field +" :";
    str = str+"("+line->lg.points[0]+" "+lg.points[1]+" "+lg.points[2]+")";
    str = str+"("+line->lg.points[3]+" "+lg.points[4]+" "+lg.points[5]+")";
    //this->setText(str);
}

ReControl::ReControl()
{
    use = false;
    name = new QLineEdit;
    value = new QLineEdit;
    hLayout = new QHBoxLayout;
    hLayout->addWidget(name);
    hLayout->addWidget(value);
    this->setLayout(hLayout);
}

ReControl::~ReControl()
{
    delete name;
    delete value;
    delete hLayout;
}

QStringList ReControl::save()
{
    QStringList lst;
    lst.append(name->text());
    lst.append(value->text());
    use = true;
    return lst;
}


lineReCtr::lineReCtr(QString ne)
{
    name = new QLabel("name");
    value = new QLabel("value");
    add = new QPushButton("+");
    add->setMinimumSize(12,12);
    add->setMaximumSize(12,12);
    for(int i=0; i<MAXIMUMLINE; i++)
        reT[i] = new ReControl;
    hLayout = new QHBoxLayout;
    vlayout = new QVBoxLayout;
    hLayout->addWidget(name);
    hLayout->addWidget(value);
    hLayout->addWidget(add);
    vlayout->addLayout(hLayout);
    vlayout->addWidget(reT[0]);
    vlayout->addStretch();
    this->setLayout(vlayout);
    this->setTitle(ne);
    //this->setStyleSheet("QGroupBox{ margin-top:0px;} QGroupBox:title {margin-top: -2px;}");
    vlayout->setContentsMargins(0,0,0,0);
    count = 1;
    reT[0]->use = true;
    reT[0]->name->setText("U");
    reT[0]->value->setText("1e-3");
    connect(add, SIGNAL(clicked(bool)), this, SLOT(addTriggered()));
}

lineReCtr::~lineReCtr()
{
    /*delete name;
    delete value;
    delete add;
    delete reT;
    delete hLayout;
    delete vlayout;*/
}

void lineReCtr::save()
{
    QList<unit> ctrs;
    for(int i=0; i<MAXIMUMLINE; i++)
    {
        if(reT[i]->use)
        {
            QStringList lst = reT[i]->save();
            unit pe;
            pe.name = lst[0];
            pe.value = lst[1];
            ctrs.append(pe);
        }
    }
    ctr = ctrs;
}

void lineReCtr::addTriggered()
{
    for(int index=0; index<vlayout->count(); index++)
    {
        QLayoutItem *items = vlayout->itemAt(index);
        if(items->spacerItem())
        {
            vlayout->removeItem(items);
            --index;
        }
    }
    vlayout->addWidget(reT[count]);
    vlayout->addStretch();
    reT[count]->use = true;
    count++;
}
