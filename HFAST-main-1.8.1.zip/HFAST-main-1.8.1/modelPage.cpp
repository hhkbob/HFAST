#include "modelPage.h"
#include "stdlib.h"
#include <QDebug>

modelPage::modelPage(printTool *p, QWidget *m)
{
    pEvent = p;

    hLayout = new QHBoxLayout;
    whole = WCONSTANT;
    constant = new QLabel*[whole];
    value = new QLineEdit*[whole];
    cLayout = new QHBoxLayout*[WCONSTANT];
    currentIndex = 0;

    setModel();
    saveModel();
    showModel();
    m->setLayout(hLayout);
}

modelPage::~modelPage()
{
    delete model;
    delete bGroup;
    delete value;
    delete constant;
    delete cLayout;
    delete gLayout;
    delete nvgGroup;
}

void modelPage::setModel()
{
    QString gName[2];
    gName[0] = tr("");
    gName[1] = tr("");
    for(int i=0; i<2; i++)
    {
        nvgGroup[i] = new QGroupBox(gName[i]);
        gLayout[i] = new QVBoxLayout;
    }

    //  set constant and value
    for(int i=0; i<WCONSTANT; i++)
    {
        constant[i] = new QLabel(" ");
        constant[i]->setMinimumWidth(100);
        constant[i]->setMaximumWidth(100);
        value[i] = new QLineEdit;
        cLayout[i] = new QHBoxLayout;
        cLayout[i]->addWidget(constant[i]);
        cLayout[i]->addWidget(value[i]);
        //cLayout[i]->addStretch();
        gLayout[1]->addLayout(cLayout[i]);
    }

    hLayout->addWidget(nvgGroup[0]);

    scroArea = new QScrollArea;
    scroArea->setWidgetResizable(true);
    //scroArea->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOn);
    scroArea->setWidget(nvgGroup[1]);
    scroArea->setStyleSheet("QScrollArea{border:none}");
    //scroArea->setStyleSheet("background-color: #242424");

    hLayout->addWidget(scroArea);
}

void modelPage::showDetail(mStr m)
{
    for(int i=0; i<WCONSTANT; i++)
    {
        if(i<m.cKey)
        {
            constant[i]->setText(m.cName[i]);
            constant[i]->setHidden(false);
            char buffer[50];
            sprintf(buffer, "%g", m.vName[i]);
            value[i]->setText(buffer);
            value[i]->setHidden(false);
        }
        else
        {
            constant[i]->setHidden(true);
            value[i]->setHidden(true);
        }
    }
    //this->update();
}

void modelPage::printModel(QString loc, mStr m)
{
    FILE *data = fopen("model.data", "ab+");
    if(data==NULL)
    {
        HError HFASTError;
        Mess mes;
        mes.Fun = "void modelPage::printModel(...)";
        mes.Head = "modelPage.h";
        mes.Loc = loc;
        mes.title = "Warning";
        mes.Mess = "cannot create the model.data again";
        HFASTError.HFASTWarning(mes);
    }
    else
    {
        fwrite(&m, sizeof(mStr),1, data);
        fclose(data);
    }
}

void modelPage::readModel(QString loc)
{
    FILE *data = fopen("model.data", "rb");
    if(data==NULL)
    {
        HError HFASTError;
        Mess mes;
        mes.Fun = "void modelPage::readModel(QString loc)";
        mes.Head = "modelPage.h";
        mes.Loc = loc;
        mes.title = "Warning";
        mes.Mess = "cannot find the model.data. It affacts the definition of models.";
        HFASTError.HFASTWarning(mes);
    }
    else
    {
        mStr model;
        while(!feof(data))
        {
           fread(&model, sizeof(mStr), 1, data);
           list.append(model);
        }
        fclose(data);
    }
}

void modelPage::showModel()
{
    readModel("void modelPage::showModel()");

    //  set model name
    count = list.count()-1;
    model = new QRadioButton*[count];
    bGroup = new QButtonGroup;
    for(int i=0; i<count; i++)
    {
        model[i] = new QRadioButton(list[i].name);
        bGroup->addButton(model[i], i);
        gLayout[0]->addWidget(model[i]);
    }

    connect(bGroup, SIGNAL(buttonClicked(int)), this, SLOT(defineModel(int )));

    // set layout
    for(int i=0; i<2; i++)
    {
        gLayout[i]->addStretch();
        nvgGroup[i]->setLayout(gLayout[i]);
    }

    showDetail(list[0]);
    model[0]->setChecked(true);
}

void modelPage::saveModel()
{
    FILE *data =fopen("model.data", "wb");
    if(data!=NULL)
    {
        kEpsilon();
        RNG();
        SSTKOmega();
        SSTCD();
        SSTLMCD();
        SSTLM();
        v2f();
    }
    else
    {
       qDebug()<<"model.data is not found";
    }
}

void modelPage::kEpsilon()
{
    mStr ke;
    ke.cKey = 6;
    strcpy(ke.name, "kEpsilon");
    strcpy(ke.cName[0], "Cmu");
    strcpy(ke.cName[1], "C1");
    strcpy(ke.cName[2], "C2");
    strcpy(ke.cName[3], "C3");
    strcpy(ke.cName[4], "sigmak");
    strcpy(ke.cName[5], "sigmaEps");
    ke.vName[0] = 0.09;
    ke.vName[1] = 1.44;
    ke.vName[2] = 1.92;
    ke.vName[3] = 0.33;
    ke.vName[4] = 1.0;
    ke.vName[5] = 1.3;
    printModel("kEpsilon()", ke);
    QStringList eqs;
    eqs<<"k"<<"[0 2 -2 0 0 0 0]"<<"epsilon"<<"[0 2 -3 0 0 0 0]";
    eq.append(eqs);
}

void modelPage::RNG()
{
    mStr ke;
    ke.cKey = 8;
    strcpy(ke.name, "RNGkEpsilon");
    strcpy(ke.cName[0], "Cmu");
    strcpy(ke.cName[1], "C1");
    strcpy(ke.cName[2], "C2");
    strcpy(ke.cName[3], "C3");
    strcpy(ke.cName[4], "sigmak");
    strcpy(ke.cName[5], "sigmaEps");
    strcpy(ke.cName[6], "eta0");
    strcpy(ke.cName[7], "beta");
    ke.vName[0] = 0.0845;
    ke.vName[1] = 1.42;
    ke.vName[2] = 0.068;
    ke.vName[3] = 0.33;
    ke.vName[4] = 0.71942;
    ke.vName[5] = 0.71942;
    ke.vName[6] = 4.38;
    ke.vName[7] = 0.012;
    printModel("RNGkEpsilon()", ke);
    QStringList eqs;
    eqs<<"k"<<"[0 2 -2 0 0 0 0]"<<"epsilon"<<"[0 2 -3 0 0 0 0]";
    eq.append(eqs);
}

void modelPage::SSTKOmega()
{
    mStr ke;
    ke.cKey = 14;
    strcpy(ke.name, "kOmegaSST");
    strcpy(ke.cName[0], "alphaK1");
    strcpy(ke.cName[1], "alphaK2");
    strcpy(ke.cName[2], "alphaOmega1");
    strcpy(ke.cName[3], "alphaOmega2");
    strcpy(ke.cName[4], "beta1");
    strcpy(ke.cName[5], "beta2");
    strcpy(ke.cName[6], "betaStar");
    strcpy(ke.cName[7], "gamma1");
    strcpy(ke.cName[8], "gamma2");
    strcpy(ke.cName[9], "a1");
    strcpy(ke.cName[10], "b1");
    strcpy(ke.cName[11], "c1");
    strcpy(ke.cName[12], "F3");
    strcpy(ke.cName[13], "KatoLaunder");
    ke.vName[0] = 0.85;
    ke.vName[1] = 1.0;
    ke.vName[2] = 0.5;
    ke.vName[3] = 0.856;
    ke.vName[4] = 0.075;
    ke.vName[5] = 0.0828;
    ke.vName[6] = 0.09;
    ke.vName[7] = 5.0/9.0;
    ke.vName[8] = 0.44;
    ke.vName[9] = 0.31;
    ke.vName[10] = 1.0;
    ke.vName[11] = 10.0;
    ke.vName[12] = 0;
    ke.vName[13] = 0;
    printModel("SSTKOmega()", ke);

    QStringList eqs;
    eqs<<"k"<<"[0 2 -2 0 0 0 0]"<<"omega"<<"[0 0 -1 0 0 0 0]";
    eq.append(eqs);
}

void modelPage::SSTLM()
{
    mStr ke;
    ke.cKey = 22;
    strcpy(ke.name, "kOmegaSSTLM");
    strcpy(ke.cName[0], "alphaK1");
    strcpy(ke.cName[1], "alphaK2");
    strcpy(ke.cName[2], "alphaOmega1");
    strcpy(ke.cName[3], "alphaOmega2");
    strcpy(ke.cName[4], "beta1");
    strcpy(ke.cName[5], "beta2");
    strcpy(ke.cName[6], "betaStar");
    strcpy(ke.cName[7], "gamma1");
    strcpy(ke.cName[8], "gamma2");
    strcpy(ke.cName[9], "a1");
    strcpy(ke.cName[10], "b1");
    strcpy(ke.cName[11], "c1");
    strcpy(ke.cName[12], "F3");

    strcpy(ke.cName[13], "ca1");
    strcpy(ke.cName[14], "ca2");
    strcpy(ke.cName[15], "ce1");
    strcpy(ke.cName[16], "ce2");
    strcpy(ke.cName[17], "cThetat");
    strcpy(ke.cName[18], "sigmaThetat");
    strcpy(ke.cName[19], "lambdaErr");
    strcpy(ke.cName[20], "maxLambdaIter");
    strcpy(ke.cName[21], "katoLaunder");

    ke.vName[0] = 0.85;
    ke.vName[1] = 1.0;
    ke.vName[2] = 0.5;
    ke.vName[3] = 0.856;
    ke.vName[4] = 0.075;
    ke.vName[5] = 0.0828;
    ke.vName[6] = 0.09;
    ke.vName[7] = 5.0/9.0;
    ke.vName[8] = 0.44;
    ke.vName[9] = 0.31;
    ke.vName[10] = 1.0;
    ke.vName[11] = 10.0;
    ke.vName[12] = 0;

    ke.vName[13] = 2;
    ke.vName[14] = 0.06;
    ke.vName[15] = 1;
    ke.vName[16] = 50;
    ke.vName[17] = 0.03;
    ke.vName[18] = 2;
    ke.vName[19] = 1e-6;
    ke.vName[20] = 10;
    ke.vName[21] = 0;

    printModel("SSTKOmegaLM()", ke);

    QStringList eqs;
    eqs<<"k"<<"[0 2 -2 0 0 0 0]"<<"omega"<<"[0 0 -1 0 0 0 0]"
      <<"ReThetat"<<"[0 0 0 0 0 0 0]"<<"gammaInt"<<"[0 0 0 0 0 0 0]";
    eq.append(eqs);
}

void modelPage::SSTCD()
{
    mStr ke;
    ke.cKey = 19;
    strcpy(ke.name, "kOmegaSSTCD");
    strcpy(ke.cName[0], "alphaK1");
    strcpy(ke.cName[1], "alphaK2");
    strcpy(ke.cName[2], "alphaOmega1");
    strcpy(ke.cName[3], "alphaOmega2");
    strcpy(ke.cName[4], "beta1");
    strcpy(ke.cName[5], "beta2");
    strcpy(ke.cName[6], "betaStar");
    strcpy(ke.cName[7], "gamma1");
    strcpy(ke.cName[8], "gamma2");
    strcpy(ke.cName[9], "a1");
    strcpy(ke.cName[10], "b1");
    strcpy(ke.cName[11], "c1");
    strcpy(ke.cName[12], "F3");
    strcpy(ke.cName[13], "f1");
    strcpy(ke.cName[14], "f2");
    strcpy(ke.cName[15], "Katolaunder");
    strcpy(ke.cName[16], "VortexCorrect");
    strcpy(ke.cName[17], "beta0Star");
    strcpy(ke.cName[18], "d1");


    ke.vName[0] = 0.85;
    ke.vName[1] = 1.0;
    ke.vName[2] = 0.5;
    ke.vName[3] = 0.856;
    ke.vName[4] = 0.075;
    ke.vName[5] = 0.0828;
    ke.vName[6] = 0.09;
    ke.vName[7] = 5.0/9.0;
    ke.vName[8] = 0.44;
    ke.vName[9] = 0.31;
    ke.vName[10] = 1.0;
    ke.vName[11] = 10.0;
    ke.vName[12] = 0;
    ke.vName[13] = 680;
    ke.vName[14] = 80;
    ke.vName[15] = 0;
    ke.vName[16] = 0;
    ke.vName[17] = 0.09;
    ke.vName[18] = 1.0;


    printModel("SSTCD()", ke);

    QStringList eqs;
    eqs<<"k"<<"[0 2 -2 0 0 0 0]"<<"omega"<<"[0 0 -1 0 0 0 0]";
    eq.append(eqs);
}

void modelPage::SSTLMCD()
{
    mStr ke;
    ke.cKey = 27;
    strcpy(ke.name, "kOmegaSSTLMCD");
    strcpy(ke.cName[0], "alphaK1");
    strcpy(ke.cName[1], "alphaK2");
    strcpy(ke.cName[2], "alphaOmega1");
    strcpy(ke.cName[3], "alphaOmega2");
    strcpy(ke.cName[4], "beta1");
    strcpy(ke.cName[5], "beta2");
    strcpy(ke.cName[6], "betaStar");
    strcpy(ke.cName[7], "gamma1");
    strcpy(ke.cName[8], "gamma2");
    strcpy(ke.cName[9], "a1");
    strcpy(ke.cName[10], "b1");
    strcpy(ke.cName[11], "c1");
    strcpy(ke.cName[12], "F3");
    strcpy(ke.cName[13], "f1");
    strcpy(ke.cName[14], "f2");
    strcpy(ke.cName[15], "Katolaunder");
    strcpy(ke.cName[16], "VortexCorrect");
    strcpy(ke.cName[17], "beta0Star");

    strcpy(ke.cName[18], "ca1");
    strcpy(ke.cName[19], "ca2");
    strcpy(ke.cName[20], "ce1");
    strcpy(ke.cName[21], "ce2");
    strcpy(ke.cName[22], "cThetat");
    strcpy(ke.cName[23], "sigmaThetat");
    strcpy(ke.cName[24], "lambdaErr");
    strcpy(ke.cName[25], "maxLambdaIter");
    strcpy(ke.cName[26], "d1");

    ke.vName[0] = 0.85;
    ke.vName[1] = 1.0;
    ke.vName[2] = 0.5;
    ke.vName[3] = 0.856;
    ke.vName[4] = 0.075;
    ke.vName[5] = 0.0828;
    ke.vName[6] = 0.09;
    ke.vName[7] = 5.0/9.0;
    ke.vName[8] = 0.44;
    ke.vName[9] = 0.31;
    ke.vName[10] = 1.0;
    ke.vName[11] = 10.0;
    ke.vName[12] = 0;
    ke.vName[13] = 680;
    ke.vName[14] = 80;
    ke.vName[15] = 0;
    ke.vName[16] = 0;
    ke.vName[17] = 0.09;

    ke.vName[18] = 2;
    ke.vName[19] = 0.06;
    ke.vName[20] = 1;
    ke.vName[21] = 50;
    ke.vName[22] = 0.03;
    ke.vName[23] = 2;
    ke.vName[24] = 1e-6;
    ke.vName[25] = 10;
    ke.vName[26] = 1.0;
    printModel("SSTLMCD()", ke);

    QStringList eqs;
    eqs<<"k"<<"[0 2 -2 0 0 0 0]"<<"omega"<<"[0 0 -1 0 0 0 0]"
       <<"ReThetat"<<"[0 0 0 0 0 0 0]"<<"gammaInt"<<"[0 0 0 0 0 0 0]";
    eq.append(eqs);
}

void modelPage::v2f()
{
    mStr ke;
    ke.cKey = 10;
    strcpy(ke.name, "v2f");
    strcpy(ke.cName[0], "Cmu");
    strcpy(ke.cName[1], "CmuKEps");
    strcpy(ke.cName[2], "C1");
    strcpy(ke.cName[3], "C2");
    strcpy(ke.cName[4], "CL");
    strcpy(ke.cName[5], "Ceta");
    strcpy(ke.cName[6], "Ceps2");
    strcpy(ke.cName[7], "Ceps3");
    strcpy(ke.cName[8], "sigmaEps");
    strcpy(ke.cName[9], "sigmaK");
    ke.vName[0] = 0.22;
    ke.vName[1] = 0.09;
    ke.vName[2] = 1.4;
    ke.vName[3] = 0.3;
    ke.vName[4] = 0.23;
    ke.vName[5] = 70;
    ke.vName[6] = 1.9;
    ke.vName[7] = -0.33;
    ke.vName[8] = 1.3;
    ke.vName[9] = 1;
    printModel("v2f()", ke);

    QStringList eqs;
     eqs<<"k"<<"[0 2 -2 0 0 0 0]"<<"epsilon"<<"[0 2 -3 0 0 0 0]"
       <<"v2"<<"[0 2 -2 0 0 0 0]"<<"f"<<"[0 0 -1 0 0 0 0]";
    eq.append(eqs);
}

void modelPage::defineModel(int index)
{
    showDetail(list[index]);
    currentIndex = index;
    list[index].index = index;
    pEvent->saveTool->modelS.index = index;
}

void modelPage::saveProject()
{
    for(int i=0; i<list[currentIndex].cKey;  i++)
    {
        list[currentIndex].vName[i] = value[i]->text().toDouble();
    }
    pEvent->saveTool->modelS = list[currentIndex];
    pEvent->saveTool->modelS.index = currentIndex;
    pEvent->printModel(list[currentIndex], "void modelPage::saveProject()");
}

void modelPage::readProject()
{
    int index = pEvent->saveTool->modelS.index;
    currentIndex = index;
    model[index]->setChecked(true);
    showDetail(pEvent->saveTool->modelS);
}

void modelPage::saveEq()
{
    pEvent->saveTool->modelEq = eq[currentIndex];
}
