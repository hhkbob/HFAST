#ifndef PLOT_H
#define PLOT_H

#include <QObject>
#include "basic.h"
#include "residualPanel.h"
#include "plotWidget.h"
#include <QTimer>
#include <QThread>
#include <QMetaType>
#define MAXPLOT 8

class myThread;
class PLOTDATA;

class plot : public QObject
{
    Q_OBJECT
public:
    explicit plot(residualPanel *rPanel, QTabWidget *tabEdit);
    QStringList time;
    plotWidget *plt[MAXPLOT];
    QString curTimeStep;
    bool first;
private:
    residualPanel *rPanel;
    QTabWidget *tab;
    void plotInTab(int index, QString name);

protected:

signals:

public slots:
    void readResidual(PLOTDATA data);
};

class myThread : public QThread
{
    Q_OBJECT
public:
    myThread();
    QString curTimeStep;
    bool isReady;
    QString timeFolder;

protected:
    void run();
signals:
    void transData(PLOTDATA);

public slots:
    void workFinished();

};

class PLOTDATA
{
public:
    PLOTDATA();
    QList<QStringList> data;
    QStringList name;
    QString curTime;
};
Q_DECLARE_METATYPE(PLOTDATA)

#endif // PLOT_H
