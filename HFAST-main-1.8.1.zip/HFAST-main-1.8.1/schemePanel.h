#ifndef SCHEMEPANEL_H
#define SCHEMEPANEL_H

#include <QObject>
#include <QWidget>
#include "printTool.h"
#include "QSplitter"

#define DDT 1
#define DDG 2
#define DDV 3
#define SNG 4
#define LAP 5

class schemeWidget : public QWidget
{
    Q_OBJECT
public:
    schemeWidget(QStringList lst, QStringList sch, int index, int schemKey);
    ~schemeWidget();
    QHBoxLayout *layout;
    QComboBox *bounded;
    QComboBox *scheme;
    QLineEdit *other;
    QLineEdit *name;
    QPushButton *addWidget;
    int index;
    SCHEME sch;
    SCHEME saveState();

signals:
    void addButtonClicked(int);
private slots:
    void hideOther(int index);
    void hideGrad(int index);
    void addClicked();
};

class schemeGroup : public QWidget
{
    Q_OBJECT
public:
    schemeGroup
    (
            QString name,
            QStringList First,
            QStringList scheme,
            bool titleShow,
            int mark,
            bool hiFirst,
            bool hilast
    );
    ~schemeGroup();
    schemeWidget *schemeW[20];
    QVBoxLayout *vLayout;
    QHBoxLayout *hLayout;
    QLabel *title;
    bool show;
    QList<SCHEME> se;
    int count;

    QList<SCHEME> saveState();

signals:
    void currentCount(int);
private:
    void deleteStretch();
    QPushButton *addWidget[20];

private slots:
    void addScheme();
    void showWidget();

};

class schemePanel : public QObject
{
    Q_OBJECT
public:
    explicit schemePanel(printTool *p, QWidget *w);
    ~schemePanel();
    printTool *pEvent;

    void saveProject();
    void readProject();
    void reScheme(printTool *p);
    bool useRec;
    QTabWidget *schemeT;

private:


    QVBoxLayout *wLayout;
    QWidget *tabW[3];
    QVBoxLayout *tabLayout[3];

    schemeGroup *ddvGroup;
    schemeGroup *ddtGroup;
    schemeGroup *gradGroup;
    schemeGroup *interGroup;
    schemeGroup *snGroup;
    schemeGroup *lapGroup;
    QScrollArea *scroArea;
    QSplitter *spliter;
    QWidget  *divWidget;
    QPushButton *useRecommend;
    QVBoxLayout *divLayout;

    pSCHEME saveScheme();
    int hiddenScheme(schemeGroup *group);
    QStringList getVariables(printTool *p);

    bool firstRead;

signals:

public slots:
    void tabChange(int index);
    void reBtTrigger();
};

#endif // SCHEMEPANEL_H
