#include "readBoundary.h"

readBoundary::readBoundary(QObject *parent) : QObject(parent)
{
    bdr.totalBdr = "0";
}

int readBoundary::readPolyMesh()
{
    QString workPath = QDir::currentPath();
    QString file = workPath + "/constant/polyMesh/boundary";
    FILE *data = fopen(file.toLocal8Bit().data(), "r");
    int currentPosition=0;
    if(data!=NULL)
    {
        char buffer[200];
        while(!feof(data))
        {
            buffer[0] = fgetc(data);
            currentPosition++;
            if(buffer[0]=='(')
            {
                break;
            }
        }
        rewind(data);
        for(int i=0; i<currentPosition-2; i++)
        {
            buffer[0] = fgetc(data);
        }
        buffer[1]='\0';
        bdr.totalBdr = QString(buffer);
        bool OK=false;
        bdr.totalBdr.toInt(&OK);
        if(!OK)
        {
            Mess mes;
            mes.Fun = "void readBoundary::readPolyMesh()";
            mes.Head = "readBoundary.h";
            mes.Loc = "read Mesh triggered";
            mes.title = "warnning";
            mes.Mess = "the boundary file is error";
            HError HFASTError;
            HFASTError.HFASTWarning(mes);
            return 0;
        }
        fscanf(data, "%s", buffer);
        QList<QStringList> value;
        for(int i=0; i<bdr.totalBdr.toInt(); i++)
        {
            QStringList lst = readUnit(data);
            if(lst.size()==0)
                return 0;
            else
                value.append(lst);
        }
        bdr.value = value;
        fclose(data);
        return 1;
    }
    else
        return 0;
 /*   if(data!=NULL)
    {
        char buffer[200];
        while(!feof(data))
        {
            fscanf(data, "%s", buffer);
            if(strcmp(buffer, "(")==0)
            {
                break;
            }
        }
        fseek(data, -4*sizeof(char), SEEK_CUR);
        fscanf(data, "%s", buffer);
        bdr.totalBdr = QString(buffer);
        bool OK=false;
        bdr.totalBdr.toInt(&OK);
        if(!OK)
        {
            Mess mes;
            mes.Fun = "void readBoundary::readPolyMesh()";
            mes.Head = "readBoundary.h";
            mes.Loc = "read Mesh triggered";
            mes.title = "warnning";
            mes.Mess = "the boundary file is error";
            HError HFASTError;
            HFASTError.HFASTWarning(mes);
            return 0;
        }

        QList<QStringList> value;

        fscanf(data, "%s", buffer);
        for(int i=0; i<bdr.totalBdr.toInt(); i++)
        {
            QStringList lst = readUnit(data);
            if(lst.size()==0)
                return 0;
            else
                value.append(lst);
        }
        bdr.value = value;
        fclose(data);
        return 1;
    }
    else
    {
        Mess mes;
        mes.Fun = "void readBoundary::readPolyMesh()";
        mes.Head = "readBoundary.h";
        mes.Loc = "read Mesh triggered";
        mes.title = "warnning";
        mes.Mess = "confirm that there is a mesh in the current working directory";
        HError HFASTError;
        HFASTError.HFASTWarning(mes);
        return 0;
    }*/
}

QStringList readBoundary::readUnit(FILE *data)
{
    QStringList lst;
    char name[100];
    QString type, nFaces, startFace;
    char buffer[200];
    int value;
    fscanf(data, "%s", name);
    fseek(data, 4*sizeof(char), SEEK_CUR);
    fscanf(data, "%s", buffer);
    while(!feof(data))
    {
        fscanf(data, "%s", buffer);
        QString str = QString(buffer).remove(" ");
        if(QString(str).compare("type")==0)
        {
            fscanf(data, "%s", buffer);
            QStringList lst=QString(buffer).split(";");
            type = lst[0];
        }
        else if(strcmp(buffer, "nFaces")==0)
        {
            fscanf(data, "%d", &value);
            fscanf(data, "%s", buffer);
            nFaces = QString::number(value);
        }
        else if(strcmp(buffer, "startFace")==0)
        {
            fscanf(data, "%d", &value);
            fscanf(data, "%s", buffer);
            startFace = QString::number(value);
        }
        if(strcmp(buffer, "}")==0)
            break;
    }
    lst.append(name);
    lst.append(type);
    lst.append(nFaces);
    lst.append(startFace);
    return lst;
}
