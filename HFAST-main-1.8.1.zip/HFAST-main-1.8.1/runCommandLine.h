#ifndef RUNCOMMANDLINE_H
#define RUNCOMMANDLINE_H
#include "generalPanel.h"
#include "modelPage.h"
#include "materialPanel.h"
#include "schemePanel.h"
#include "controlPanel.h"
#include "residualPanel.h"
#include "fileToolBar.h"
#include "textBrowser.h"
#include "fileToolh.h"
#include "plot.h"
#include "solutionPanel.h"
#include "boundaryPanel.h"
#include "postProcess.h"
#include "post.h"
#include "runPanel.h"
#include "readBash.h"
class runCommandLine : public textBrowser
{

public:
    runCommandLine();
    fileToolBar *fBar;
    readBash *runBash;

protected:
    virtual void runMsgCommand();
private:
    void runBashIn(QString qbt);
    void readBashFile(QString file);

};

#endif // RUNCOMMANDLINE_H
