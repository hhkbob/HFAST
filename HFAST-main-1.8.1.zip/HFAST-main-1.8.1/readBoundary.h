#ifndef READBOUNDARY_H
#define READBOUNDARY_H

#include <QObject>
#include "printTool.h"

class readBoundary : public QObject
{
    Q_OBJECT
public:
    explicit readBoundary(QObject *parent = nullptr);
    BOUNDARY bdr;
    int readPolyMesh();
private:
    QStringList readUnit(FILE *data);

signals:

public slots:
};

#endif // READBOUNDARY_H
