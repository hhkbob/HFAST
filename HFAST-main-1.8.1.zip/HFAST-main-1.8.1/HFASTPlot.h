#ifndef HFASTPLOT_H
#define HFASTPLOT_H

#include <QWidget>
#include <qcustomplot.h>

namespace Ui {
class HFASTPlot;
}

class HFASTPlot : public QCustomPlot
{
    Q_OBJECT

public:
    explicit HFASTPlot();
    ~HFASTPlot();

    void plotXY(QStringList x, QStringList y, int idx, QString name, double scaleX, double scaleY);
    void plotPlane(QStringList x, QStringList y, QStringList value);

private:
    Ui::HFASTPlot *ui;
    QList<QColor> color;
    QList<Qt::PenStyle> line;
    void griddata(QVector<double> x, QVector<double> y, QVector<double> z, int nx, int ny);
};

#endif // HFASTPLOT_H
