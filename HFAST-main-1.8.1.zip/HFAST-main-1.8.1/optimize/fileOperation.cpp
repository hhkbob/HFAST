#include <iostream>

int main(int argc, char *argv[])
{
    if(argc>1)
    {
        system("mkdir 
    }
}
