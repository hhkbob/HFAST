#include <iostream>
#include <vector>

using namespace std;
void printHeader(FILE *file);
void printFoot(FILE *file);
void printModel(vector<double> lst);

int main()
{
    FILE *data=fopen("keyPara.H", "r");
    vector<double> lst;
    if(data!=NULL)
    {
        char buffer[50];
        double value;
        while(!feof(data))
        {
            fscanf(data, "%s", buffer);
            int su = fscanf(data, "%lf", &value);
            if(su<0)
                break;
            else
            {
                lst.push_back(value);
            }
            fscanf(data, "%s", buffer);
            printf("%lf\n", value);
        }
        fclose(data);
    }
    printModel(lst);
    return 0;
}

void printHeader(FILE *file)
{
    fprintf(file, "/*--------------------------------*- C++ -*----------------------------------*\\\n");
    fprintf(file, "| =========                 |                                                 |\n");
    fprintf(file, "| \\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox           |\n");
    fprintf(file, "|  \\    /   O peration     | Version:  10                                  |\n");
    fprintf(file, "|   \\  /    A nd           | Web:      www.OpenFOAM.org                      |\n");
    fprintf(file, "|    \\/     M anipulation  |                                                 |\n");
    fprintf(file, "\\*---------------------------------------------------------------------------*/\n");
    fprintf(file, "%s\n{\n", "FoamFile");
    fprintf(file, "    version	   2.0;\n");
    fprintf(file, "    format	   ascii;\n");
    fprintf(file, "    class	   dictionary;\n");
    fprintf(file, "    location	  \"constant\";\n");
    fprintf(file, "    object	   momentumTransport;\n}\n");
    fprintf(file, "//    author      Huakun Huang\n");
    fprintf(file, "//    Email:      huanghuakun0902@163.com\n");
    //fprintf(file, "// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //\n");
}

void printFoot(FILE *file)
{
    fprintf(file, "// ************************************************************************* //");
}

void printModel(vector<double> lst)
{
    FILE *data = fopen("constant/momentumTransport", "w");
    printHeader(data);
    printFoot(data);
    fprintf(data, "\nsimulationType RAS;\n\n");
    fprintf(data, "RAS\n{\n");
    fprintf(data, "     RASModel       %s;\n", "kOmegaSSTLM");
    fprintf(data, "     turbulence      on;\n");
    fprintf(data, "     printCoeffs     on;\n");
    fprintf(data, "     kOmegaSSTCoeffs\n");
    fprintf(data, "     {\n");
    
    {
         fprintf(data, "        beta1  %g;\n", lst[4]);
         fprintf(data, "        beta2  %g;\n", lst[5]);
         fprintf(data, "        ca1    %g;\n", lst[0]);
         fprintf(data, "        ca2    %g;\n", lst[1]);
         fprintf(data, "        ce1    %g;\n", lst[2]);
         fprintf(data, "        cThetat %g;\n", lst[3]);
         fprintf(data, "        Katolaunder       yes;\n");
    }
    fprintf(data, "     }\n");
    fprintf(data, "}\n");
    printFoot(data);
    fclose(data);
}

