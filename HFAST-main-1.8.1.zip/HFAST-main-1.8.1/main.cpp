#include "HFAST.h"
#include <QApplication>
struct inf
{
    bool win;
};

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    qRegisterMetaType<PLOTDATA>("PLOTDATA");
    qRegisterMetaType<PLOTDATA>("PLOTDATA&");
    inf app;
    app.win = true;
    if(argc>1)
    {
        for(int i=1; i<argc; i++)
        {
            if(QString(argv[i]).compare("-noWindow")==0)
               app.win = false;
        }
    }
    HFAST w(app.win);
    if(app.win)
        w.show();

    QFont font = a.font();
    font.setPointSize(10);
    font.setFamily("Calibri");
    a.setFont(font);
    return a.exec();
}
