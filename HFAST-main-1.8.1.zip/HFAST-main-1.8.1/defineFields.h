#ifndef DEFINEFIELDS_H
#define DEFINEFIELDS_H

#include <QWidget>
#include "printTool.h"

namespace Ui {
class defineFields;
}

class defineFields : public QWidget
{
    Q_OBJECT

public:
    explicit defineFields(printTool *p);
    ~defineFields();
    printTool *pEvent;
    QStringList nameLst;
    QList<DEFINEPARA> dParaList;
    QStringList paraList;

private slots:
    void on_defineBt_clicked();

    void on_deleteBt_clicked();

    void removeAllItems();

public slots:
    void readEvery();
    void readProject();
protected:
    virtual void closeEvent(QCloseEvent *e);

private:
    Ui::defineFields *ui;
};

#endif // DEFINEFIELDS_H
