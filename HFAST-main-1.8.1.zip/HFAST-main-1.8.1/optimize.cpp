#include "optimize.h"
#include "error.h"
#include "QTime"
#include "QtGlobal"
#include <QDateTime>
#include "QDebug"
#include <math.h>
#include "iostream"
#include <algorithm>

optimize::optimize()
{

}

QList<QStringList> optimize::createSchemes(QList<QStringList> range, int interval)
{
    QList<QStringList> paraValueTmp;
    qsrand(QTime::currentTime().msec());
    for(int i=0; i<range.size(); i++)
    {
        QStringList value;
        double xMin = range[i][0].toDouble();
        double yMin = range[i][1].toDouble();
        double len = yMin-xMin;
        if(len<=0)
        {
            QString info = "para " + i + QString(" the range is wrong");
            qDebug()<<info;
            QList<QStringList> result;
            return result;
        }
        double size = len/(interval*1.0);
        int key = 0;
        double aMin = xMin;
        double aMax = aMin;
        for(int k=0; k<interval; k++)
        {
            aMax = aMin + size;
            if(k==interval-1)
                aMax = yMin;
            aMax = aMax*1000;
            aMin = aMin*1000;
            {
                int tmp = qrand()%(int(aMax-aMin))+int(aMin);
                value.append(QString::number(tmp*1.0/1000.0));
            }
            aMin = aMax/1000.0;
        }
        paraValueTmp.append(value);
    }
    paraValue = paraValueTmp;
    QList<QStringList> reLst;
    result = reLst;
    int *sorted = new int[range.size()];
    for(int i=0; i<interval; i++)
    {
       getNum(range.size(), 0, sorted, i, interval);
    }
    delete sorted;

    return result;
}

QList<int> optimize::randomNum(int MAX)
{
    int count = MAX-1;
    QList<int> des;
    //qsrand(QTime(0,0,0).secsTo(QTime::currentTime()));
    for(int i=0; i<MAX; i++)
    {
        des.append(i);
    }
    QList<int> sorted;
    while(1)
    {
        int num = 0;
        num = qrand()%(count+1)+0;
        sorted.append(des[num]);
        des.removeAt(num);
        count--;
        if(count<0)
            break;
    }
    return sorted;
}

int optimize::getNum(int varNum, int currentPosition, int *sorted, int currentvar, int interval)
{
    int var = 0;
    for(int j=0; j<interval; j++)
    {
        sorted[currentPosition]=currentvar;
        if(currentPosition+1>varNum-1)
        {
            QStringList lst;
            for(int i=0; i<varNum; i++)
            {
                QString value = paraValue[i][sorted[i]];
                lst.append(value);
            }
            result.append(lst);
            return 0;
        }
        getNum(varNum, currentPosition+1, sorted, var, interval);
        var++;
    }
}
