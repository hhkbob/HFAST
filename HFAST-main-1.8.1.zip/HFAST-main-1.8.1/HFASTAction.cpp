#include "HFASTAction.h"

HFASTAction::HFASTAction(int index, QString command)
{
    idx = index;
    cmd = command;
    this->setText(cmd);
    connect(this, SIGNAL(triggered(bool)), this, SLOT(sendData()));
}

void HFASTAction::sendData()
{
    emit triggered(idx, cmd);
}
