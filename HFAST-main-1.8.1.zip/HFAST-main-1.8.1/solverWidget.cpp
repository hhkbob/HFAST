#include "solverWidget.h"

solverWidget::solverWidget(QVBoxLayout *vlayout)
{
    solverText = new QLabel(tr("Application settings"));
    triggerBt = new QPushButton("SIMPLE");
    sSolver = new simple;
    pSolver = new pimple;
    piSolver = new piso;
    vlayout->addWidget(solverText);
    vlayout->addWidget(triggerBt);
    vlayout->addStretch();
    connect(triggerBt, SIGNAL(clicked(bool)), this, SLOT(solverSettings()));
    set = false;
}

void solverWidget::readProject(SOLVERSETTING dict)
{
    sDict = dict;
    solverDict = sDict.solverDict;
    set = true;
    if(sDict.solverDict == C_SIMPLE)
        sSolver->readEvery(sDict);
    else if(sDict.solverDict == C_PIMPLE)
        pSolver->readEvery(sDict);
    else if(sDict.solverDict == C_PISO)
        piSolver->readEvery(sDict);
}

void solverWidget::solverSettings()
{
    if(solverDict == C_SIMPLE)
    {
        if(set)
        {
            sSolver->readEvery(sDict);
        }
        else
        {
            sSolver->readEvery(sSolver->dict);
        }
        sSolver->show();
    }
    else if(solverDict == C_PIMPLE)
    {
        if(set)
        {
            pSolver->readEvery(sDict);
        }
        else
        {
            pSolver->readEvery(pSolver->dict);
        }
        pSolver->show();
    }
    else if(solverDict == C_PISO)
    {
        if(set)
        {
            piSolver->readEvery(sDict);
        }
        else
        {
            piSolver->readEvery(piSolver->dict);
        }
        piSolver->show();
    }
    else
    {
        Mess mes;
        mes.Fun = "void solverWidget::solverSettings(int solverDict)";
        mes.Head = "solverWidget.h";
        mes.Loc = "triggerBt is triggered";
        mes.title = "Informed";
        mes.Mess = "It doest not need to define";
        HError HFASTError;
        HFASTError.HFASTInform(mes);
    }
}

void solverWidget::changeSolver(int dict)
{
    if(solverDict == C_SIMPLE)
    {
        triggerBt->setText("SIMPLE");
    }
    else if(solverDict == C_PIMPLE)
    {
        triggerBt->setText("PIMPLE");
    }
    else if(solverDict == C_PISO)
    {
        triggerBt->setText("PISO");
    }
    else
    {
        triggerBt->setText("none");
    }
}

simple::simple()
{
    vLayout = new QVBoxLayout;
    QStringList nLst, val;
    nLst<<"nNonOrthogonalCorrectors"<<"consistent"<<"momentumPredictor"<<"pRefPoint"<<" pRefValue";
    val<<"0"<<"yes"<<"true"<<"(0 0 0)"<<"101325";
    dict.value = val;
    for(int i=0; i<simpleNum ; i++)
    {
        name[i] = new QLabel(nLst[i]);
        name[i]->setMinimumWidth(200);
        name[i]->setMaximumWidth(200);
        value[i] = new QLineEdit;
        value[i]->setText(dict.value[i]);
        hLayout[i] = new QHBoxLayout;
        hLayout[i]->addWidget(name[i]);
        hLayout[i]->addWidget(value[i]);
        vLayout->addLayout(hLayout[i]);
    }
    vLayout->addStretch();
    this->setLayout(vLayout);
}

SOLVERSETTING simple::saveEvery()
{
    SOLVERSETTING dicts;
    for(int i=0; i<simpleNum; i++)
        dicts.value.append(value[i]->text());
    dicts.solverDict = C_SIMPLE;

    dict = dicts;
    dict.len = simpleNum;
    return dicts;
}

void simple::readEvery(SOLVERSETTING dicts)
{
    dict = dicts;
    for(int i=0; i<simpleNum; i++)
    {
        value[i]->setText(dicts.value[i]);
    }
}

void simple::closeEvent(QCloseEvent *e)
{
    saveEvery();
}

pimple::pimple()
{
    vLayout = new QVBoxLayout;
    QStringList nLst, val;
    nLst<<"nNonOrthogonalCorrectors"<<"nOuterCorrectors"<<"nCorrectors"<<"correctPhi"
       <<"correctMeshPhi"<<"momentumPredictor"<<"pRefPoint"<<"pRefValue";
    val<<"0"<<"2"<<"1"<<"yes"<<"no"<<"yes"<<"(0 0 0)"<<"101325";
    dict.value = val;
    for(int i=0; i<pimpleNum ; i++)
    {
        name[i] = new QLabel(nLst[i]);
        name[i]->setMinimumWidth(200);
        name[i]->setMaximumWidth(200);
        value[i] = new QLineEdit;
        value[i]->setText(dict.value[i]);
        hLayout[i] = new QHBoxLayout;
        hLayout[i]->addWidget(name[i]);
        hLayout[i]->addWidget(value[i]);
        vLayout->addLayout(hLayout[i]);
    }
    vLayout->addStretch();
    this->setLayout(vLayout);
}

SOLVERSETTING pimple::saveEvery()
{
    SOLVERSETTING dicts;
    for(int i=0; i<pimpleNum; i++)
    {
        dicts.value.append(value[i]->text());
    }
    dicts.solverDict = C_PIMPLE;
    dict = dicts;
    dict.len = pimpleNum;
    return dicts;
}

void pimple::readEvery(SOLVERSETTING dicts)
{
    dict = dicts;
    for(int i=0; i<pimpleNum; i++)
    {
        value[i]->setText(dicts.value[i]);
    }
}

void pimple::closeEvent(QCloseEvent *e)
{
    saveEvery();
}

piso::piso()
{

}
