#include "boundaryPanel.h"

boundaryPanel::boundaryPanel(printTool *p, QWidget *w)
{
    pEvent = p;
    rBdr = new readBoundary;
    vlayout = new QVBoxLayout;

    slpliter = new QSplitter(Qt::Vertical);

    w->setLayout(vlayout);
    //w->setMaximumWidth(MAXIMUMVIEWPANELWIDTH);

    bVLayout = new QVBoxLayout;
    basicBdr = new QWidget;
    basicBdr->setLayout(bVLayout);

    scroArea = new QScrollArea;
    scroArea->setWidgetResizable(true);
    scroArea->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOn);
    scroArea->setWidget(basicBdr);
    //scroArea->setStyleSheet("background-color: #242424");

    tab = new QTabWidget;

    slpliter->addWidget(scroArea);
    slpliter->addWidget(tab);

    vlayout->addWidget(slpliter);
    //vlayout->addStretch();

    name = NULL;
    value = NULL;
    hLayout = NULL;
    totalBasic = 0;
}

void boundaryPanel::deleteBasic(QStringList lst)
{
    for(int i=0; i<nameLst.size(); i++)
    {
        delete bdrVara[i];
    }
    delete bdrVara;

    for(int i=tab->count()-1; i>=0; i--)
    {
        QString name = tab->tabText(i);
        bool exist = false;
        for(int j=0; j<boundaryName.size(); j++)
        {
            if(name.compare(boundaryName[j])==0)
            {
                exist = true;
                break;
            }
        }
        if(!exist)
            tab->removeTab(i);
    }
}

void boundaryPanel::defineBasic(QStringList nameLsts)
{
    bdrVara = new boundarySetting* [nameLsts.size()];
    for(int i=0; i<nameLsts.size(); i++)
    {
        {
            bdrVara[i] = new boundarySetting;
            bdrVara[i]->setUpPanel(rBdr->bdr);
            tab->addTab(bdrVara[i],nameLsts[i]);
        }
    }
    for(int i=0; i<tab->count(); i++)
    {
        QString name = tab->tabText(i);
        for(int j=0; j<boundaryName.size(); j++)
        {
            if(name.compare(boundaryName[j])==0)
            {
                //set the value as defaut
                bdrVara[i]->interValue->setText(bdr.internal[j]);

                for(int k=0; k<bdr.paraIndex[0].size(); k++)
                {
                    bdrVara[i]->edit[k]->clear();
                    bdrVara[i]->edit[k]->appendPlainText(bdr.paraValue[j][k]);
                    bdrVara[i]->value[k]->setCurrentIndex(bdr.paraIndex[j][k].toInt());
                }
            }
        }
    }

    nameLst = nameLsts;
    boundaryName = nameLst;
    totalBasic = nameLst.size();
}

int boundaryPanel::setUpPanel
(
        QList<QStringList> paraName,
        QStringList lst,
        int mIndex,
        int sIndex,
        int sSelect
)
{
    bdr.paraName = paraName;
    bdr.totalBdr = lst.size();
    {
        if(!tab->count())
        {
            modelIndex = mIndex;
            solverIndex = sIndex;
            solverSelect = sSelect;
            defineBasic(lst);
        }
        else
        {
            if(mIndex!=modelIndex || sIndex!=solverIndex || sSelect!=solverSelect)
            {
                modelIndex = mIndex;
                solverIndex = sIndex;
                solverSelect = sSelect;
                deleteBasic(lst);
                defineBasic(lst);
            }
        }
        return 1;
    }
}

int boundaryPanel::defineMeshPanel()
{
    int sucess = rBdr->readPolyMesh();
    if(sucess)
    {
        totalBasic = rBdr->bdr.totalBdr.toInt();
        bdr.totalBdr = rBdr->bdr.totalBdr;
        bdr.value = rBdr->bdr.value;
        QStringList lst;
        lst<<"patch"<<"wall"<<"symmetryPlane"<<"symmetry"<<"empty"<<"wedge";

        name = new QLabel*[totalBasic];
        value = new QComboBox*[totalBasic];
        hLayout = new QHBoxLayout*[totalBasic];

        for(int i=0; i<totalBasic; i++)
        {
            name[i] = new QLabel(rBdr->bdr.value[i][0]);
            //name[i]->setMinimumWidth(100);
            //name[i]->setMaximumWidth(100);
            value[i] = new QComboBox;
            value[i]->addItems(lst);
            for(int j=0; j<lst.size(); j++)
            {
                if(strcmp(lst[j].toLocal8Bit().data(), rBdr->bdr.value[i][1].toLocal8Bit().data())==0)
                {
                    value[i]->setCurrentIndex(j);
                    break;
                }
            }
            hLayout[i] = new QHBoxLayout;
            hLayout[i]->addWidget(name[i]);
            hLayout[i]->addWidget(value[i]);
            bVLayout->addLayout(hLayout[i]);
        }
        bVLayout->addStretch();
        return 1;
    }
    return 0;
}

void boundaryPanel::delecteMeshPanel()
{
    if(name!=NULL)
    {
        for(int i=0; i<vlayout->count(); i++)
        {
            QLayoutItem *Item = vlayout->itemAt(i);
            if(Item->spacerItem())
            {
                vlayout->removeItem(Item);
                i--;
            }
        }

        for(int i=0; i<totalBasic; i++)
        {
            delete name[i];
            delete value[i];
            delete hLayout[i];
        }
        delete name;
        delete value;
        delete hLayout;
    }
}

int boundaryPanel::saveProject()
{
    //  bdr.value
    bdr.totalBdr = rBdr->bdr.totalBdr;
    bdr.value = rBdr->bdr.value;

    for(int i=0; i<bdr.totalBdr.toInt(); i++)
    {
        bdr.value[i][1] = value[i]->currentText();
    }

    //  detail
    QList<QStringList> paraV, paraIndex;
    QStringList interV;
    int count = 0;
    for(int i=0; i<bdr.paraName.size(); i++)
        count = count + bdr.paraName[i].size();

    count = count /2;
    QStringList name;
    for(int i=0; i<bdr.paraName.size(); i++)
        for(int j=0; j<bdr.paraName[i].size(); j=j+2)
            name.append(bdr.paraName[i][j]);

    bool su = true;
    for(int i=0; i<count; i++)
    {
        QStringList lst, index;
        for(int j=0; j<bdr.totalBdr.toInt(); j++)
        {
            lst.append(bdrVara[i]->edit[j]->toPlainText());
            index.append(QString::number(bdrVara[i]->value[j]->currentIndex()));
            if(bdrVara[i]->value[j]->currentIndex()==0)
            {
                Mess mes;
                mes.Fun = "void boundaryPanel::saveProject()";
                mes.Head = "boundaryPanel.h";
                mes.Loc = "save the boundary detail";
                mes.title = "Warnning";
                mes.Mess = "The boundary " + name[i] + " " + bdr.value[j][0]
                        + " block is not defined;\n Save project is failed!";
                HError HFASTError;
                int mark = HFASTError.HFASTWarning(mes);
                if(mark==0)
                {
                    su = false;
                    break;
                }
            }
        }
        if(!su)
            break;
        else
        {
            paraV.append(lst);
            paraIndex.append(index);
            interV.append(bdrVara[i]->interValue->text());
        }
    }
    if(su)
    {
        bdr.paraIndex = paraIndex;
        bdr.paraValue = paraV;
        bdr.internal = interV;

        pEvent->printBoundary(bdr, "void boundaryPanel::saveProject()");
    }
    else
        return 0;
    return 1;
}

void boundaryPanel::readProject()
{
    rBdr->readPolyMesh();

    bdr = pEvent->saveTool->bdr;

    if(rBdr->bdr.totalBdr.toInt()!= bdr.totalBdr.toInt())
    {
        Mess mes;
        mes.Fun = "void boundaryPanel::readProject()";
        mes.Head = "boundaryPanel.h";
        mes.Loc = "read the boundary detail";
        mes.title = "Warnning";
        mes.Mess = "The boundary ("+ rBdr->bdr.totalBdr+ ")" +" is not same with the user.json (" +bdr.totalBdr+")";
        HError HFASTError;
        int mark = HFASTError.HFASTWarning(mes);
        return;
    }

    //-- set value
    int total = bdr.totalBdr.toInt();
    for(int i=0; i<total; i++)
    {
        value[i]->setCurrentText(bdr.value[i][0]);
    }

    int count = (bdr.paraName[0].size())/2;

    modelIndex = pEvent->saveTool->modelS.index;
    solverIndex = pEvent->saveTool->ctrlT.appIndex;
    solverSelect = pEvent->saveTool->ctrlT.appSelect;

    QStringList name;
    for(int i=0; i<bdr.paraName.size(); i++)
        for(int j=0; j<bdr.paraName[i].size(); j=j+2)
            name.append(bdr.paraName[i][j]);

    setUpPanel(bdr.paraName, name, modelIndex, solverIndex, solverSelect);

    for(int i=0; i<count; i++)
    {
        for(int j=0; j<total; j++)
        {
            bdrVara[i]->edit[j]->clear();
            bdrVara[i]->edit[j]->appendPlainText(bdr.paraValue[i][j]);
            bdrVara[i]->value[j]->setCurrentIndex(bdr.paraIndex[i][j].toInt());
        }
        bdrVara[i]->interValue->setText(bdr.internal[i]);
    }
}

boundarySetting::boundarySetting()
{
    widget = new QWidget;
    this->setWidgetResizable(true);
    this->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOn);
    //this->setStyleSheet("background-color: #242424");

    vLayout = new QVBoxLayout;
    widget->setLayout(vLayout);

    this->setWidget(widget);

    edit = NULL;
    name = NULL;
    hLayout = NULL;


    bdrLst<<"none"<<"alphatJayatillekeWallFunction"<<"calculated"<<"compressible::alphatJayatillekeWallFunction"
      <<"empty"<<"fixedValue"<<"freestream"<<"fixedFluxPressure"
      <<"inletOutlet"<<"nutUSpaldingWallFunction"<<"nutkWallFunction"
      <<"nutLowReWallFunction"<<"noSlip"
      <<"omegaWallFunction"<<"pressureInletOutletVelocity"<<"slip"
      <<"surfaceNormalFixedValue"<<"symmetry"<<"wedge"<<"zeroGradient";

    QStringList lst;
    lst.append(" ");
    lst.append("type    alphatJayatillekeWallFunction;\nvalue	uniform 0.0;\nPrt	0.72;");
    lst.append("type    calculated;\nvalue      $internalField;");
    lst.append("type    compressible::alphatJayatillekeWallFunction;\nvalue	uniform 0.0;\nPrt	0.72;");
    lst.append("type     empty;");
    lst.append("type    fixedValue;\nvalue      uniform 0;");
    lst.append("type    freeStream;\nfreestreamValue       uniform  0;");
    lst.append("type	fixedFluxPressure;\nrho         rhok;");
    lst.append("type    inletOutlet;\ninletValue    uniform 0;");
    lst.append("type    nutUSpaldingWallFunction;\nvalue   uniform 0;");
    lst.append("type    nutkWallFunction;\nvalue    $internalField;");
    lst.append("type    nutLowReWallFunction;\nvalue    $internalField;");
    lst.append("type    noSlip;");
    lst.append("type    omegaWallFunction;\nvalue    $internalField;");
    lst.append("type    pressureInletOutletVelocity;\nvalue uniform (0 0 0);\nrho	rhok;");
    lst.append("type    slip;");
    lst.append("type    surfaceNormalFixedValue;\nvalue    uniform (0 0 0);\nrefValue	uniform 0;");
    lst.append("type    symmetry;");
    lst.append("type    wedge;");
    lst.append("type    zeroGradient;");
    bdrValueLst = lst;

}

void boundarySetting::defineWidget(BOUNDARY bdr)
{
    count = bdr.totalBdr.toInt();
    edit = new QPlainTextEdit*[count];
    name = new QLabel*[count];
    value = new HComboBox*[count];
    hLayout = new QHBoxLayout*[count];
    QLabel *inter = new QLabel("internalField");
    interValue = new QLineEdit;
    interValue->setText("uniform 0;");
    interLayout = new QHBoxLayout;
    interLayout->addWidget(inter);
    interLayout->addWidget(interValue);
    vLayout->addLayout(interLayout);

    QVector<int> first(count);
    for(int i=0; i<count; i++)
        first[i] = -1;
    lastIndex = first;
    for(int i=0; i<count; i++)
    {
        edit[i] = new QPlainTextEdit;
        name[i] = new QLabel(bdr.value[i][0]);
        value[i] = new  HComboBox(i);
        value[i]->addItems(bdrLst);
        hLayout[i] = new QHBoxLayout;
        hLayout[i]->addWidget(name[i]);
        hLayout[i]->addWidget(value[i]);
        vLayout->addLayout(hLayout[i]);
        vLayout->addWidget(edit[i]);

        connect(value[i], SIGNAL(activated(int, int)), this, SLOT(defineBoundary(int,int)));

        if(bdr.value[i][1].compare("symmetry")==0)
        {
            int index = getTheBdrID("symmetry");
            first[i] = index;
            defineBoundaryAuto(index, i);
        }
        else if(bdr.value[i][1].compare("empty")==0)
        {
            int index = getTheBdrID("empty");
            first[i] = index;
            defineBoundaryAuto(index, i);
        }
        else if(bdr.value[i][1].compare("wedge")==0)
        {
            int index = getTheBdrID("wedge");
            first[i] = index;
            defineBoundaryAuto(index, i);
        }
        else if(bdr.value[i][1].compare("symmetryPlane")==0)
        {
            int index = getTheBdrID("symmetryPlane");
            first[i] = index;
            defineBoundaryAuto(index, i);
        }
    }
    //lastLastIndex = first;
    countIndex = 0;
    lastResults = new QString[count];
    vLayout->addStretch();
}

void boundarySetting::deleteWidget()
{
    for(int i=0; i<vLayout->count(); i++)
    {
        QLayoutItem *Item = vLayout->itemAt(i);
        if(Item->spacerItem())
        {
            vLayout->removeItem(Item);
            i--;
        }
    }
    for(int i=0; i<count; i++)
    {
        delete edit[i];
        delete name[i];
        delete hLayout[i];
    }
    delete name;
    delete edit;
    delete hLayout;
}

void boundarySetting::setUpPanel(BOUNDARY bdr)
{
    if(edit==NULL)
    {
        defineWidget(bdr);
    }
    else
    {
        deleteWidget();
        defineWidget(bdr);
    }
}

void boundarySetting::defineBoundary(int index, int editIndex)
{
    if(index!=lastIndex[editIndex])
    {
        edit[editIndex]->clear();
        edit[editIndex]->appendPlainText(bdrValueLst[index]);
        lastIndex[editIndex] = index;
    }
}

void boundarySetting::defineBoundaryAuto(int index, int editIndex)
{
    value[editIndex]->setCurrentIndex(index);
    defineBoundary(index, editIndex);
}

int boundarySetting::getTheBdrID(QString bdrName)
{
    int result;
    bool isFind=false;
    for(int i=0; i<bdrLst.size(); i++)
    {
        if(bdrLst[i].compare(bdrName)==0)
        {
            result = i;
            isFind = true;
            break;
        }
    }
    if(isFind)
        return result;
    else
        return -1;
}

HComboBox::HComboBox(int id)
{
    idx = id;
    connect(this, SIGNAL(activated(int)), this, SLOT(triggered()));
}

void HComboBox::wheelEvent(QWheelEvent *e)
{

}

void HComboBox::triggered()
{
    int index = this->currentIndex();
    emit activated(index, idx);
}
