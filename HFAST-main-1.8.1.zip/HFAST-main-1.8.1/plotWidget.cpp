#include "plotWidget.h"

plotWidget::plotWidget(int idx)
{
    index = idx;
    color.append(Qt::black);
    color.append(Qt::red);
    color.append(Qt::darkBlue);
    color.append(Qt::darkCyan);
    color.append(Qt::darkMagenta);
    color.append(Qt::darkGreen);
    color.append(Qt::gray);

    line.append(Qt::SolidLine);
    line.append(Qt::DashLine);
    line.append(Qt::DotLine);
    line.append(Qt::DashDotLine);
    line.append(Qt::DashDotDotLine);

    QSharedPointer<QCPAxisTickerLog> logTicker(new QCPAxisTickerLog);
    this->yAxis->setTicker(logTicker);
    this->yAxis->setScaleType(QCPAxis::stLogarithmic);
    logTicker->setLogBase(10);

    connect(this, SIGNAL(mouseRelease(QMouseEvent*)), this, SLOT(mouseReEvent(QMouseEvent*)));
    first = false;
    //this->setBackground(QColor(255,255,255,0));
}

void plotWidget::plotXY(pltPROPERTY plt, int idx)
{
    QVector<double> x(plt.x.size());
    QVector<double> y(plt.y.size());

    if(x.size()!=y.size())
        return;

    //this->addGraph();

    for(int i=0; i<x.size(); i++)
    {
        x[i] = plt.x[i].toDouble();
        y[i] = plt.y[i].toDouble();
    }
    this->graph(idx)->setData(x, y);
    this->xAxis->setLabel(plt.xLabel);
    this->yAxis->setLabel(plt.yLabel);
    //set range
    this->xAxis->setRange(x[0], x[plt.x.size()-1]);
    this->yAxis->setRange(y[0], y[plt.y.size()-1]*1e-1);
    this->graph(idx)->setName(plt.name);
    if(idx<color.size())
    {
        QPen pen;
        if(idx<line.size())
        {
            pen.setColor(color[idx]);
            pen.setStyle(line[idx]);
        }
        else
        {
            pen.setColor(color[idx]);
            pen.setStyle(line[0]);
        }
        this->graph(idx)->setPen(pen);
    }
    else
    {
        QPen pen(color[0], line[2]);
        this->graph(idx)->setPen(pen);
    }
    //this->yAxis->setScaleType(QCPAxis::stLogarithmic);

    this->rescaleAxes(true);

    this->replot();
}

void plotWidget::addLayer(int num)
{
    for(int i=0; i<num; i++)
        this->addGraph();
}

void plotWidget::mouseReEvent(QMouseEvent *e)
{
    //排除非左鼠标键
    if (e->button() != Qt::LeftButton)
    {
        return;
    }

    //获取点击的点坐标
    QPointF ChickedPoint = e->pos();
    //排除区间外鼠标点
    if(!this->viewport().contains(e->pos()))
    {
        return;
    }
    //将像素坐标转换为轴值
    double currentx = this->xAxis->pixelToCoord(ChickedPoint.x());
    double currenty = this->yAxis->pixelToCoord(ChickedPoint.y());
    //使用QToolTip输出值，
    QToolTip::showText(mapToGlobal(e->pos()),
        QString("当前点值为：x=%1,y=%2").arg(currentx).arg(currenty),this);
}
