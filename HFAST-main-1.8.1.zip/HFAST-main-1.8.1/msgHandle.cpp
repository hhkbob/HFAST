#include "msgHandle.h"
#include <QMetaType>
#include <QMutex>
#include <QMutexLocker>
#include <QCoreApplication>
#include <QApplication>

void static msgHandleFunction
(
        QtMsgType type,
        const QMessageLogContext &context,
        const QString &msg
)
{
    QMetaObject::invokeMethod(msgHandle::instance(), "message"
                            , Q_ARG(QtMsgType, type)
                            , Q_ARG(const QString, msg));
    QByteArray localMsg = msg.toLocal8Bit();
    switch(type)
    {
        case QtDebugMsg:
             fprintf(stderr, "Debug: %s (%s:%u)\n",
                    localMsg.constData(),context.file,context.line);
        break;
        case QtInfoMsg:
             fprintf(stderr, "Info: %s (%s:%u)\n",
                     localMsg.constData(),context.file,context.line);
        break;
        case QtWarningMsg:
             fprintf(stderr, "Warning: %s (%s:%u)\n",
                    localMsg.constData(),context.file,context.line);
        break;
        case QtCriticalMsg:
            fprintf(stderr, "Critical: %s (%s:%u)\n",
                     localMsg.constData(),context.file,context.line);
        break;
        case QtFatalMsg:
             fprintf(stderr, "Fata: %s (%s:%u)\n",
                localMsg.constData(),context.file,context.line);
        break;
    }
}

msgHandle *msgHandle::sInstance = 0;

msgHandle::msgHandle() : QObject(qApp)
{
    qRegisterMetaType<QtMsgType>("QtMsgType");
    qInstallMessageHandler(msgHandleFunction);
}

msgHandle *msgHandle::instance()
{
    static QMutex mutex;
    if (!sInstance) {
        QMutexLocker locker(&mutex);
        if (!sInstance)
            sInstance = new msgHandle;
    }

    return sInstance;
}


