#include "readBash.h"
#include "ui_runPanel.h"

readBash::readBash()
{
    optimize.active = 0;
}

void readBash::readBashFile(QString desFile)
{
    FILE *data = fopen(desFile.toLocal8Bit().data(), "r");
    if(data!=NULL)
    {
        // read the optimize
        bool su=false;
        su = readOptimize(data);
        fclose(data);
    }
}

bool readBash::readOptimize(FILE *data)
{
    //
    rewind(data);
    char buffer[500];
    while(!feof(data))
    {
        //--look for the activate_optimize
        fscanf(data, "%s", buffer);
        if(QString(buffer).compare("actived_optimize")==0)
        {
            optimize.active = true;
            while(!feof(data))
            {
                fscanf(data, "%s", buffer);
                if(QString(buffer).compare("{")==0)
                    break;
            }
            break;
        }
    }
    if(QString(buffer).compare("{")!=0)
        return false;
    else
    {
        char value[500];
        while(!feof(data))
        {
            fscanf(data, "%s", buffer);
            fgets(value, 500, data);
            //fscanf(data, "%s", value);
            qDebug()<<buffer<<"  "<<value;
            if(QString(buffer).compare("optimize_max")==0)
                optimize.max = QString(value).simplified();
            else if(QString(buffer).compare("optimize_min")==0)
                optimize.min = QString(value).simplified();
            else if(QString(buffer).compare("optimize_interval")==0)
                optimize.interval = QString(value).simplified();
            else if(QString(buffer).compare("optimize_refData")==0)
                optimize.ref = QString(value).simplified();
            else if(QString(buffer).compare("optimize_line")==0)
                optimize.line = QString(value).simplified();
            else if(QString(buffer).compare("optimize_var")==0)
                optimize.varIdx = QString(value).toInt();
            else if(QString(buffer).compare("optimize_process")==0)
                optimize.process = QString(value).toInt();
            else if(QString(buffer).compare("optimize_task")==0)
                optimize.task = QString(value).toInt();
            else if(QString(buffer).compare("}")==0)
                break;
        }
    }
    return true;
}

bool readBash::readRunPanel(QString file, runPanel *p)
{
    FILE *data = fopen(file.toLocal8Bit().data(), "r");
    if(data!=NULL){
    char buffer[500];
    {
        char val[500];
        QString value;
        while(!feof(data))
        {
            fscanf(data, "%s", buffer);
            fgets(val, 500, data);
            value = QString(val);
            if(QString(buffer).compare("runPanel_active_save_project")==0)
                p->ui->save->setChecked(value.toInt());
            else if(QString(buffer).compare("runPanel_active_read_monitor")==0)
                p->ui->read->setChecked(value.toInt());
            else if(QString(buffer).compare("runPanel_active_run_command")==0)
                p->ui->run->setChecked(value.toInt());
            else if(QString(buffer).compare("runPanel_run_command_file")==0)
                p->ui->runEdit->setText(value);
            else if(QString(buffer).compare("runPanel_active_time_variable")==0)
                p->ui->var->setChecked(value.toInt());
        }
    } fclose(data);}
    return true;
}

void readBash::setRunPanel(runPanel *panel)
{
    if(optimize.active)
    {
        panel->ui->coreNum->setValue(optimize.process);
        panel->ui->interval->setText(optimize.interval);
        panel->ui->OpMaxEdit->setText(optimize.max);
        panel->ui->OpMinEdit->setText(optimize.min);
        panel->ui->varBox->setCurrentIndex(optimize.varIdx);
        panel->ui->RefData->setText(optimize.ref);
        panel->ui->sampleData->setText(optimize.line);
        panel->ui->task->setValue(optimize.task);
        panel->ui->useOpt->setChecked(optimize.active);
    }
}

void readBash::changeWorkPath(QString file, fileToolBar *f)
{
    QString path = findValue("set_work_path", file);
    if(!path.isEmpty())
       f->setWorkDirBash(path);
}

void readBash::setProcess(QString file, generalPanel *gpanel)
{
    QString num = findValue("set_process_num", file);
    QString medIdx = findValue("set_process_method", file);
    gpanel->paraNum->setValue(num.toInt());
    gpanel->paraMet->setCurrentIndex(medIdx.toInt());
}

QString readBash::findValue(QString name, QString file)
{
    FILE *data = fopen(file.toLocal8Bit().data(), "r");
    char value[500];
    QString ref;
    if(data!=NULL)
    {
        char buffer[500];

        while(!feof(data))
        {
            fscanf(data, "%s", buffer);
            fgets(value, 500, data);
            if(QString(buffer).compare(name)==0)
            {
                ref = value;
                break;
            }
        }
    }
    return ref.simplified();
}
