#ifndef FUNCTIONS_H
#define FUNCTIONS_H
#include "HError.h"
#include "QString"
#include "QFile"
#pragma once
generalFunc::generalFunc()
{}
void generalFunc:: FatalErrors(QString inf)
{
    Mess mes;
    mes.Fun = "running application";
    mes.Head = "not need to know";
    mes.Loc = "here";
    mes.title = "critical";
    mes.Mess = inf;
    HError HFASTError;
    HFASTError.HFASTCritical(mes);
}

QList<QStringList> generalFunc::readXYData(QString file)
{
    QFile re(file);
    if(!re.open(QIODevice::ReadOnly | QIODevice::Text))
    {
        //qCritical() <<"Error cannot open file: "<< file;
        qDebug()<<"opening " << file <<" is wrong";
        QList<QStringList> tmp;
        return tmp;
    }
    qDebug()<<"opening " << file <<" is OK";
    QTextStream in(&re);
    in.setCodec("UTF-8");

    QStringList var;
    while(!in.atEnd())
    {
        QString line = in.readLine().toUtf8();
        QStringList lineLst = line.split(QRegExp(" "));
        if(lineLst[0]=="#")
        {
            for(int i=1; i<lineLst.size(); i++)
                if(!lineLst[i].isEmpty())
                      var.append(lineLst[i]);
            break;
        }
    }
    //-- read data
    QStringList dataTmp[var.size()];
    QList<QStringList> Tmp2;
    while(!in.atEnd())
    {
        QString line = in.readLine().toUtf8();
        QStringList lineLst = line.split(" ");
        lineLst.removeAll(QString(""));
        if(lineLst.size()!=var.size())
        {
            continue;
        }
        else
        {
            for(int i=0; i<var.size(); i++)
            {
                bool OK;
                double tr = lineLst[i].toDouble(&OK);
                if(OK)
                {
                   dataTmp[i].append(lineLst[i]);
                }
                else
                {
                    break;
                }
            }
        }
    }
    re.close();
    for(int i=0; i<var.size(); i++)
    {
        Tmp2.append(dataTmp[i]);
    }
    return Tmp2;
}

QStringList generalFunc::getTimeName(QString path, QString name)
{
    QString filePath = path+name;
    QDir dir(filePath);
    QStringList nameList;
    QStringList time;
    if(dir.exists())
    {
        nameList = dir.entryList(QDir::AllDirs);
        nameList.removeOne(".");
        nameList.removeOne("..");
        for(int i=0; i<nameList.size(); i++)
        {
            bool su;
            nameList[i].toDouble(&su);
            if(su)
                time.append(nameList[i]);
        }

        if(time.size()>0)
        {
            //  sort time, form small to large
            QString tmp;
            for(int i=0; i<time.size()-1; i++)
            {
                for(int j=i; j<time.size()-i-1; j++)
                {
                    if(time[j].toDouble()>time[j+1].toDouble())
                    {
                        tmp = time[j];
                        time[j] = time[j+1];
                        time[j+1] = tmp;
                    }
                }

            }
        }
    }
    return time;
}

#endif // FUNCTIONS_H
