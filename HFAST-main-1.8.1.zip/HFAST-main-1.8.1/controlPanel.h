#ifndef CONTROLPANEL_H
#define CONTROLPANEL_H

#include "solverWidget.h"
#define SOLVER 8
#define CTRKEY 8

class controlPanel : public QObject
{
    Q_OBJECT
public:
    explicit controlPanel(printTool *p, QWidget *widget);
    ~controlPanel();
    printTool *pEvent;
    CTRL ctrlT;
    void saveProject();
    void readproject();
    QLineEdit *keyLine[5];
private:
    QRadioButton *solver[SOLVER];
    QButtonGroup *sButGroup;
    QHBoxLayout *sTitle;
    QLabel *title;
    QComboBox *app;
    QStringList solverName[SOLVER];
    QList<int> solverDict[SOLVER];
    QList<bool> solverInCompressilbel[SOLVER];
    QList<QStringList> solverEq[SOLVER];
    QLabel *keyName[CTRKEY];    
    QComboBox *keyBox[3];
    QCheckBox *runModif;
    QCheckBox *Co;
    solverWidget *sPanel;
    void defineSolver();
    void definePanel(QWidget *w);

private:
    QHBoxLayout *sLayout[4];
    QVBoxLayout *sVLayout;
    QVBoxLayout *vLayout;
    QHBoxLayout *keyLayout[CTRKEY];
    QVBoxLayout *kLayout;
    QGroupBox *sGroup;

signals:
    void solverChoose(int solverDict);
    void appSelectTrigger(int);
    void sendAppName(QString);

public slots:
    void selectApp(int index);
    void selectAppIndex();
    void saveForNextStep();
};

#endif // CONTROLPANEL_H
