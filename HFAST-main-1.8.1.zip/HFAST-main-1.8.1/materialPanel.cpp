#include "materialPanel.h"

materialPanel::materialPanel(printTool *p, QWidget *m)
{
    pEvent = p;
    saveMt();
    setUpPanel();
    m->setLayout(vLayout);
    strcpy(mt.name, "air");
    mt.index = 0;
    currentInex = 0;
}

materialPanel::~materialPanel()
{
    delete dataBase;
    delete dataL;
    for(int i=0; i<MATERIAL_NUM; i++)
    {
        delete mtName[i];
        delete mtValue[i];
    }
    delete [] mtName;
    delete [] mtValue;
    delete hLayout;
    for(int i=0; i<MATERIAL_NUM; i++)
    {
        delete pLayout[i];
    }
    delete []pLayout;
    delete thValue;
    delete tGroup;
    delete tab;
    delete add;
    delete vLayout;
}

void materialPanel::saveProject()
{
    sprintf(mt.name, "%s", dataBase->currentText().toLocal8Bit().data());
    mt.index = currentInex;
    for(int i=0; i<MATERIAL_NUM; i++)
    {
        mt.materials[i] = mtValue[i]->text().toDouble();
    }
    pEvent->saveTool->mt = mt;

    tThermal.type = tGroup->save();
    tThermal.value = thValue->save();
    pEvent->saveTool->mThermal = tThermal;
    pEvent->saveTool->mtAdditional = add->toPlainText();
    pEvent->printMaterial(mt, "void materialPanel::saveProject()");
}

void materialPanel::readProject()
{
    dataBase->setCurrentIndex(pEvent->saveTool->mt.index);
    emit dataBase->activated(pEvent->saveTool->mt.index);

    tThermal = pEvent->saveTool->mThermal;
    if(tThermal.heat)
    {
        tGroup->read(tThermal.type);
        thValue->read(tThermal.value);
    }
    if(!pEvent->saveTool->mtAdditional.isEmpty())
        add->appendPlainText(pEvent->saveTool->mtAdditional);
}

void materialPanel::saveForNextStep()
{
    tThermal.type = tGroup->save();
    tThermal.value = thValue->save();
    pEvent->saveTool->mThermal = tThermal;
}

void materialPanel::setUpPanel()
{
    readMt("void materialPanel::setUpPanel()");

    QList<QString> list1 = pEvent->saveTool->mtName;

    QStringList mtList;
    mtList.append("air");
    mtList.append("water");

    dataBase = new QComboBox;
    dataBase->addItems(mtList);
    dataBase->setCurrentIndex(0);
    dataL = new QLabel(tr("dataBase"));

    hLayout = new QHBoxLayout;
    hLayout->addWidget(dataL);
    hLayout->addWidget(dataBase);
    hLayout->addStretch();

    vLayout = new QVBoxLayout;
    vLayout->addLayout(hLayout);

    char buffer[50];
    for(int i=0; i<MATERIAL_NUM; i++)
    {
        sprintf(buffer, "%lf", list[0].materials[i]);
        mt.materials[i] = list[0].materials[i];
        mtName[i] = new QLabel(list1[i]);
        mtValue[i] = new QLineEdit;
        mtValue[i]->setText(buffer);
        mtName[i]->setMinimumWidth(40);
        mtName[i]->setMaximumWidth(40);
        pLayout[i] = new QHBoxLayout;
        pLayout[i]->addWidget(mtName[i]);
        pLayout[i]->addWidget(mtValue[i]);
        vLayout->addLayout(pLayout[i]);
    }
    tab = new QTabWidget;
    tGroup = new thermal;
    thValue = new thermaValue(tGroup);
    thValue->defineValue(list[0]);

    scroArea = new QScrollArea;
    scroArea->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOn);
    scroArea->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOn);
    scroArea->setWidgetResizable(true);
    scroArea->setWidget(thValue);
    //scroArea->setStyleSheet("background-color: #242424");

    tab->addTab(tGroup, tr("thermal type"));
    tab->addTab(scroArea, tr("mixture"));

    add = new QPlainTextEdit;
    vLayout->addWidget(tab);
    vLayout->addWidget(add);
    vLayout->addStretch();
    tab->setHidden(true);

    //  set hidden for heat
    if(pEvent->saveTool->Version.toInt()==10)
    {
        for(int i=2; i<MATERIAL_NUM; i++)
        {
            mtName[i]->setHidden(true);
            mtValue[i]->setHidden(true);
        }
    }
    else if(pEvent->saveTool->Version.toInt()==5)
    {
        ;
    }
    connect(tGroup->value[2], SIGNAL(activated(int)), thValue, SLOT(thermoChange(int)));
    connect(dataBase, SIGNAL(activated(int)),SLOT(showDetail(int)));

}

void materialPanel::printMt(QString loc, MATERIAL mtr)
{
    FILE *data=fopen("material.data", "ab+");
    if(data==NULL)
    {
        HError HFASTError;
        Mess mes;
        mes.Fun = "materialPanel::printMt(...)";
        mes.Head = "materialPanel.h";
        mes.Loc = loc;
        mes.title = "Warning";
        mes.Mess = "cannot create the material.data again";
        HFASTError.HFASTWarning(mes);
    }
    else
    {
        fwrite(&mtr, sizeof(MATERIAL), 1, data);
        fclose(data);
    }
}

void materialPanel::saveMt()
{
    FILE *data = fopen("material.data","'rb");
    if(data==NULL)
    {
        defineAir();
        defineWater();
    }
    else
    {
        fclose(data);
    }
}

void materialPanel::readMt(QString loc)
{
    FILE *data = fopen("material.data", "rb");
    if(data==NULL)
    {
        HError HFASTError;
        Mess mes;
        mes.Fun = "void materialPanel::readMt(QString loc)";
        mes.Head = "materialPanel.h";
        mes.Loc = loc;
        mes.title = "Warning";
        mes.Mess = "cannot find the material.data. It affacts the definition of materials.";
        HFASTError.HFASTWarning(mes);
    }
    else
    {
        MATERIAL mt1;
        while(!feof(data))
        {
            fread(&mt1, sizeof(MATERIAL), 1, data);
            list.append(mt1);
        }
        fclose(data);
    }
}

void materialPanel::showDetail(int index)
{
    char buffer[50];
    for(int i=0; i<MATERIAL_NUM; i++)
    {
        sprintf(buffer, "%g", list[index].materials[i]);
        mtValue[i]->setText(buffer);
    }
    currentInex = index;
    thValue->defineValue(list[index]);
}

void materialPanel::hideWidget(int index)
{
     if(index==1 || index==2 || index==5)
     {
         tThermal.heat = true;
         tab->setHidden(false);
         for(int i=2; i<MATERIAL_NUM; i++)
         {
             mtName[i]->setHidden(false);
             mtValue[i]->setHidden(false);
         }
     }
     else
     {
         tThermal.heat = false;
         tab->setHidden(true);
         for(int i=2; i<MATERIAL_NUM; i++)
         {
             mtName[i]->setHidden(true);
             mtValue[i]->setHidden(true);
         }
     }
}

void materialPanel::defineAir()
{
    MATERIAL air;
    air.materials[NU]= 1.5e-5;
    air.materials[RHO] = 1.1716;
    air.materials[BETA] = 0.003;
    air.materials[T0] = 300;
    air.materials[MOWEIGHT] = 28.9;
    air.materials[CP] = 1005.5;
    air.materials[CV] = 712;
    air.materials[HF] = 0;
    air.materials[PR] = 0.7;
    air.materials[PRt] = 0.85;
    printMt("void materialPanel::defineAir()", air);
}

void materialPanel::defineWater()
{
    MATERIAL m;
    m.materials[NU] = 1.0e-3;
    m.materials[RHO] = 980;
    m.materials[BETA] = 0.003;
    m.materials[T0] = 300;
    m.materials[MOWEIGHT] = 18.0;
    m.materials[CP] = 4195;
    m.materials[CV] = 1000;
    m.materials[HF] = 0;
    m.materials[PR] = 2.289;
    m.materials[PRt] = 2;
    printMt("void materialPanel::defineWater()", m);
}
